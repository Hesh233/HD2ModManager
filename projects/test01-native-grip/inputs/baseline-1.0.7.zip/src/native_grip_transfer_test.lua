-- B23 opt-in experiment, separate from the production physics/attachment addons.
-- The converter supplies the wrist AXIS registration, not a palm-surface fit.
-- Position = rigid(Source wrist) * sourceToNativeAxes * animated original mount local.
-- B19/B20 write path: preserve native aim, refresh model -> gun -> components.
-- IK_right is observed. The left Source arm follows the held weapon's own IK_left marker.
-- Engine matrices and IdString values are temporary: retain numeric copies only.
local M = {VERSION = '1.0.7'}
local unpack = unpack or table.unpack

local function finite(x)
    return type(x) == 'number' and x == x and math.abs(x) < 1e10
end
local function copy(a)
    local b = {}; for i, v in ipairs(a) do b[i] = v end; return b
end
local function difference(a, b)
    local d = 0
    for i = 1, 12 do d = math.max(d, math.abs(a[i] - b[i])) end
    return d
end
local function distance(a, b)
    local d = 0
    for i = 10, 12 do d = d + (a[i] - b[i]) ^ 2 end
    return math.sqrt(d)
end
local function compose(a, b)
    local r = {}
    for c = 0, 2 do
        for j = 1, 3 do
            r[c * 3 + j] = a[j]*b[c*3+1] + a[j+3]*b[c*3+2] + a[j+6]*b[c*3+3]
        end
    end
    for j = 1, 3 do r[9+j] = a[j]*b[10] + a[j+3]*b[11] + a[j+6]*b[12] + a[9+j] end
    return r
end
local function inverse_vector(m, v)
    local a,b,c,d,e,f,g,h,i = m[1],m[4],m[7],m[2],m[5],m[8],m[3],m[6],m[9]
    local det = a*(e*i-f*h) - b*(d*i-f*g) + c*(d*h-e*g)
    assert(finite(det) and math.abs(det) > 1e-8, 'singular_parent')
    return {((e*i-f*h)*v[1] + (c*h-b*i)*v[2] + (b*f-c*e)*v[3])/det,
            ((f*g-d*i)*v[1] + (a*i-c*g)*v[2] + (c*d-a*f)*v[3])/det,
            ((d*h-e*g)*v[1] + (b*g-a*h)*v[2] + (a*e-b*d)*v[3])/det}
end
local function relative(a, b)
    local r = {}
    for c = 0, 2 do
        local v = inverse_vector(a, {b[3*c+1], b[3*c+2], b[3*c+3]})
        for j = 1, 3 do r[3*c+j] = v[j] end
    end
    local v = inverse_vector(a, {b[10]-a[10], b[11]-a[11], b[12]-a[12]})
    for j = 1, 3 do r[9+j] = v[j] end
    return r
end
local function rigid(m)
    local r, scales = copy(m), {}
    for c = 0, 2 do
        local n = 0; for j = 1, 3 do n = n + m[3*c+j]^2 end
        n = math.sqrt(n); assert(finite(n) and n > 1e-6, 'invalid_axis_scale')
        scales[c+1] = n
        for j = 1, 3 do r[3*c+j] = m[3*c+j]/n end
    end
    for a = 0, 1 do for b = a+1, 2 do
        local dot = 0; for j = 1, 3 do dot = dot + r[3*a+j]*r[3*b+j] end
        assert(math.abs(dot) < 0.002, 'sheared_wrist_or_mount')
    end end
    local det = r[1]*(r[5]*r[9]-r[6]*r[8]) - r[4]*(r[2]*r[9]-r[3]*r[8])
        + r[7]*(r[2]*r[6]-r[3]*r[5])
    assert(det > 0.998 and det < 1.002, 'mirrored_wrist_or_mount')
    return r, scales
end
local function angle(a, b)
    local x, y = rigid(a), rigid(b)
    local trace = 0; for i = 1, 9 do trace = trace + x[i]*y[i] end
    return math.deg(math.acos(math.max(-1, math.min(1, (trace-1)/2))))
end
local function quote(s)
    return '"' .. tostring(s):gsub('[%z\1-\31\\"]', function(c)
        if c == '\\' then return '\\\\' elseif c == '"' then return '\\"' end
        return string.format('\\u%04x', string.byte(c))
    end) .. '"'
end
local function json(v)
    if v == nil then return 'null' end
    if type(v) == 'boolean' then return tostring(v) end
    if type(v) == 'number' then assert(finite(v), 'nonfinite_log'); return string.format('%.12g', v) end
    if type(v) == 'string' then return quote(v) end
    assert(type(v) == 'table', 'invalid_log_value')
    local out = {}
    if #v > 0 then
        for i = 1, #v do out[i] = json(v[i]) end
        return '[' .. table.concat(out, ',') .. ']'
    end
    local keys = {}; for k in pairs(v) do keys[#keys+1] = k end; table.sort(keys)
    for _, k in ipairs(keys) do out[#out+1] = quote(k) .. ':' .. json(v[k]) end
    return '{' .. table.concat(out, ',') .. '}'
end

function M.new(S, cfg, logger, ArmMath)
    local U, X, W, A = S.Unit, S.Matrix4x4, S.World, S.Application
    assert(U and X and W and A and S.IdString64, 'engine_api_missing')
    for _, name in ipairs({'alive','resource_name','num_scene_graph_items','has_node','node',
                           'scene_graph_parent','local_pose','world_pose','set_local_pose'}) do
        assert(type(U[name]) == 'function', 'unit_api_missing:' .. name)
    end
    assert(type(W.units)=='function' and type(W.update_unit)=='function'
        and type(A.worlds)=='function' and type(A.string_to_id32)=='function'
        and type(X.to_elements)=='function' and type(X.from_elements)=='function'
        and type(S.IdString64.to_hex)=='function', 'pose_api_missing')
    assert(cfg.target.name == 'attach_hand_r' and cfg.target.index == 84, 'write_allowlist')
    assert(cfg.originalMount.index ~= cfg.target.index and cfg.originalMount.parent == cfg.target.parent,
        'independent_original_reference_required')
    assert(cfg.sourceRight.name:match('_r_hand$'), 'source_wrist_required')
    assert(cfg.axisRegistration == 'converter-reference-rotation', 'axis_registration_required')
    rigid(cfg.rightAxes); rigid(cfg.leftAxes)
    local leftEnabled=cfg.leftGrip and cfg.leftGrip.enabled==true
    for _, row in ipairs(cfg.attachments or {}) do
        assert(row.node.index~=cfg.target.index and row.native.name~='head', 'attachment_allowlist')
        assert(row.node.name~='weapon_aim' and row.node.name~='aim_weapon'
            and row.node.name~='boss_aim' and row.node.name~='climb_ref'
            and row.node.name~='attach_cam_1', 'controller_input_protected')
        rigid(row.axes)
    end
    if leftEnabled then
        assert(ArmMath and type(ArmMath.solve_arm)=='function' and type(ArmMath.quaternion)=='function',
            'existing_arm_math_required')
        local nodes=cfg.leftGrip.nodes
        assert(#nodes==4,'left_arm_allowlist')
        local outputs=cfg.leftGrip.outputs
        if outputs then
            assert(#outputs==3 and outputs[3].index==cfg.sourceLeft.index,'left_output_allowlist')
            for i=1,3 do assert(outputs[i].parent==nodes[i+1].index,'left_output_reference_parent') end
        else assert(nodes[4].index==cfg.sourceLeft.index,'left_arm_allowlist') end
        for i=2,4 do assert(nodes[i].parent==nodes[i-1].index,'left_arm_direct_chain') end
        assert(nodes[2].name:match('_l_shoulder$')
            and nodes[3].name:match('_l_elbow$'),'left_source_chain_required')
        local targets=cfg.leftGrip.weaponTargets
        assert(type(targets)=='table','left_weapon_targets_required')
        local count=0
        for id,row in pairs(targets) do
            count=count+1
            assert(type(id)=='string' and #id==16
                and (row.rootName=='boss' or row.rootName=='skeleton'),
                'left_target_identity:'..tostring(id))
            for _,key in ipairs({'rootToIKLeft','rootToIKRight'}) do
                local m=row[key]
                if key=='rootToIKLeft' or m~=nil then
                    assert(type(m)=='table' and #m==12,'left_target_matrix:'..key..':'..tostring(id))
                    for j=1,12 do assert(finite(m[j]),'left_target_finite:'..key..':'..tostring(id)) end
                    rigid(m)
                end
            end
        end
        assert(count>0,'left_weapon_targets_empty')
    end
    local self = {pending={}, actors={}, models={}, consumers={}, sequence=0, identities={},
        monitored={},syncFrame=nil,lastSync=nil,
        lastScan=nil, lastLog=nil, lastStatus=nil, disabled=false, stopped=false, records=0,
        stats={writes=0, readbacks=0, restores=0, freshPreserved=0, skipped=0,mountSkipped=0,
            modelRefreshes=0, consumerRefreshes=0, refreshErrors=0,
            leftWrites=0,leftNodeWrites=0,leftRestores=0,leftFreshPreserved=0,leftSkipped=0,
            syncSamples=0,syncErrors=0,bodyNodeWrites=0,bodyRestores=0,bodyFreshPreserved=0,
            attachmentWrites=0,attachmentRestores=0,attachmentFreshPreserved=0}}
    local function emit(row, urgent)
        if self.records >= cfg.maxRecords and not urgent then return end
        row.variant = cfg.variant
        self.records = self.records + 1; logger(json(row))
    end
    local function resource(u)
        local id = S.IdString64.to_hex(U.resource_name(u))
        assert(type(id)=='string' and id:match('^%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x$'), 'resource_id')
        return id:lower()
    end
    local function matrix(u, n, world)
        local r = {X.to_elements((world and U.world_pose or U.local_pose)(u, n+1))}
        assert(#r == 12, 'matrix_size')
        for _, v in ipairs(r) do assert(finite(v), 'matrix_nonfinite') end
        return r
    end
    local function verify_node(u,node,parents)
        local id=A.string_to_id32(node.name)
        assert(U.has_node(u,id)==true and U.node(u,id)==node.index+1,'node_identity:'..node.name)
        if parents then assert(U.scene_graph_parent(u,node.index+1)==node.parent+1,'node_parent:'..node.name) end
    end
    local function identity(item)
        local u, spec = item.unit, item.spec
        assert(U.alive(u)==true,'unit_dead')
        local count=U.num_scene_graph_items(u)
        assert(count==spec.count,'node_count:'..spec.kind..':actual='..tostring(count)..':expected='..spec.count)
        assert(resource(u)==spec.resource, 'resource_changed')
        for _, node in ipairs(spec.nodes) do
            local id = A.string_to_id32(node.name)
            assert(U.has_node(u,id)==true and U.node(u,id)==node.index+1, 'node_identity:'..node.name)
            if node.parent ~= nil and (spec.kind=='avatar' or spec.kind=='model') then
                local parent = U.scene_graph_parent(u,node.index+1)
                -- B21 live captures show nil parents for externally linked model bones.
                -- Their five world poses must still match one Avatar before any write.
                local externalModelParent = spec.kind=='model' and parent==nil
                assert(externalModelParent or parent==node.parent+1, 'node_parent:'..node.name)
            end
        end
    end
    local function visible(u)
        if not (U.num_meshes and U.mesh and S.Mesh and S.Mesh.visibility) then return nil end
        local count=U.num_meshes(u)
        if not finite(count) or count<1 or count>128 then return nil end
        local unknown=false
        for i=1,count do
            local value=S.Mesh.visibility(U.mesh(u,i))
            if value==true then return true elseif value~=false then unknown=true end
        end
        if unknown then return nil end
        return false
    end
    -- B19/B20 enumerated every world and every Unit. Prefix limits miss live
    -- mission actors while still admitting the much smaller preview worlds.
    local function members()
        local result, worlds = {}, A.worlds() or {}
        for wi, world in ipairs(worlds) do
            local ok, units = pcall(W.units, world)
            if ok then
                local set = {}; result[world] = {units=units or {}, set=set, label=wi}
                for _, u in ipairs(units or {}) do set[u]=true end
            end
        end
        return result
    end
    local function present(item, membership)
        return membership[item.world] and membership[item.world].set[item.unit] == true
    end
    local function refresh_models(world, membership)
        for _, item in ipairs(self.models) do
            if item.world==world and present(item,membership) then
                local ok,why=pcall(function()
                    identity(item)
                    if visible(item.unit)~=false then
                        W.update_unit(world,item.unit)
                        self.stats.modelRefreshes=self.stats.modelRefreshes+1
                    end
                end)
                if not ok then
                    self.stats.refreshErrors=self.stats.refreshErrors+1
                    if self.stats.refreshErrors<=8 then
                        emit({event='refresh_unavailable',kind='model',resource=item.spec.resource,reason=tostring(why)})
                    end
                end
            end
        end
    end
    local function refresh_consumers(world, membership)
        for _, item in ipairs(self.consumers) do
            if item.world==world and present(item,membership) then
                -- B19/B20 refreshes every recognized existing equipment graph
                -- in the affected world, with gun roots before components.
                local ok,why=pcall(function()
                    identity(item)
                    if visible(item.unit)~=false then
                        if item.spec.kind=='linked_item' then
                            local near=false
                            for _, actor in ipairs(self.actors) do
                                if actor.world==world and present(actor,membership) then
                                    near=near or distance(matrix(item.unit,item.spec.root,true),
                                        matrix(actor.unit,cfg.target.index,true))<=cfg.consumerRadius
                                end
                            end
                            if not near then return end
                        end
                        W.update_unit(world,item.unit)
                        self.stats.consumerRefreshes=self.stats.consumerRefreshes+1
                    end
                end)
                if not ok then
                    self.stats.refreshErrors=self.stats.refreshErrors+1
                    if self.stats.refreshErrors<=8 then
                        emit({event='refresh_unavailable',kind=item.spec.kind,resource=item.spec.resource,reason=tostring(why)})
                    end
                end
            end
        end
    end
    local function restore(record, membership, force)
        local item = record.actor
        if not present(item,membership) then return 'gone' end
        local valid = pcall(identity,item)
        if not valid then return 'layout_changed' end
        local changed=false
        local function restore_node(index,before,written,left)
            local current=matrix(item.unit,index,false)
            if not force and difference(current,written)>cfg.localTolerance then
                local key=left=='attachment' and 'attachmentFreshPreserved' or left=='body' and 'bodyFreshPreserved' or left and 'leftFreshPreserved' or 'freshPreserved'
                self.stats[key]=self.stats[key]+1
                return
            end
            U.set_local_pose(item.unit,index+1,X.from_elements(unpack(before)))
            assert(difference(matrix(item.unit,index,false),before)<=cfg.localTolerance,'restore_readback')
            local key=left=='attachment' and 'attachmentRestores' or left=='body' and 'bodyRestores' or left and 'leftRestores' or 'restores';self.stats[key]=self.stats[key]+1
            changed=true
        end
        if record.written then restore_node(cfg.target.index,record.before,record.written,false) end
        for _,row in ipairs(record.left or {}) do
            if row.touched then restore_node(row.index,row.before,row.written,true) end
        end
        for _,row in ipairs(record.body or {}) do
            if row.touched then restore_node(row.index,row.before,row.written,'body') end
        end
        for _,row in ipairs(record.attachments or {}) do
            if row.touched then restore_node(row.index,row.before,row.written,'attachment') end
        end
        if changed then
            W.update_unit(item.world,item.unit)
            refresh_models(item.world,membership)
            refresh_consumers(item.world,membership)
        end
        return changed and 'restored' or 'fresh_animation_preserved'
    end
    function self:release(membership)
        local pending = self.pending; self.pending = {}
        for _, record in ipairs(pending) do
            local ok, result = pcall(restore,record,membership,false)
            if not ok then
                self.pending[#self.pending+1]=record; self.disabled=true
                emit({event='restore_failed',avatar=record.actor.id,reason=tostring(result)},true)
            elseif record.diagnostic or result=='layout_changed' then
                emit({event='release',avatar=record.actor.id,result=result,phase=self.phase},true)
            end
        end
    end
    -- Reuse B19/B20 marker-based equipment discovery. These dynamic signatures
    -- authorize graph refresh/observation only, never setters or new links.
    local function equipment_spec(u, id, count)
        if count<3 or count>192 then return nil end
        local function node(name)
            local hash=A.string_to_id32(name)
            if U.has_node(u,hash)~=true then return nil end
            local n=U.node(u,hash)
            assert(finite(n) and n%1==0 and n>=1 and n<=count,'consumer_node_index:'..name)
            return {name=name,index=n-1}
        end
        local left,right=node('IK_left'),node('IK_right')
        local supported=cfg.leftGrip and cfg.leftGrip.weaponTargets[id]
        if supported and left then
            local root=node(supported.rootName)
            if not root then return nil end
            local nodes={root,left};if right then nodes[#nodes+1]=right end
            for _, name in ipairs(supported.linkNodes or {}) do
                local extra=node(name)
                if extra and extra.index~=root.index then nodes[#nodes+1]=extra end
            end
            return {kind='weapon',resource=id,count=count,nodes=nodes,root=root.index,order=0}
        end
        if left and right then
            local root=node('boss') or node('skeleton') or right
            return {kind='weapon',resource=id,count=count,nodes={left,right,root},root=root.index,order=0}
        end
        local skeleton,mesh=node('skeleton'),node('game_mesh')
        if not mesh then return nil end
        if not skeleton then
            -- G-16 and other rigid hand items have game_mesh/pivot but no
            -- skeleton or IK markers. They still consume the right hand link.
            local pivot=node('pivot')
            if not pivot then return nil end
            return {kind='linked_item',resource=id,count=count,nodes={mesh,pivot},root=pivot.index,order=2}
        end
        for _,row in ipairs({{'IK_left','weapon_grip'},{'muzzle','weapon_muzzle'},
                             {'attach_offset','weapon_optic'},{'bullet_01','weapon_magazine'},
                             {'laser','weapon_underbarrel'}}) do
            local marker=node(row[1])
            if marker then
                return {kind=row[2],resource=id,count=count,nodes={skeleton,mesh,marker},
                    root=skeleton.index,order=1}
            end
        end
        -- Shells, revolver parts and carried objects need a cache refresh too;
        -- IK/muzzle/bullet_01 is not a complete equipment signature. No setters
        -- are authorized on these Units, and refresh is limited to nearby items.
        local root=node('boss') or node('root') or skeleton
        return {kind='linked_item',resource=id,count=count,nodes={skeleton,mesh,root},
            root=root.index,order=2}
    end
    local function scan(membership, now)
        self.actors={}; self.models={}; self.consumers={}
        local identities,seen,worlds,rejected = {},{},{},{}
        for world, group in pairs(membership) do
            local summary={world=group.label,units=#group.units,actors=0,models=0,consumers=0}
            worlds[#worlds+1]=summary
            local function consider(u)
                if seen[u] or not group.set[u] then return end
                seen[u]=true
                local ok,why=pcall(function()
                    if U.alive(u)~=true then return end
                    local count=U.num_scene_graph_items(u)
                    if count<cfg.minNodes or count>cfg.maxNodes then return end
                    local id=resource(u)
                    local spec = id==cfg.avatar.resource and cfg.avatar or cfg.models[id] or cfg.consumers[id]
                        or equipment_spec(u,id,count)
                    if not spec then return end
                    local item={unit=u,world=world,worldLabel=group.label,spec=spec}
                    identity(item)
                    local previous=self.identities[u]
                    if previous and previous.world==world and previous.resource==id then item.id=previous.id
                    else self.sequence=self.sequence+1;item.id=self.sequence end
                    identities[u]={id=item.id,world=world,resource=id}
                    if spec.kind=='avatar' then self.actors[#self.actors+1]=item;summary.actors=summary.actors+1
                    elseif spec.kind=='model' then self.models[#self.models+1]=item;summary.models=summary.models+1
                    else self.consumers[#self.consumers+1]=item;summary.consumers=summary.consumers+1 end
                end)
                if not ok then
                    local reason=tostring(why);rejected[reason]=(rejected[reason] or 0)+1
                end
            end
            if type(W.units_by_resource)=='function' then
                local ok,avatars=pcall(W.units_by_resource,world,'content/fac_helldivers/cha_avatar/avatar_helldiver')
                if ok then for _,u in ipairs(avatars or {}) do consider(u) end
                else rejected.avatar_query=(rejected.avatar_query or 0)+1 end
            end
            for _,u in ipairs(group.units) do consider(u) end
        end
        -- Gun graph first, then its separate foregrip graph.
        table.sort(self.consumers,function(a,b) return a.spec.order<b.spec.order end)
        self.identities=identities;self.lastScan=now
        table.sort(worlds,function(a,b) return a.world<b.world end)
        emit({event='scan',time=now,worlds=worlds,actors=#self.actors,models=#self.models,
            consumers=#self.consumers,rejected=rejected,scope='all_worlds_all_units'})
    end
    local function matching_actors(membership)
        local selected,blocked={},{}
        local reasons={hidden=0,poseMismatch=0,ambiguous=0,unavailable=0}
        for _, model in ipairs(self.models) do
            local ok, matches=pcall(function()
                if not present(model,membership) then return {} end
                identity(model);if not visible(model.unit) then reasons.hidden=reasons.hidden+1;return {} end
                local poses={}
                for i,row in ipairs(model.spec.nodes) do poses[i]=matrix(model.unit,row.index,true) end
                local found={}
                for _, actor in ipairs(self.actors) do
                    if actor.world==model.world and present(actor,membership) then
                        local good=pcall(function()
                            identity(actor)
                            for i,row in ipairs(model.spec.nodes) do
                                assert(difference(poses[i],matrix(actor.unit,row.avatarIndex,true))<=cfg.matchTolerance,
                                    'model_avatar_pose_mismatch')
                            end
                        end)
                        if good then found[#found+1]=actor else reasons.poseMismatch=reasons.poseMismatch+1 end
                    end
                end
                return found
            end)
            -- Geometric agreement gates this experiment, not a claim of API ownership.
            if ok and #matches==1 then selected[matches[1]]=model
            elseif ok and #matches>1 then
                reasons.ambiguous=reasons.ambiguous+1
                for _,actor in ipairs(matches) do blocked[actor]=true end
            elseif not ok then reasons.unavailable=reasons.unavailable+1 end
        end
        for actor in pairs(blocked) do selected[actor]=nil end
        return selected,reasons
    end
    -- Observe both the live native skeleton and the added Source hierarchy.
    -- The observer itself does not write poses; output nodes may inherit native parents.
    local function begin_sync(frame,now)
        local sync=cfg.sync
        if not sync or not sync.enabled or not next(self.monitored) then return end
        if self.stats.syncSamples>=sync.maxSamples or self.syncFrame==frame then return end
        if self.lastSync and now>=self.lastSync and now-self.lastSync<sync.seconds then return end
        self.lastSync=now;self.syncFrame=frame;self.stats.syncSamples=self.stats.syncSamples+1
    end
    local function capture_sync(phase,selected,membership,frame,now)
        if self.syncFrame~=frame then return end
        for actor,model in pairs(selected) do
            local ok,why=pcall(function()
                if not present(actor,membership) or not present(model,membership) then return end
                identity(actor);identity(model)
                if not visible(model.unit) then return end
                local nodes={};local maximum,position=0,0
                for _,pair in ipairs(cfg.sync.pairs) do
                    verify_node(actor.unit,pair.native,false);verify_node(actor.unit,pair.source,false)
                    local native=matrix(actor.unit,pair.native.index,true)
                    local source=matrix(actor.unit,pair.source.index,true)
                    local equivalent=compose(rigid(source),pair.axes)
                    local node
                    for _,n in ipairs(model.spec.observeNodes or {}) do if n.driver==pair.name then node=n end end
                    assert(node,'sync_model_node_missing:'..pair.name)
                    local hash=A.string_to_id32(node.name)
                    assert(U.has_node(model.unit,hash)==true and U.node(model.unit,hash)==node.index+1,
                        'sync_model_identity:'..node.name)
                    local consumed=matrix(model.unit,node.index,true)
                    local error=difference(source,consumed)
                    maximum=math.max(maximum,error);position=math.max(position,distance(source,consumed))
                    nodes[pair.name]={nativeWorld=native,sourceWorld=source,modelWorld=consumed,
                        nativeLocal=matrix(actor.unit,pair.native.index,false),
                        sourceLocal=matrix(actor.unit,pair.source.index,false),
                        nativeParent=U.scene_graph_parent(actor.unit,pair.native.index+1) or 'nil',
                        sourceParent=U.scene_graph_parent(actor.unit,pair.source.index+1) or 'nil',
                        nativeSourceAngle=angle(native,equivalent),modelMatrixError=error}
                    if pair.reference then
                        verify_node(actor.unit,pair.reference,false)
                        nodes[pair.name].animationReferenceWorld=matrix(actor.unit,pair.reference.index,true)
                        nodes[pair.name].animationReferenceLocal=matrix(actor.unit,pair.reference.index,false)
                    end
                end
                local owned=0
                for _,record in ipairs(self.pending) do if record.actor.unit==actor.unit then
                    for _,row in ipairs(record.left or {}) do
                        if row.touched and difference(matrix(actor.unit,row.index,false),row.written)<=cfg.localTolerance then
                            owned=owned+1
                        end
                    end
                end end
                emit({event='sync',sample=self.stats.syncSamples,phase=phase,frame=frame,time=now,
                    avatar=actor.id,world=actor.worldLabel,modelResource=model.spec.resource,nodes=nodes,
                    aimWorld=matrix(actor.unit,cfg.sync.aim.index,true),
                    rightMountWorld=matrix(actor.unit,cfg.target.index,true),leftLocalsOwned=owned,
                    modelMaxMatrixError=maximum,modelMaxPositionError=position,
                    ownership='last_unique_geometric_match_revalidated',cameraSample=false,
                    upperBodyWrites=cfg.bodySync and cfg.bodySync.enabled or false})
            end)
            if not ok then
                self.stats.syncErrors=self.stats.syncErrors+1
                if self.stats.syncErrors<=8 then emit({event='sync_unavailable',phase=phase,frame=frame,
                    avatar=actor.id,reason=tostring(why)}) end
            end
        end
    end
    local function consumer_node(item,name)
        for _,node in ipairs(item.spec.nodes) do if node.name==name then return node.index end end
        error('consumer_marker_missing:'..name)
    end
    local function weapon_static(resource,key)
        local targets=cfg.leftGrip and cfg.leftGrip.weaponTargets
        local row=targets and targets[resource]
        if resource then return row and row[key] end
        if key=='rootToIKRight' then return cfg.weaponRight end
        return cfg.weaponForegripLeft
    end
    local function plan_left(actor,target,nativeBefore,nativeLeft,membership)
        local c=cfg.leftGrip
        for _,node in ipairs(c.nodes) do verify_node(actor.unit,node,true) end
        for _,node in ipairs(c.outputs or {}) do verify_node(actor.unit,node,true) end
        local weapons={}
        local mounts={{name='attach_hand_r',pose=target}}
        for _, row in ipairs(cfg.attachments or {}) do
            if row.node.name=='attach_weapon' then
                mounts[#mounts+1]={name=row.node.name,pose=matrix(actor.unit,row.node.index,true)}
            end
        end
        for _,item in ipairs(self.consumers) do
            local supported=c.weaponTargets[item.spec.resource]
            if item.world==actor.world and supported and present(item,membership) then
                local ok,linked=pcall(function()
                    identity(item);if visible(item.unit)==false then return nil end
                    local names=supported.linkNodes or {supported.rootName}
                    for _,name in ipairs(names) do
                        local hash=A.string_to_id32(name)
                        if U.has_node(item.unit,hash) then
                            local pose=matrix(item.unit,U.node(item.unit,hash)-1,true)
                            for _,mount in ipairs(mounts) do
                                if distance(pose,mount.pose)<=c.linkMetres and angle(pose,mount.pose)<=c.linkDegrees then
                                    -- Sidearms use the hand-r link while aiming; the
                                    -- hip carry link must not force their free hand.
                                    -- GP-20 Ultimatum explicitly uses both links.
                                    if supported.leftPolicy~='aim_only' or mount.name=='attach_hand_r' then
                                        return {mount=mount.name,node=name}
                                    end
                                end
                            end
                        end
                    end
                end)
                if ok and linked then
                    weapons[#weapons+1]={item=item,link=linked}
                end
            end
        end
        if #weapons~=1 then return nil,'no_unique_supported_held_weapon' end
        local weapon=weapons[1].item
        -- 2026-11-05 user decision: the left hand always targets the held weapon's
        -- own IK_left marker, underbarrel accessories are no longer link-searched.
        local gripPose=matrix(weapon.unit,consumer_node(weapon,'IK_left'),true)
        local oldGrip=compose(nativeBefore,weapon_static(weapon.spec.resource,'rootToIKLeft'))
        local contact=distance(nativeLeft,oldGrip)
        local inContact=contact<=c.contactMetres and angle(nativeLeft,oldGrip)<=c.contactDegrees
        local function pose(m)
            return {p={m[10],m[11],m[12]},q=ArmMath.quaternion(rigid(m))}
        end
        local worlds,locals={},{ }
        for i,node in ipairs(c.nodes) do
            worlds[i]=matrix(actor.unit,node.index,true)
            locals[i]=matrix(actor.unit,node.index,false)
        end
        local _,parentScales=rigid(worlds[1]);local parentScale=parentScales[1]
        for i=2,3 do assert(math.abs(parentScales[i]-parentScale)<0.001,'left_parent_nonuniform_scale') end
        for i=2,4 do
            local _,scales=rigid(locals[i])
            for j=1,3 do assert(math.abs(scales[j]-1)<0.001,'left_joint_scaled') end
        end
        local root,mid,hand,parent=pose(worlds[2]),pose(worlds[3]),pose(worlds[4]),pose(worlds[1])
        local axes={p={0,0,0},q=ArmMath.quaternion(cfg.leftAxes)}
        local inverseAxes=ArmMath.relative(axes,{p={0,0,0},q={0,0,0,1}})
        local desiredHand=ArmMath.compose(pose(gripPose),inverseAxes)
        desiredHand.referencePosition=hand.p
        local chain={upperCalibration={0,0,0,1},forearmCalibration={0,0,0,1},handCalibration={0,0,0,1},
            upperOffset={locals[3][10],locals[3][11],locals[3][12]},
            forearmOffset={locals[4][10],locals[4][11],locals[4][12]},armFrame='reference',
            hingeAxis=c.hingeAxis,forearmHingeAxis=c.forearmHingeAxis}
        -- Match processor._apply_two_bone_ik's reachable interval and soft extension.
        -- Native contact is telemetry only: an unreachable target still extends the arm.
        local first,second=distance(worlds[2],worlds[3]),distance(worlds[3],worlds[4])
        local actualDistance=distance(worlds[2],gripPose)
        local minimum,maximum=math.abs(first-second)+1e-7,first+second-1e-7
        local reach=math.max(minimum,math.min(maximum,actualDistance))
        local soft=math.min(c.softDistance or 0,(maximum-minimum)*0.25)
        if soft>0 and actualDistance>maximum-soft then
            reach=maximum-soft*math.exp(-(actualDistance-(maximum-soft))/soft)
        end
        for j=1,3 do
            local direction=actualDistance>1e-8 and (gripPose[j+9]-root.p[j])/actualDistance
                or (mid.p[j]-root.p[j])/first
            desiredHand.p[j]=root.p[j]+direction*reach
        end
        local targets=ArmMath.solve_arm(root,root,mid,desiredHand,parent,chain,{},1/60,parentScale,desiredHand.q)
        local residual=math.abs(actualDistance-reach)
        local rows={};local expected=worlds[1]
        for i=1,3 do
            local before=locals[i+1];local written=copy(before)
            for col=0,2 do
                local axis={0,0,0};axis[col+1]=1
                local rotated=ArmMath.rotate(targets[i].q,axis)
                for j=1,3 do written[col*3+j]=rotated[j] end
            end
            -- The existing solver changes rotations; retain the animated bone offsets.
            for j=1,3 do assert(math.abs(targets[i].p[j]-before[j+9])<cfg.localTolerance,'left_bone_offset_changed') end
            expected=compose(expected,written)
            local output=c.outputs and c.outputs[i]
            if output then
                -- The animation still owns the private input chain. Only its
                -- unanimated named outputs receive IK deltas, held through skinning.
                rows[i]={index=output.index,before=matrix(actor.unit,output.index,false),
                    written=relative(worlds[i+1],expected),touched=false}
            else rows[i]={index=c.nodes[i+1].index,before=before,written=written,touched=false} end
        end
        return {rows=rows,target=gripPose,expected=expected,before=worlds[4],reachResidual=residual,
            nativeContactDistance=contact,nativeInContact=inContact,weapon=weapon.id,
            weaponResource=weapon.spec.resource,link=weapons[1].link}
    end
    local function plan_attachments(actor)
        local rows={}
        for _,spec in ipairs(cfg.attachments or {}) do
            verify_node(actor.unit,spec.node,true);verify_node(actor.unit,spec.native,true)
            verify_node(actor.unit,spec.source,true)
            if spec.reference then verify_node(actor.unit,spec.reference,true) end
            local before=matrix(actor.unit,spec.node.index,true)
            local reference=spec.reference and matrix(actor.unit,spec.reference.index,true) or before
            -- Snapshot every offset before any attachment write. Nested cape
            -- nodes must not receive the parent's translation a second time.
            local offset=relative(rigid(matrix(actor.unit,spec.native.index,true)),reference)
            rows[#rows+1]={spec=spec,index=spec.node.index,before=matrix(actor.unit,spec.node.index,false),
                basis=before,offset=offset,touched=false}
        end
        return rows
    end
    local function apply_attachments(actor,rows,leftPhase)
        local worlds,changed={},{}
        for _,row in ipairs(rows) do
            if (row.spec.native.name=='l_hand' or row.spec.native.name=='l_elbow')==leftPhase then
                local destination=compose(compose(rigid(matrix(actor.unit,row.spec.source.index,true)),row.spec.axes),row.offset)
                local desired=copy(row.basis)
                for i=10,12 do desired[i]=destination[i] end
                row.written=relative(worlds[row.spec.node.parent] or matrix(actor.unit,row.spec.node.parent,true),desired)
                worlds[row.index]=desired;changed[#changed+1]=row
                row.touched=true
                U.set_local_pose(actor.unit,row.index+1,X.from_elements(unpack(row.written)))
                assert(difference(matrix(actor.unit,row.index,false),row.written)<=cfg.localTolerance,'attachment_local_readback')
                self.stats.attachmentWrites=self.stats.attachmentWrites+1
            end
        end
        if #changed>0 then
            W.update_unit(actor.world,actor.unit)
            for _,row in ipairs(changed) do
                assert(difference(matrix(actor.unit,row.index,true),worlds[row.index])<=cfg.worldTolerance,'attachment_world_readback')
            end
        end
    end
    local function observe_consumers(actor, sourceLeft, nativeLeft, target, membership, frame)
        for _, item in ipairs(self.consumers) do
            if item.world==actor.world and present(item,membership) then
                pcall(function()
                    identity(item)
                    local root=matrix(item.unit,item.spec.root,true)
                    if distance(root,target)>cfg.consumerRadius then return end
                    local poses={}
                    for _,node in ipairs(item.spec.nodes) do poses[node.name]=matrix(item.unit,node.index,true) end
                    local row={event='consumer',frame=frame,phase='render',avatar=actor.id,
                        world=actor.worldLabel,instance=item.id,kind=item.spec.kind,
                        resource=item.spec.resource,owner='unverified',poses=poses}
                    if item.spec.kind=='weapon' and cfg.leftGrip and cfg.leftGrip.enabled
                        and cfg.leftGrip.weaponTargets[item.spec.resource] then
                        row.mountDistance=distance(root,target);row.mountAngleDegrees=angle(root,target)
                        local right=weapon_static(item.spec.resource,'rootToIKRight')
                        row.rightMarkerAvailable=poses.IK_right~=nil
                        if poses.IK_right and right then
                            row.predictedRightMarkerError=distance(poses.IK_right,compose(target,right))
                        end
                        row.predictedLeftMarkerError=distance(poses.IK_left,
                            compose(target,weapon_static(item.spec.resource,'rootToIKLeft')))
                    elseif item.spec.kind=='foregrip' then
                        row.sourceLeftDistance=distance(sourceLeft,poses.IK_left)
                        row.sourceLeftAngleDegrees=angle(sourceLeft,poses.IK_left)
                        row.nativeLeftDistance=distance(nativeLeft,poses.IK_left)
                        row.nativeLeftAngleDegrees=angle(nativeLeft,poses.IK_left)
                        row.predictedForegripError=distance(poses.IK_left,compose(target,cfg.weaponForegripLeft))
                    end
                    emit(row)
                end)
            end
        end
    end
    local function apply(actor, model, membership, frame, now, diagnostic)
        local record
        local ok, why=pcall(function()
            identity(actor);identity(model)
            assert(visible(model.unit),'model_hidden_before_write')
            local u=actor.unit
            local original=matrix(u,cfg.originalMount.index,false)
            -- A rigid Source wrist preserves this displacement's length. Check
            -- the animated reference before any body/mount/left setter: an
            -- out-of-range transition must not disable every later weapon.
            local offset=compose(cfg.rightAxes,original)
            local mountDistance=math.sqrt(offset[10]^2+offset[11]^2+offset[12]^2)
            if mountDistance>cfg.maxWristMountDistance then
                self.stats.mountSkipped=self.stats.mountSkipped+1
                if diagnostic or self.stats.mountSkipped==1 then
                    emit({event='mount_skipped',avatar=actor.id,frame=frame,time=now,
                        reason='mount_offset_out_of_range',distance=mountDistance,
                        limit=cfg.maxWristMountDistance,retry='next_render',originalLocal=original})
                end
                return
            end
            record={actor=actor,diagnostic=diagnostic,protected={},body={},attachments=plan_attachments(actor)}
            self.pending[#self.pending+1]=record
            if cfg.bodySync and cfg.bodySync.enabled then
                for _,item in ipairs(cfg.bodySync.outputs) do
                    verify_node(u,item.node,true);verify_node(u,item.native,true)
                    verify_node(u,item.reference,true);verify_node(u,item.positionParent,true)
                    assert(item.node.parent==item.native.index,'body_native_parent_required')
                    -- Keep the Source torso's animated offsets; direct native
                    -- pivots otherwise separate its coincident upper-spine joints.
                    local positioned=compose(matrix(u,item.positionParent.index,true),matrix(u,item.reference.index,false))
                    local parentLocal=relative(matrix(u,item.native.index,true),positioned)
                    local outputPose=copy(item.localPose)
                    for j=10,12 do outputPose[j]=parentLocal[j] end
                    local row={index=item.node.index,before=matrix(u,item.node.index,false),
                        written=outputPose,touched=true}
                    record.body[#record.body+1]=row
                    U.set_local_pose(u,row.index+1,X.from_elements(unpack(row.written)))
                    assert(difference(matrix(u,row.index,false),row.written)<=cfg.localTolerance,'body_local_readback')
                    self.stats.bodyNodeWrites=self.stats.bodyNodeWrites+1
                    W.update_unit(actor.world,u)
                    assert(distance(matrix(u,row.index,true),positioned)<=cfg.worldTolerance,'body_position_readback')
                end
                refresh_models(actor.world,membership)
                if diagnostic then emit({event='body_applied',avatar=actor.id,frame=frame,
                    mode=cfg.bodySync.mode,outputs=#record.body,nativeLocalsWritten=false,
                    positionPolicy='source_chain_animated_offsets'}) end
            end
            local native=matrix(u,cfg.target.index,true)
            local nativeLeftBefore=leftEnabled and matrix(u,cfg.nativeLeft.index,true) or nil
            local source=matrix(u,cfg.sourceRight.index,true)
            local sourceLeft=compose(rigid(matrix(u,cfg.sourceLeft.index,true)),cfg.leftAxes)
            local equivalent=compose(rigid(source),cfg.rightAxes)
            local reference=compose(equivalent,original)
            -- B20's effective position-only setter: keep the live native aim
            -- basis and scale. The destination still uses B23's wrist reference.
            local desired=copy(native);local _,nativeScale=rigid(native)
            for j=10,12 do desired[j]=reference[j] end
            assert(distance(desired,source)<=cfg.maxWristMountDistance,'mount_offset_out_of_range')
            local parent=matrix(u,cfg.target.parent,true)
            local written=relative(parent,desired)
            for _,v in ipairs(written) do assert(finite(v),'invalid_output') end
            record.before=matrix(u,cfg.target.index,false);record.written=written
            record.sourceWorld=source;record.desired=desired
            for _,node in ipairs(cfg.protected) do
                record.protected[#record.protected+1]={node=node,localPose=matrix(u,node.index,false),
                    worldPose=node.world and matrix(u,node.index,true) or nil}
            end
            apply_attachments(actor,record.attachments,false)
            U.set_local_pose(u,cfg.target.index+1,X.from_elements(unpack(written)))
            self.stats.writes=self.stats.writes+1
            W.update_unit(actor.world,u)
            local modelRefreshes,consumerRefreshes=self.stats.modelRefreshes,self.stats.consumerRefreshes
            refresh_models(actor.world,membership)
            refresh_consumers(actor.world,membership)
            local leftResult,leftReason
            if leftEnabled then
                local planned,result,reason=pcall(plan_left,actor,desired,native,nativeLeftBefore,membership)
                if planned then leftResult,leftReason=result,reason else leftReason=tostring(result) end
                if leftResult then
                    record.left=leftResult.rows
                    for _,row in ipairs(record.left) do
                        row.touched=true
                        U.set_local_pose(u,row.index+1,X.from_elements(unpack(row.written)))
                        self.stats.leftNodeWrites=self.stats.leftNodeWrites+1
                    end
                    W.update_unit(actor.world,u)
                    refresh_models(actor.world,membership);refresh_consumers(actor.world,membership)
                    for _,row in ipairs(record.left) do
                        assert(difference(matrix(u,row.index,false),row.written)<=cfg.localTolerance,'left_local_readback')
                    end
                    local actualLeft=matrix(u,cfg.sourceLeft.index,true)
                    assert(difference(actualLeft,leftResult.expected)<=cfg.worldTolerance,'left_world_readback')
                    self.stats.leftWrites=self.stats.leftWrites+1
                    sourceLeft=compose(rigid(actualLeft),cfg.leftAxes)
                    if diagnostic then emit({event='left_applied',frame=frame,time=now,avatar=actor.id,
                        weapon=leftResult.weapon,weaponResource=leftResult.weaponResource,owner='unverified',
                        link=leftResult.link,
                        mode='existing_two_bone_solver',nativeContactDistance=leftResult.nativeContactDistance,
                        outputMode=cfg.leftGrip.outputs and 'unanimated_reference_children' or 'animated_source_nodes',
                        nativeInContact=leftResult.nativeInContact,requireNativeContact=false,
                        reachPolicy=cfg.leftGrip.reachPolicy,softDistance=cfg.leftGrip.softDistance,
                        beforeDistance=distance(leftResult.before,leftResult.target),
                        afterDistance=distance(actualLeft,leftResult.target),
                        afterAngleDegrees=angle(sourceLeft,leftResult.target),reachResidual=leftResult.reachResidual,
                        target=leftResult.target,sourceBefore=leftResult.before,sourceAfter=actualLeft}) end
                else
                    self.stats.leftSkipped=self.stats.leftSkipped+1
                    if diagnostic then emit({event='left_skipped',frame=frame,time=now,avatar=actor.id,reason=leftReason}) end
                end
            end
            -- A package or reload shell follows the final left wrist, whether
            -- that wrist is animated freely or solved to a two-handed weapon.
            apply_attachments(actor,record.attachments,true)
            if #record.attachments>0 then
                refresh_models(actor.world,membership);refresh_consumers(actor.world,membership)
                if diagnostic then emit({event='attachments_applied',frame=frame,avatar=actor.id,
                    count=#record.attachments,headDescendants=false,policy='position_preserve_native_basis',
                    singleHand='right_and_left_mounts_independent'}) end
            end
            local actual=matrix(u,cfg.target.index,true)
            assert(difference(matrix(u,cfg.target.index,false),written)<=cfg.localTolerance,'local_readback')
            assert(difference(actual,desired)<=cfg.worldTolerance,'world_readback')
            for _,row in ipairs(record.protected) do
                assert(difference(matrix(u,row.node.index,false),row.localPose)<=cfg.localTolerance,
                    'protected_local_changed:'..row.node.name)
                if row.worldPose then
                    assert(difference(matrix(u,row.node.index,true),row.worldPose)<=cfg.worldTolerance,
                        'protected_world_changed:'..row.node.name)
                end
            end
            self.stats.readbacks=self.stats.readbacks+1
            if diagnostic then
                local nativeLeft=matrix(u,cfg.nativeLeft.index,true)
                local rightMarker=leftResult and weapon_static(leftResult.weaponResource,'rootToIKRight')
                    or (not leftEnabled and cfg.weaponRight or nil)
                emit({event='applied',frame=frame,time=now,phase='render',avatar=actor.id,world=actor.worldLabel,
                    target=cfg.target.name,source=cfg.sourceRight.name,reference=cfg.originalMount.name,
                    axisRegistration=cfg.axisRegistration,originalLocal=original,rotationMode='native-world',
                    worldUnits=#membership[actor.world].units,modelResource=model.spec.resource,
                    modelRefreshes=self.stats.modelRefreshes-modelRefreshes,
                    consumerRefreshes=self.stats.consumerRefreshes-consumerRefreshes,
                    nativeRight=matrix(u,cfg.nativeRight.index,true),sourceRight=source,
                    equivalentRight=equivalent,beforeWorld=native,desiredWorld=desired,actualWorld=actual,
                    localReadbackError=difference(matrix(u,cfg.target.index,false),written),
                    worldReadbackError=difference(actual,desired),weaponWorldScale=nativeScale,
                    weaponResource=leftResult and leftResult.weaponResource,
                    rightWristToMarker=rightMarker and relative(equivalent,compose(desired,rightMarker)),
                    sourceLeft=sourceLeft,nativeLeft=nativeLeft,leftWrite=leftResult~=nil,
                    predictedLeftDistance=leftResult and distance(sourceLeft,leftResult.target),
                    palmSurfaceCalibrated=false})
                observe_consumers(actor,sourceLeft,nativeLeft,actual,membership,frame)
            end
        end)
        if not ok then
            self.disabled=true
            if record then
                local restored,result=pcall(restore,record,membership,true)
                if restored then
                    for i=#self.pending,1,-1 do if self.pending[i]==record then table.remove(self.pending,i) end end
                end
                emit({event='rollback',avatar=actor.id,verified=restored and result=='restored',reason=tostring(result)},true)
            end
            emit({event='disabled',avatar=actor.id,reason=tostring(why)},true)
        end
    end
    function self:tick(phase, frame, now)
        if self.stopped then return end
        self.phase=phase
        assert(phase=='update' or phase=='render','unknown_phase')
        -- Match the working B19/B20 lifetime: hold the write through update,
        -- restore immediately before the next render transaction or shutdown.
        if phase=='update' then
            begin_sync(frame,now)
            if self.syncFrame==frame then capture_sync('update',self.monitored,members(),frame,now) end
            return
        end
        local membership=members()
        begin_sync(frame,now)
        capture_sync('render_input',self.monitored,membership,frame,now)
        self:release(membership)
        if self.disabled then return end
        local rescanned=not self.lastScan or now<self.lastScan or now-self.lastScan>=cfg.scanSeconds
        if rescanned then scan(membership,now) end
        local diagnostic=not self.lastLog or now<self.lastLog or now-self.lastLog>=cfg.logSeconds
        local selected,reasons=matching_actors(membership);local active=0
        for actor,model in pairs(selected) do
            if not self.disabled then apply(actor,model,membership,frame,now,diagnostic);active=active+1 end
        end
        self.monitored=selected
        capture_sync('render_output',selected,membership,frame,now)
        if self.disabled then self:release(membership) end
        local status=active>0 and 'active' or 'waiting_for_unique_visible_test01'
        if status~=self.lastStatus then
            emit({event='status',status=status,frame=frame,actors=#self.actors,models=#self.models,
                consumers=#self.consumers},true)
            self.lastStatus=status
        end
        if active==0 then
            self.stats.skipped=self.stats.skipped+1
            if rescanned then emit({event='waiting',frame=frame,actors=#self.actors,models=#self.models,
                consumers=#self.consumers,reasons=reasons}) end
        end
        if diagnostic then self.lastLog=now end
    end
    function self:stop(reason)
        if self.stopped then return end
        self.phase='shutdown';self:release(members());self.stopped=true
        emit({event='complete',reason=reason or 'shutdown',stats=self.stats,pendingRestores=#self.pending,
            disabled=self.disabled},true)
    end
    emit({event='loaded',version=M.VERSION,writePhase='render',restorePhase='before_render_and_shutdown',
        target='attach_hand_r',originalReference=cfg.originalMount.name,axisRegistration=cfg.axisRegistration,
        writePolicy='position_only_preserve_native_aim',discovery='B19_B20_all_worlds_all_units',
        refreshOrder='avatar_model_weapon_components',
        leftMode=leftEnabled and 'source_arm_to_weapon_self_ik_left' or 'foregrip_observation_only',
        mountOutOfRangePolicy='skip_frame_retry_without_setters',
        leftOutputMode=cfg.leftGrip and cfg.leftGrip.outputs and 'unanimated_reference_children' or 'animated_source_nodes',
        bodyMode=cfg.bodySync and cfg.bodySync.enabled and cfg.bodySync.mode or 'observation_only',
        rigExpectedNodes=cfg.avatar.count,
        attachmentCount=#(cfg.attachments or {}),headDescendants=false,
        syncMode=cfg.sync and cfg.sync.enabled and 'update_render_input_render_output' or 'off',
        physics='separate_addon',palmSurfaceCalibrated=false},true)
    return self
end

return M
