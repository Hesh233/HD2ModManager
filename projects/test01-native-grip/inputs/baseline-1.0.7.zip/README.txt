B23-LR-M 1.0.7 多武器与持物挂点整合工程（可直接安装）

本 ZIP 可直接导入管理器并启用；应识别一个模组、两个补丁组。停用旧 B23-R/LR 和旧多武器工程空节点。
根目录同时含 Lua patch_4 和 Avatar/Bones patch_5（各带 stream/gpu_resources），必须作为整包启用。
修改 hd2attachmentfix-B23.lua 后，运行 python repack_native_b23.py；仅需标准 Python。
输出位于 rebuilt/；本目录已有的 Lua patch_4 也同步更新，重封包保留根目录骨架补丁。
本版必须加载完整 ZIP；单独的 Lua 不包含新增输出节点。重封包不自动验证修改后的 Lua 行为。
左手目标=本枪 IK_left；GP-20 持续双手，其他副武器仅瞄准路径双手；左右手单持物品独立更新。
整合 21 个非头部挂点，含臂板与手枪收纳；保护头部子节点和原生控制器输入。

完整离线回归需原工作区的 Lua 5.1/Lupa、NumPy、B21 原生资源、B22 动画、武器清单和 Chef 源码。
保留的 tools/ 是审计源码快照；在 HD2ModManager 原工作区运行 tools/audit_native_v31_b23.py
和 tools/audit_native_v31_b23_chef.py。reports/*fixture.log 是模拟数据，不是游戏日志。
