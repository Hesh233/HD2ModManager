local M={VERSION='0.12.1'}
local function mul(a,b)
 local x,y,z,w=unpack(a);local X,Y,Z,W=unpack(b)
 return {w*X+x*W+y*Z-z*Y,w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W,w*W-x*X-y*Y-z*Z}
end
local function inv(a)return {-a[1],-a[2],-a[3],a[4]} end
local function rot(q,p)local r=mul(mul(q,{p[1],p[2],p[3],0}),inv(q));return {r[1],r[2],r[3]} end
local function relative(a,b)
 local p={};for i=1,3 do p[i]=b.p[i]-a.p[i] end
 return {p=rot(inv(a.q),p),q=mul(inv(a.q),b.q)}
end
local function compose(a,b)
 local p=rot(a.q,b.p);for i=1,3 do p[i]=p[i]+a.p[i] end
 return {p=p,q=mul(a.q,b.q)}
end
local function finite(v)return type(v)=='number' and v==v and math.abs(v)<1e12 end
local function valid(p)
 if not p then return false end
 for _,v in ipairs(p.p) do if not finite(v) then return false end end
 local n=0;for _,v in ipairs(p.q) do if not finite(v) then return false end;n=n+v*v end
 return math.abs(n-1)<.002
end
local function close(a,b)
 if not valid(a) or not valid(b) then return false end
 local d=0;for i=1,3 do d=d+(a.p[i]-b.p[i])^2 end
 local q=0;for i=1,4 do q=q+a.q[i]*b.q[i] end
 return d<.000025 and math.abs(q)>.9999 -- 5 mm and about 1.6 degrees
end
M.relative=relative;M.compose=compose;M.close=close

local function add(a,b)return {a[1]+b[1],a[2]+b[2],a[3]+b[3]}end
local function sub(a,b)return {a[1]-b[1],a[2]-b[2],a[3]-b[3]}end
local function scale(a,s)return {a[1]*s,a[2]*s,a[3]*s}end
local function dot(a,b)return a[1]*b[1]+a[2]*b[2]+a[3]*b[3]end
local function cross(a,b)return {a[2]*b[3]-a[3]*b[2],a[3]*b[1]-a[1]*b[3],a[1]*b[2]-a[2]*b[1]}end
local function length(a)return math.sqrt(dot(a,a))end
local function normal(a,fallback)local n=length(a);if n<1e-10 then return fallback or {1,0,0}end;return scale(a,1/n)end
local function qnormal(q)local n=0;for i=1,4 do n=n+q[i]*q[i]end;n=math.sqrt(n);assert(n>1e-10,'zero arm quaternion');return {q[1]/n,q[2]/n,q[3]/n,q[4]/n}end
local function axisangle(axis,angle)local s=math.sin(angle/2);return {axis[1]*s,axis[2]*s,axis[3]*s,math.cos(angle/2)}end
local function fromto(a,b)
 a=normal(a);b=normal(b);local d=math.max(-1,math.min(1,dot(a,b)))
 if d < -1+1e-10 then
  local seed=math.abs(a[1])<.8 and {1,0,0} or {0,1,0};local axis=normal(cross(a,seed));return {axis[1],axis[2],axis[3],0}
 end
 local c=cross(a,b);return qnormal({c[1],c[2],c[3],1+d})
end
local function fitframe(q,offset,secondary,direction)
 if length(direction)<1e-8 then return q end
 local swing=fromto(rot(q,offset),direction);local axis=normal(direction)
 local finish=rot(q,secondary);local start=rot(swing,finish)
 start=sub(start,scale(axis,dot(start,axis)));finish=sub(finish,scale(axis,dot(finish,axis)))
 if math.min(length(start),length(finish))<1e-8 then return qnormal(mul(swing,q))end
 start=normal(start);finish=normal(finish)
 local roll=math.atan2(dot(cross(start,finish),axis),dot(start,finish))
 return qnormal(mul(axisangle(axis,roll),mul(swing,q)))
end

-- Drive the Source-only arm from this avatar's native, post-IK hand pose.
-- Native joints, controllers and weapon transforms are read-only inputs.
function M.grip_target(grip,chain,parentScale)
 local q=qnormal(mul(grip.q,inv(chain.sourceGripRotation)))
 return {p=sub(grip.p,rot(q,scale(chain.sourceGripOffset,parentScale or 1))),q=q}
end
function M.solve_arm(root,upper,forearm,hand,parent,chain,state,dt,parentScale,desiredHandRotation)
 parentScale=parentScale or 1;assert(finite(parentScale) and parentScale>.0001,'invalid arm parent scale')
 local uq=qnormal(mul(upper.q,chain.upperCalibration));local fq=qnormal(mul(forearm.q,chain.forearmCalibration))
 local first=scale(rot(uq,chain.upperOffset),parentScale);local second=scale(rot(fq,chain.forearmOffset),parentScale)
 local l1,l2=length(first),length(second);assert(l1>1e-5 and l2>1e-5,'zero arm length')
 local ray=sub(hand.p,root.p);local distance=length(ray);local direction=normal(ray,normal(first))
 if chain.armFrame=='reference' then
  uq=fitframe(uq,chain.upperOffset,chain.hingeAxis,sub(forearm.p,upper.p))
  fq=fitframe(fq,chain.forearmOffset,chain.forearmHingeAxis,sub(hand.referencePosition or hand.p,forearm.p))
  first=scale(rot(uq,chain.upperOffset),parentScale);second=scale(rot(fq,chain.forearmOffset),parentScale)
  -- Keep the accepted arm frame. Bend the forearm within its existing plane,
  -- then swing the whole chain toward the contact. No independent axial roll
  -- is added to force every pose onto the bind pose's hinge hemisphere.
  local reach=math.max(math.abs(l1-l2)+1e-7,math.min(l1+l2-1e-7,distance))
  local plane=cross(first,second)
  if length(plane)<l1*l2*1e-5 then plane=rot(uq,chain.hingeAxis)end
  local input=math.acos(math.max(-1,math.min(1,dot(first,second)/(l1*l2))))
  local flex=math.acos(math.max(-1,math.min(1,(reach*reach-l1*l1-l2*l2)/(2*l1*l2))))
  local elbow=axisangle(normal(plane),flex-input)
  local bent=rot(elbow,second);local swing=fromto(add(first,bent),direction)
  local firstTarget=rot(swing,first)
  local rootTarget={p=root.p,q=qnormal(mul(swing,uq))}
  local midTarget={p=add(root.p,firstTarget),q=qnormal(mul(swing,mul(elbow,fq)))}
  local handTarget={p=add(root.p,add(firstTarget,rot(swing,bent))),q=qnormal(desiredHandRotation or mul(hand.q,chain.handCalibration))}
  local result={relative(parent,rootTarget),relative(rootTarget,midTarget),relative(midTarget,handTarget)}
  for _,p in ipairs(result)do p.p=scale(p.p,1/parentScale)end
  return result,math.abs(distance-reach)
 end
 local plane=cross(first,second)
 if length(plane)<l1*l2*1e-5 then plane=rot(uq,chain.hingeAxis)end
 plane=rot(fromto(add(first,second),direction),normal(plane))
 local bend=normal(cross(direction,plane))
 if state.pole then
  local previous=rot(parent.q,state.pole);previous=sub(previous,scale(direction,dot(previous,direction)))
  if length(previous)>1e-6 then
   previous=normal(previous);local cosine=math.max(-1,math.min(1,dot(previous,bend)))
   if cosine<0 and dot(first,second)/(l1*l2)>.999 then bend=scale(bend,-1);cosine=-cosine end
   local angle=math.atan2(dot(cross(previous,bend),direction),cosine)
   local limit=math.max(0,dt)*4*math.pi;angle=math.max(-limit,math.min(limit,angle))
   bend=add(scale(previous,math.cos(angle)),scale(cross(direction,previous),math.sin(angle)))
  end
 end
 state.pole=rot(inv(parent.q),bend)
 local reach=math.max(math.abs(l1-l2)+1e-7,math.min(l1+l2-1e-7,distance))
 local projection=(reach*reach+l1*l1-l2*l2)/(2*reach)
 local height=math.sqrt(math.max(0,l1*l1-projection*projection))
 local firstTarget=add(scale(direction,projection),scale(bend,height))
 local secondTarget=sub(scale(direction,reach),firstTarget)
 local swing=fromto(first,firstTarget);local axis=normal(firstTarget)
 local start=rot(swing,rot(uq,chain.hingeAxis));start=normal(sub(start,scale(axis,dot(start,axis))))
 local finish=normal(cross(firstTarget,secondTarget))
 local roll=math.atan2(dot(cross(start,finish),axis),dot(start,finish))
 local delta=qnormal(mul(axisangle(axis,roll),swing))
 local rootTarget={p=root.p,q=qnormal(mul(delta,uq))}
 local midTarget={p=add(root.p,firstTarget),q=qnormal(mul(fromto(rot(delta,second),secondTarget),mul(delta,fq)))}
 local handTarget={p=add(root.p,scale(direction,reach)),q=qnormal(mul(hand.q,chain.handCalibration))}
 local result={relative(parent,rootTarget),relative(rootTarget,midTarget),relative(midTarget,handTarget)}
 for _,p in ipairs(result)do p.p=scale(p.p,1/parentScale)end
 return result,math.abs(distance-reach)
end

local function stored9_quaternion(r)
	local a,b,c,d,e,f,g,h,i = r[1],r[4],r[7],r[2],r[5],r[8],r[3],r[6],r[9]
	local x,y,z,w,s
	if a+e+i > 0 then
		s=math.sqrt(1+a+e+i)*2; x=(h-f)/s; y=(c-g)/s; z=(d-b)/s; w=s/4
	elseif a>e and a>i then
		s=math.sqrt(math.max(0,1+a-e-i))*2; x=s/4; y=(b+d)/s; z=(c+g)/s; w=(h-f)/s
	elseif e>i then
		s=math.sqrt(math.max(0,1+e-a-i))*2; x=(b+d)/s; y=s/4; z=(f+h)/s; w=(c-g)/s
	else
		s=math.sqrt(math.max(0,1+i-a-e))*2; x=(c+g)/s; y=(f+h)/s; z=s/4; w=(d-b)/s
	end
	local n=math.sqrt(x*x+y*y+z*z+w*w)
	return x/n,y/n,z/n,w/n
end


M.quaternion=function(r)return {stored9_quaternion(r)}end
M.rotate=rot
return M
