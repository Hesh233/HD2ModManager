-- HD2-Addon: mods/hd2modmanager/attachment_fix
-- B23 test01: dynamic native mount transferred through converter wrist axes.
-- A separate pure-physics addon may run alongside this experiment.
local loader=...
assert(type(loader)=='table' and loader.loader=='Chef Shared Loader','B23 requires Chef Shared Loader')
local ArmMath=(function()
local M={VERSION='0.12.1'}
local function mul(a,b)
 local x,y,z,w=unpack(a);local X,Y,Z,W=unpack(b)
 return {w*X+x*W+y*Z-z*Y,w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W,w*W-x*X-y*Y-z*Z}
end
local function inv(a)return {-a[1],-a[2],-a[3],a[4]} end
local function rot(q,p)local r=mul(mul(q,{p[1],p[2],p[3],0}),inv(q));return {r[1],r[2],r[3]} end
local function relative(a,b)
 local p={};for i=1,3 do p[i]=b.p[i]-a.p[i] end
 return {p=rot(inv(a.q),p),q=mul(inv(a.q),b.q)}
end
local function compose(a,b)
 local p=rot(a.q,b.p);for i=1,3 do p[i]=p[i]+a.p[i] end
 return {p=p,q=mul(a.q,b.q)}
end
local function finite(v)return type(v)=='number' and v==v and math.abs(v)<1e12 end
local function valid(p)
 if not p then return false end
 for _,v in ipairs(p.p) do if not finite(v) then return false end end
 local n=0;for _,v in ipairs(p.q) do if not finite(v) then return false end;n=n+v*v end
 return math.abs(n-1)<.002
end
local function close(a,b)
 if not valid(a) or not valid(b) then return false end
 local d=0;for i=1,3 do d=d+(a.p[i]-b.p[i])^2 end
 local q=0;for i=1,4 do q=q+a.q[i]*b.q[i] end
 return d<.000025 and math.abs(q)>.9999 -- 5 mm and about 1.6 degrees
end
M.relative=relative;M.compose=compose;M.close=close

local function add(a,b)return {a[1]+b[1],a[2]+b[2],a[3]+b[3]}end
local function sub(a,b)return {a[1]-b[1],a[2]-b[2],a[3]-b[3]}end
local function scale(a,s)return {a[1]*s,a[2]*s,a[3]*s}end
local function dot(a,b)return a[1]*b[1]+a[2]*b[2]+a[3]*b[3]end
local function cross(a,b)return {a[2]*b[3]-a[3]*b[2],a[3]*b[1]-a[1]*b[3],a[1]*b[2]-a[2]*b[1]}end
local function length(a)return math.sqrt(dot(a,a))end
local function normal(a,fallback)local n=length(a);if n<1e-10 then return fallback or {1,0,0}end;return scale(a,1/n)end
local function qnormal(q)local n=0;for i=1,4 do n=n+q[i]*q[i]end;n=math.sqrt(n);assert(n>1e-10,'zero arm quaternion');return {q[1]/n,q[2]/n,q[3]/n,q[4]/n}end
local function axisangle(axis,angle)local s=math.sin(angle/2);return {axis[1]*s,axis[2]*s,axis[3]*s,math.cos(angle/2)}end
local function fromto(a,b)
 a=normal(a);b=normal(b);local d=math.max(-1,math.min(1,dot(a,b)))
 if d < -1+1e-10 then
  local seed=math.abs(a[1])<.8 and {1,0,0} or {0,1,0};local axis=normal(cross(a,seed));return {axis[1],axis[2],axis[3],0}
 end
 local c=cross(a,b);return qnormal({c[1],c[2],c[3],1+d})
end
local function fitframe(q,offset,secondary,direction)
 if length(direction)<1e-8 then return q end
 local swing=fromto(rot(q,offset),direction);local axis=normal(direction)
 local finish=rot(q,secondary);local start=rot(swing,finish)
 start=sub(start,scale(axis,dot(start,axis)));finish=sub(finish,scale(axis,dot(finish,axis)))
 if math.min(length(start),length(finish))<1e-8 then return qnormal(mul(swing,q))end
 start=normal(start);finish=normal(finish)
 local roll=math.atan2(dot(cross(start,finish),axis),dot(start,finish))
 return qnormal(mul(axisangle(axis,roll),mul(swing,q)))
end

-- Drive the Source-only arm from this avatar's native, post-IK hand pose.
-- Native joints, controllers and weapon transforms are read-only inputs.
function M.grip_target(grip,chain,parentScale)
 local q=qnormal(mul(grip.q,inv(chain.sourceGripRotation)))
 return {p=sub(grip.p,rot(q,scale(chain.sourceGripOffset,parentScale or 1))),q=q}
end
function M.solve_arm(root,upper,forearm,hand,parent,chain,state,dt,parentScale,desiredHandRotation)
 parentScale=parentScale or 1;assert(finite(parentScale) and parentScale>.0001,'invalid arm parent scale')
 local uq=qnormal(mul(upper.q,chain.upperCalibration));local fq=qnormal(mul(forearm.q,chain.forearmCalibration))
 local first=scale(rot(uq,chain.upperOffset),parentScale);local second=scale(rot(fq,chain.forearmOffset),parentScale)
 local l1,l2=length(first),length(second);assert(l1>1e-5 and l2>1e-5,'zero arm length')
 local ray=sub(hand.p,root.p);local distance=length(ray);local direction=normal(ray,normal(first))
 if chain.armFrame=='reference' then
  uq=fitframe(uq,chain.upperOffset,chain.hingeAxis,sub(forearm.p,upper.p))
  fq=fitframe(fq,chain.forearmOffset,chain.forearmHingeAxis,sub(hand.referencePosition or hand.p,forearm.p))
  first=scale(rot(uq,chain.upperOffset),parentScale);second=scale(rot(fq,chain.forearmOffset),parentScale)
  -- Keep the accepted arm frame. Bend the forearm within its existing plane,
  -- then swing the whole chain toward the contact. No independent axial roll
  -- is added to force every pose onto the bind pose's hinge hemisphere.
  local reach=math.max(math.abs(l1-l2)+1e-7,math.min(l1+l2-1e-7,distance))
  local plane=cross(first,second)
  if length(plane)<l1*l2*1e-5 then plane=rot(uq,chain.hingeAxis)end
  local input=math.acos(math.max(-1,math.min(1,dot(first,second)/(l1*l2))))
  local flex=math.acos(math.max(-1,math.min(1,(reach*reach-l1*l1-l2*l2)/(2*l1*l2))))
  local elbow=axisangle(normal(plane),flex-input)
  local bent=rot(elbow,second);local swing=fromto(add(first,bent),direction)
  local firstTarget=rot(swing,first)
  local rootTarget={p=root.p,q=qnormal(mul(swing,uq))}
  local midTarget={p=add(root.p,firstTarget),q=qnormal(mul(swing,mul(elbow,fq)))}
  local handTarget={p=add(root.p,add(firstTarget,rot(swing,bent))),q=qnormal(desiredHandRotation or mul(hand.q,chain.handCalibration))}
  local result={relative(parent,rootTarget),relative(rootTarget,midTarget),relative(midTarget,handTarget)}
  for _,p in ipairs(result)do p.p=scale(p.p,1/parentScale)end
  return result,math.abs(distance-reach)
 end
 local plane=cross(first,second)
 if length(plane)<l1*l2*1e-5 then plane=rot(uq,chain.hingeAxis)end
 plane=rot(fromto(add(first,second),direction),normal(plane))
 local bend=normal(cross(direction,plane))
 if state.pole then
  local previous=rot(parent.q,state.pole);previous=sub(previous,scale(direction,dot(previous,direction)))
  if length(previous)>1e-6 then
   previous=normal(previous);local cosine=math.max(-1,math.min(1,dot(previous,bend)))
   if cosine<0 and dot(first,second)/(l1*l2)>.999 then bend=scale(bend,-1);cosine=-cosine end
   local angle=math.atan2(dot(cross(previous,bend),direction),cosine)
   local limit=math.max(0,dt)*4*math.pi;angle=math.max(-limit,math.min(limit,angle))
   bend=add(scale(previous,math.cos(angle)),scale(cross(direction,previous),math.sin(angle)))
  end
 end
 state.pole=rot(inv(parent.q),bend)
 local reach=math.max(math.abs(l1-l2)+1e-7,math.min(l1+l2-1e-7,distance))
 local projection=(reach*reach+l1*l1-l2*l2)/(2*reach)
 local height=math.sqrt(math.max(0,l1*l1-projection*projection))
 local firstTarget=add(scale(direction,projection),scale(bend,height))
 local secondTarget=sub(scale(direction,reach),firstTarget)
 local swing=fromto(first,firstTarget);local axis=normal(firstTarget)
 local start=rot(swing,rot(uq,chain.hingeAxis));start=normal(sub(start,scale(axis,dot(start,axis))))
 local finish=normal(cross(firstTarget,secondTarget))
 local roll=math.atan2(dot(cross(start,finish),axis),dot(start,finish))
 local delta=qnormal(mul(axisangle(axis,roll),swing))
 local rootTarget={p=root.p,q=qnormal(mul(delta,uq))}
 local midTarget={p=add(root.p,firstTarget),q=qnormal(mul(fromto(rot(delta,second),secondTarget),mul(delta,fq)))}
 local handTarget={p=add(root.p,scale(direction,reach)),q=qnormal(mul(hand.q,chain.handCalibration))}
 local result={relative(parent,rootTarget),relative(rootTarget,midTarget),relative(midTarget,handTarget)}
 for _,p in ipairs(result)do p.p=scale(p.p,1/parentScale)end
 return result,math.abs(distance-reach)
end

local function stored9_quaternion(r)
	local a,b,c,d,e,f,g,h,i = r[1],r[4],r[7],r[2],r[5],r[8],r[3],r[6],r[9]
	local x,y,z,w,s
	if a+e+i > 0 then
		s=math.sqrt(1+a+e+i)*2; x=(h-f)/s; y=(c-g)/s; z=(d-b)/s; w=s/4
	elseif a>e and a>i then
		s=math.sqrt(math.max(0,1+a-e-i))*2; x=s/4; y=(b+d)/s; z=(c+g)/s; w=(h-f)/s
	elseif e>i then
		s=math.sqrt(math.max(0,1+e-a-i))*2; x=(b+d)/s; y=s/4; z=(f+h)/s; w=(c-g)/s
	else
		s=math.sqrt(math.max(0,1+i-a-e))*2; x=(c+g)/s; y=(f+h)/s; z=s/4; w=(d-b)/s
	end
	local n=math.sqrt(x*x+y*y+z*z+w*w)
	return x/n,y/n,z/n,w/n
end


M.quaternion=function(r)return {stored9_quaternion(r)}end
M.rotate=rot
return M

end)()
local Transfer=(function()
-- B23 opt-in experiment, separate from the production physics/attachment addons.
-- The converter supplies the wrist AXIS registration, not a palm-surface fit.
-- Position = rigid(Source wrist) * sourceToNativeAxes * animated original mount local.
-- B19/B20 write path: preserve native aim, refresh model -> gun -> components.
-- IK_right is observed. The left Source arm follows the held weapon's own IK_left marker.
-- Engine matrices and IdString values are temporary: retain numeric copies only.
local M = {VERSION = '1.0.8'}
local unpack = unpack or table.unpack

local function finite(x)
    return type(x) == 'number' and x == x and math.abs(x) < 1e10
end
local function copy(a)
    local b = {}; for i, v in ipairs(a) do b[i] = v end; return b
end
local function difference(a, b)
    local d = 0
    for i = 1, 12 do d = math.max(d, math.abs(a[i] - b[i])) end
    return d
end
local function distance(a, b)
    local d = 0
    for i = 10, 12 do d = d + (a[i] - b[i]) ^ 2 end
    return math.sqrt(d)
end
local function compose(a, b)
    local r = {}
    for c = 0, 2 do
        for j = 1, 3 do
            r[c * 3 + j] = a[j]*b[c*3+1] + a[j+3]*b[c*3+2] + a[j+6]*b[c*3+3]
        end
    end
    for j = 1, 3 do r[9+j] = a[j]*b[10] + a[j+3]*b[11] + a[j+6]*b[12] + a[9+j] end
    return r
end
local function inverse_vector(m, v)
    local a,b,c,d,e,f,g,h,i = m[1],m[4],m[7],m[2],m[5],m[8],m[3],m[6],m[9]
    local det = a*(e*i-f*h) - b*(d*i-f*g) + c*(d*h-e*g)
    assert(finite(det) and math.abs(det) > 1e-8, 'singular_parent')
    return {((e*i-f*h)*v[1] + (c*h-b*i)*v[2] + (b*f-c*e)*v[3])/det,
            ((f*g-d*i)*v[1] + (a*i-c*g)*v[2] + (c*d-a*f)*v[3])/det,
            ((d*h-e*g)*v[1] + (b*g-a*h)*v[2] + (a*e-b*d)*v[3])/det}
end
local function relative(a, b)
    local r = {}
    for c = 0, 2 do
        local v = inverse_vector(a, {b[3*c+1], b[3*c+2], b[3*c+3]})
        for j = 1, 3 do r[3*c+j] = v[j] end
    end
    local v = inverse_vector(a, {b[10]-a[10], b[11]-a[11], b[12]-a[12]})
    for j = 1, 3 do r[9+j] = v[j] end
    return r
end
local function rigid(m)
    local r, scales = copy(m), {}
    for c = 0, 2 do
        local n = 0; for j = 1, 3 do n = n + m[3*c+j]^2 end
        n = math.sqrt(n); assert(finite(n) and n > 1e-6, 'invalid_axis_scale')
        scales[c+1] = n
        for j = 1, 3 do r[3*c+j] = m[3*c+j]/n end
    end
    for a = 0, 1 do for b = a+1, 2 do
        local dot = 0; for j = 1, 3 do dot = dot + r[3*a+j]*r[3*b+j] end
        assert(math.abs(dot) < 0.002, 'sheared_wrist_or_mount')
    end end
    local det = r[1]*(r[5]*r[9]-r[6]*r[8]) - r[4]*(r[2]*r[9]-r[3]*r[8])
        + r[7]*(r[2]*r[6]-r[3]*r[5])
    assert(det > 0.998 and det < 1.002, 'mirrored_wrist_or_mount')
    return r, scales
end
local function angle(a, b)
    local x, y = rigid(a), rigid(b)
    local trace = 0; for i = 1, 9 do trace = trace + x[i]*y[i] end
    return math.deg(math.acos(math.max(-1, math.min(1, (trace-1)/2))))
end
local function quote(s)
    return '"' .. tostring(s):gsub('[%z\1-\31\\"]', function(c)
        if c == '\\' then return '\\\\' elseif c == '"' then return '\\"' end
        return string.format('\\u%04x', string.byte(c))
    end) .. '"'
end
local function json(v)
    if v == nil then return 'null' end
    if type(v) == 'boolean' then return tostring(v) end
    if type(v) == 'number' then assert(finite(v), 'nonfinite_log'); return string.format('%.12g', v) end
    if type(v) == 'string' then return quote(v) end
    assert(type(v) == 'table', 'invalid_log_value')
    local out = {}
    if #v > 0 then
        for i = 1, #v do out[i] = json(v[i]) end
        return '[' .. table.concat(out, ',') .. ']'
    end
    local keys = {}; for k in pairs(v) do keys[#keys+1] = k end; table.sort(keys)
    for _, k in ipairs(keys) do out[#out+1] = quote(k) .. ':' .. json(v[k]) end
    return '{' .. table.concat(out, ',') .. '}'
end

function M.new(S, cfg, logger, ArmMath)
    local U, X, W, A = S.Unit, S.Matrix4x4, S.World, S.Application
    assert(U and X and W and A and S.IdString64, 'engine_api_missing')
    for _, name in ipairs({'alive','resource_name','num_scene_graph_items','has_node','node',
                           'scene_graph_parent','local_pose','world_pose','set_local_pose'}) do
        assert(type(U[name]) == 'function', 'unit_api_missing:' .. name)
    end
    assert(type(W.units)=='function' and type(W.update_unit)=='function'
        and type(A.worlds)=='function' and type(A.string_to_id32)=='function'
        and type(X.to_elements)=='function' and type(X.from_elements)=='function'
        and type(S.IdString64.to_hex)=='function', 'pose_api_missing')
    assert(cfg.target.name == 'attach_hand_r' and cfg.target.index == 84, 'write_allowlist')
    assert(cfg.originalMount.index ~= cfg.target.index and cfg.originalMount.parent == cfg.target.parent,
        'independent_original_reference_required')
    assert(cfg.sourceRight.name:match('_r_hand$'), 'source_wrist_required')
    assert(cfg.axisRegistration == 'converter-reference-rotation', 'axis_registration_required')
    rigid(cfg.rightAxes); rigid(cfg.leftAxes)
    local leftEnabled=cfg.leftGrip and cfg.leftGrip.enabled==true
    for _, row in ipairs(cfg.attachments or {}) do
        assert(row.node.index~=cfg.target.index and row.native.name~='head', 'attachment_allowlist')
        assert(row.node.name~='weapon_aim' and row.node.name~='aim_weapon'
            and row.node.name~='boss_aim' and row.node.name~='climb_ref'
            and row.node.name~='attach_cam_1', 'controller_input_protected')
        rigid(row.axes)
    end
    if leftEnabled then
        assert(ArmMath and type(ArmMath.solve_arm)=='function' and type(ArmMath.quaternion)=='function',
            'existing_arm_math_required')
        local nodes=cfg.leftGrip.nodes
        assert(#nodes==4,'left_arm_allowlist')
        local outputs=cfg.leftGrip.outputs
        if outputs then
            assert(#outputs==3 and outputs[3].index==cfg.sourceLeft.index,'left_output_allowlist')
            for i=1,3 do assert(outputs[i].parent==nodes[i+1].index,'left_output_reference_parent') end
        else assert(nodes[4].index==cfg.sourceLeft.index,'left_arm_allowlist') end
        for i=2,4 do assert(nodes[i].parent==nodes[i-1].index,'left_arm_direct_chain') end
        assert(nodes[2].name:match('_l_shoulder$')
            and nodes[3].name:match('_l_elbow$'),'left_source_chain_required')
        local targets=cfg.leftGrip.weaponTargets
        assert(type(targets)=='table','left_weapon_targets_required')
        local count=0
        for id,row in pairs(targets) do
            count=count+1
            assert(type(id)=='string' and #id==16
                and (row.rootName=='boss' or row.rootName=='skeleton'),
                'left_target_identity:'..tostring(id))
            for _,key in ipairs({'rootToIKLeft','rootToIKRight'}) do
                local m=row[key]
                if key=='rootToIKLeft' or m~=nil then
                    assert(type(m)=='table' and #m==12,'left_target_matrix:'..key..':'..tostring(id))
                    for j=1,12 do assert(finite(m[j]),'left_target_finite:'..key..':'..tostring(id)) end
                    rigid(m)
                end
            end
        end
        assert(count>0,'left_weapon_targets_empty')
    end
    local performance=cfg.performance or {}
    if cfg.leftGrip and cfg.leftGrip.intent and cfg.leftGrip.intent.enabled then
        local intent=cfg.leftGrip.intent
        local function thresholds(enter,leave)
            assert(finite(enter) and finite(leave) and enter>0 and enter<=leave and leave<=.5,'invalid_intent_thresholds')
        end
        thresholds(intent.primaryEnterMetres,intent.primaryLeaveMetres)
        thresholds(intent.sidearmEnterMetres,intent.sidearmLeaveMetres)
        for id,row in pairs(intent.weaponThresholds or {}) do
            assert(cfg.leftGrip.weaponTargets[id],'unknown_intent_weapon')
            thresholds(row.enterMetres,row.leaveMetres)
        end
    end
    if cfg.previewGuard and cfg.previewGuard.enabled then
        local n=cfg.previewGuard.minimumWorldUnits
        assert(finite(n) and n%1==0 and n>0 and n<=10000,'invalid_preview_guard')
    end
    local self = {validation={},leftIntent={},pending={}, actors={}, models={}, consumers={}, sequence=0, identities={},
        monitored={},syncFrame=nil,lastSync=nil,
        lastScan=nil, lastLog=nil, lastStatus=nil, disabled=false, stopped=false, records=0,
        stats={writes=0, readbacks=0, restores=0, freshPreserved=0, skipped=0,mountSkipped=0,
            modelRefreshes=0, consumerRefreshes=0, refreshErrors=0,
            leftWrites=0,leftNodeWrites=0,leftRestores=0,leftFreshPreserved=0,leftSkipped=0,
            syncSamples=0,syncErrors=0,bodyNodeWrites=0,bodyRestores=0,bodyFreshPreserved=0,
            attachmentWrites=0,attachmentRestores=0,attachmentFreshPreserved=0}}
    local function emit(row, urgent)
        if self.records >= cfg.maxRecords and not urgent then return end
        row.variant = cfg.variant
        self.records = self.records + 1; logger(json(row))
    end
    local function resource(u)
        local id = S.IdString64.to_hex(U.resource_name(u))
        assert(type(id)=='string' and id:match('^%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x$'), 'resource_id')
        return id:lower()
    end
    local function matrix(u, n, world)
        local r = {X.to_elements((world and U.world_pose or U.local_pose)(u, n+1))}
        assert(#r == 12, 'matrix_size')
        for _, v in ipairs(r) do assert(finite(v), 'matrix_nonfinite') end
        return r
    end
    local function verify_node(u,node,parents)
        local id=A.string_to_id32(node.name)
        assert(U.has_node(u,id)==true and U.node(u,id)==node.index+1,'node_identity:'..node.name)
        if parents then assert(U.scene_graph_parent(u,node.index+1)==node.parent+1,'node_parent:'..node.name) end
    end
    local function identity(item)
        local u, spec = item.unit, item.spec
        assert(U.alive(u)==true,'unit_dead')
        local count=U.num_scene_graph_items(u)
        assert(count==spec.count,'node_count:'..spec.kind..':actual='..tostring(count)..':expected='..spec.count)
        assert(resource(u)==spec.resource, 'resource_changed')
        if performance.cacheIdentity and self.validation[u]==spec then return end
        for _, node in ipairs(spec.nodes) do
            local id = A.string_to_id32(node.name)
            assert(U.has_node(u,id)==true and U.node(u,id)==node.index+1, 'node_identity:'..node.name)
            if node.parent ~= nil and (spec.kind=='avatar' or spec.kind=='model') then
                local parent = U.scene_graph_parent(u,node.index+1)
                -- B21 live captures show nil parents for externally linked model bones.
                -- Their five world poses must still match one Avatar before any write.
                local externalModelParent = spec.kind=='model' and parent==nil
                assert(externalModelParent or parent==node.parent+1, 'node_parent:'..node.name)
            end
        end
        if performance.cacheIdentity then self.validation[u]=spec end
    end
    local function visible(u)
        if not (U.num_meshes and U.mesh and S.Mesh and S.Mesh.visibility) then return nil end
        local count=U.num_meshes(u)
        if not finite(count) or count<1 or count>128 then return nil end
        local unknown=false
        for i=1,count do
            local value=S.Mesh.visibility(U.mesh(u,i))
            if value==true then return true elseif value~=false then unknown=true end
        end
        if unknown then return nil end
        return false
    end
    -- B19/B20 enumerated every world and every Unit. Prefix limits miss live
    -- mission actors while still admitting the much smaller preview worlds.
    local function members()
        local result, worlds = {}, A.worlds() or {}
        for wi, world in ipairs(worlds) do
            local ok, units = pcall(W.units, world)
            if ok then
                local set = {}; result[world] = {units=units or {}, set=set, label=wi}
                for _, u in ipairs(units or {}) do set[u]=true end
            end
        end
        return result
    end
    local function present(item, membership)
        return membership[item.world] and membership[item.world].set[item.unit] == true and U.alive(item.unit)==true
    end
    local function refresh_models(world, membership, actor)
        for _, item in ipairs(self.models) do
            if item.world==world and present(item,membership) and (not performance.scopedRefresh
                or not actor or self.modelOwners[item.unit]==actor.unit) then
                local ok,why=pcall(function()
                    identity(item)
                    if visible(item.unit)~=false then
                        W.update_unit(world,item.unit)
                        self.stats.modelRefreshes=self.stats.modelRefreshes+1
                    end
                end)
                if not ok then
                    self.stats.refreshErrors=self.stats.refreshErrors+1
                    if self.stats.refreshErrors<=8 then
                        emit({event='refresh_unavailable',kind='model',resource=item.spec.resource,reason=tostring(why)})
                    end
                end
            end
        end
    end
    local function refresh_consumers(world, membership, actor)
        for _, item in ipairs(self.consumers) do
            if item.world==world and present(item,membership) then
                -- B19/B20 refreshes every recognized existing equipment graph
                -- in the affected world, with gun roots before components.
                local ok,why=pcall(function()
                    identity(item)
                    if visible(item.unit)~=false then
                        if performance.scopedRefresh and actor then
                            local root=matrix(item.unit,item.spec.root,true)
                            local right=matrix(actor.unit,cfg.target.index,true)
                            local left=matrix(actor.unit,cfg.sourceLeft.index,true)
                            if math.min(distance(root,right),distance(root,left))>(performance.refreshRadius or 1.5) then return end
                        end
                        if item.spec.kind=='linked_item' then
                            local near=false
                            for _, actor in ipairs(self.actors) do
                                if actor.world==world and present(actor,membership) then
                                    near=near or distance(matrix(item.unit,item.spec.root,true),
                                        matrix(actor.unit,cfg.target.index,true))<=cfg.consumerRadius
                                end
                            end
                            if not near then return end
                        end
                        W.update_unit(world,item.unit)
                        self.stats.consumerRefreshes=self.stats.consumerRefreshes+1
                    end
                end)
                if not ok then
                    self.stats.refreshErrors=self.stats.refreshErrors+1
                    if self.stats.refreshErrors<=8 then
                        emit({event='refresh_unavailable',kind=item.spec.kind,resource=item.spec.resource,reason=tostring(why)})
                    end
                end
            end
        end
    end
    local function restore(record, membership, force)
        local item = record.actor
        if not present(item,membership) then return 'gone' end
        local valid = pcall(identity,item)
        if not valid then return 'layout_changed' end
        local changed=false
        local function restore_node(index,before,written,left)
            local current=matrix(item.unit,index,false)
            if not force and difference(current,written)>cfg.localTolerance then
                local key=left=='attachment' and 'attachmentFreshPreserved' or left=='body' and 'bodyFreshPreserved' or left and 'leftFreshPreserved' or 'freshPreserved'
                self.stats[key]=self.stats[key]+1
                return
            end
            U.set_local_pose(item.unit,index+1,X.from_elements(unpack(before)))
            assert(difference(matrix(item.unit,index,false),before)<=cfg.localTolerance,'restore_readback')
            local key=left=='attachment' and 'attachmentRestores' or left=='body' and 'bodyRestores' or left and 'leftRestores' or 'restores';self.stats[key]=self.stats[key]+1
            changed=true
        end
        if record.written then restore_node(cfg.target.index,record.before,record.written,false) end
        for _,row in ipairs(record.left or {}) do
            if row.touched then restore_node(row.index,row.before,row.written,true) end
        end
        for _,row in ipairs(record.body or {}) do
            if row.touched then restore_node(row.index,row.before,row.written,'body') end
        end
        for _,row in ipairs(record.attachments or {}) do
            if row.touched then restore_node(row.index,row.before,row.written,'attachment') end
        end
        if changed then
            W.update_unit(item.world,item.unit)
            refresh_models(item.world,membership,item)
            refresh_consumers(item.world,membership,item)
        end
        return changed and 'restored' or 'fresh_animation_preserved'
    end
    function self:release(membership)
        local pending = self.pending; self.pending = {}
        for _, record in ipairs(pending) do
            local ok, result = pcall(restore,record,membership,false)
            if not ok then
                self.pending[#self.pending+1]=record; self.disabled=true
                emit({event='restore_failed',avatar=record.actor.id,reason=tostring(result)},true)
            elseif record.diagnostic or result=='layout_changed' then
                emit({event='release',avatar=record.actor.id,result=result,phase=self.phase},true)
            end
        end
    end
    -- Reuse B19/B20 marker-based equipment discovery. These dynamic signatures
    -- authorize graph refresh/observation only, never setters or new links.
    local function equipment_spec(u, id, count)
        if performance.strictConsumers and not (cfg.allowedConsumers and cfg.allowedConsumers[id]) then return nil end
        if count<3 or count>192 then return nil end
        local function node(name)
            local hash=A.string_to_id32(name)
            if U.has_node(u,hash)~=true then return nil end
            local n=U.node(u,hash)
            assert(finite(n) and n%1==0 and n>=1 and n<=count,'consumer_node_index:'..name)
            return {name=name,index=n-1}
        end
        local left,right=node('IK_left'),node('IK_right')
        local supported=cfg.leftGrip and cfg.leftGrip.weaponTargets[id]
        if supported and left then
            local root=node(supported.rootName)
            if not root then return nil end
            local nodes={root,left};if right then nodes[#nodes+1]=right end
            for _, name in ipairs(supported.linkNodes or {}) do
                local extra=node(name)
                if extra and extra.index~=root.index then nodes[#nodes+1]=extra end
            end
            return {kind='weapon',resource=id,count=count,nodes=nodes,root=root.index,order=0}
        end
        if left and right then
            local root=node('boss') or node('skeleton') or right
            return {kind='weapon',resource=id,count=count,nodes={left,right,root},root=root.index,order=0}
        end
        local skeleton,mesh=node('skeleton'),node('game_mesh')
        if not mesh then return nil end
        if not skeleton then
            -- G-16 and other rigid hand items have game_mesh/pivot but no
            -- skeleton or IK markers. They still consume the right hand link.
            local pivot=node('pivot')
            if not pivot then return nil end
            return {kind='linked_item',resource=id,count=count,nodes={mesh,pivot},root=pivot.index,order=2}
        end
        for _,row in ipairs({{'IK_left','weapon_grip'},{'muzzle','weapon_muzzle'},
                             {'attach_offset','weapon_optic'},{'bullet_01','weapon_magazine'},
                             {'laser','weapon_underbarrel'}}) do
            local marker=node(row[1])
            if marker then
                return {kind=row[2],resource=id,count=count,nodes={skeleton,mesh,marker},
                    root=skeleton.index,order=1}
            end
        end
        -- Shells, revolver parts and carried objects need a cache refresh too;
        -- IK/muzzle/bullet_01 is not a complete equipment signature. No setters
        -- are authorized on these Units, and refresh is limited to nearby items.
        local root=node('boss') or node('root') or skeleton
        return {kind='linked_item',resource=id,count=count,nodes={skeleton,mesh,root},
            root=root.index,order=2}
    end
    local function scan(membership, now)
        self.actors={}; self.models={}; self.consumers={}
        local identities,seen,worlds,rejected = {},{},{},{}
        for world, group in pairs(membership) do
            local summary={world=group.label,units=#group.units,actors=0,models=0,consumers=0}
            worlds[#worlds+1]=summary
            local function consider(u)
                if seen[u] or not group.set[u] then return end
                seen[u]=true
                local ok,why=pcall(function()
                    if U.alive(u)~=true then return end
                    local count=U.num_scene_graph_items(u)
                    if count<cfg.minNodes or count>cfg.maxNodes then return end
                    local id=resource(u)
                    local spec = id==cfg.avatar.resource and cfg.avatar or cfg.models[id] or cfg.consumers[id]
                        or equipment_spec(u,id,count)
                    if not spec then return end
                    local item={unit=u,world=world,worldLabel=group.label,spec=spec}
                    identity(item)
                    local previous=self.identities[u]
                    if previous and previous.world==world and previous.resource==id then item.id=previous.id
                    else self.sequence=self.sequence+1;item.id=self.sequence end
                    identities[u]={id=item.id,world=world,resource=id}
                    if spec.kind=='avatar' then self.actors[#self.actors+1]=item;summary.actors=summary.actors+1
                    elseif spec.kind=='model' then self.models[#self.models+1]=item;summary.models=summary.models+1
                    else self.consumers[#self.consumers+1]=item;summary.consumers=summary.consumers+1 end
                end)
                if not ok then
                    local reason=tostring(why);rejected[reason]=(rejected[reason] or 0)+1
                end
            end
            if type(W.units_by_resource)=='function' then
                local ok,avatars=pcall(W.units_by_resource,world,'content/fac_helldivers/cha_avatar/avatar_helldiver')
                if ok then for _,u in ipairs(avatars or {}) do consider(u) end
                else rejected.avatar_query=(rejected.avatar_query or 0)+1 end
            end
            for _,u in ipairs(group.units) do consider(u) end
        end
        -- Gun graph first, then its separate foregrip graph.
        table.sort(self.consumers,function(a,b) return a.spec.order<b.spec.order end)
        self.identities=identities;self.lastScan=now
        table.sort(worlds,function(a,b) return a.world<b.world end)
        emit({event='scan',time=now,worlds=worlds,actors=#self.actors,models=#self.models,
            consumers=#self.consumers,rejected=rejected,scope='all_worlds_all_units'})
    end
    local function matching_actors(membership)
        local selected,blocked={},{}
        self.modelOwners={}
        local reasons={hidden=0,poseMismatch=0,ambiguous=0,unavailable=0}
        for _, model in ipairs(self.models) do
            local ok, matches=pcall(function()
                if not present(model,membership) then return {} end
                identity(model);if not visible(model.unit) then reasons.hidden=reasons.hidden+1;return {} end
                local poses={}
                for i,row in ipairs(model.spec.nodes) do poses[i]=matrix(model.unit,row.index,true) end
                local found={}
                for _, actor in ipairs(self.actors) do
                    if actor.world==model.world and present(actor,membership) then
                        local good=pcall(function()
                            identity(actor)
                            for i,row in ipairs(model.spec.nodes) do
                                assert(difference(poses[i],matrix(actor.unit,row.avatarIndex,true))<=cfg.matchTolerance,
                                    'model_avatar_pose_mismatch')
                            end
                        end)
                        if good then found[#found+1]=actor else reasons.poseMismatch=reasons.poseMismatch+1 end
                    end
                end
                return found
            end)
            -- Geometric agreement gates this experiment, not a claim of API ownership.
            if ok and #matches==1 then selected[matches[1]]=model;self.modelOwners[model.unit]=matches[1].unit
            elseif ok and #matches>1 then
                reasons.ambiguous=reasons.ambiguous+1
                for _,actor in ipairs(matches) do blocked[actor]=true end
            elseif not ok then reasons.unavailable=reasons.unavailable+1 end
        end
        for actor in pairs(blocked) do selected[actor]=nil end
        return selected,reasons
    end
    -- Observe both the live native skeleton and the added Source hierarchy.
    -- The observer itself does not write poses; output nodes may inherit native parents.
    local function begin_sync(frame,now)
        local sync=cfg.sync
        if not sync or not sync.enabled or not next(self.monitored) then return end
        if self.stats.syncSamples>=sync.maxSamples or self.syncFrame==frame then return end
        if self.lastSync and now>=self.lastSync and now-self.lastSync<sync.seconds then return end
        self.lastSync=now;self.syncFrame=frame;self.stats.syncSamples=self.stats.syncSamples+1
    end
    local function capture_sync(phase,selected,membership,frame,now)
        if self.syncFrame~=frame then return end
        for actor,model in pairs(selected) do
            local ok,why=pcall(function()
                if not present(actor,membership) or not present(model,membership) then return end
                identity(actor);identity(model)
                if not visible(model.unit) then return end
                local nodes={};local maximum,position=0,0
                for _,pair in ipairs(cfg.sync.pairs) do
                    verify_node(actor.unit,pair.native,false);verify_node(actor.unit,pair.source,false)
                    local native=matrix(actor.unit,pair.native.index,true)
                    local source=matrix(actor.unit,pair.source.index,true)
                    local equivalent=compose(rigid(source),pair.axes)
                    local node
                    for _,n in ipairs(model.spec.observeNodes or {}) do if n.driver==pair.name then node=n end end
                    assert(node,'sync_model_node_missing:'..pair.name)
                    local hash=A.string_to_id32(node.name)
                    assert(U.has_node(model.unit,hash)==true and U.node(model.unit,hash)==node.index+1,
                        'sync_model_identity:'..node.name)
                    local consumed=matrix(model.unit,node.index,true)
                    local error=difference(source,consumed)
                    maximum=math.max(maximum,error);position=math.max(position,distance(source,consumed))
                    nodes[pair.name]={nativeWorld=native,sourceWorld=source,modelWorld=consumed,
                        nativeLocal=matrix(actor.unit,pair.native.index,false),
                        sourceLocal=matrix(actor.unit,pair.source.index,false),
                        nativeParent=U.scene_graph_parent(actor.unit,pair.native.index+1) or 'nil',
                        sourceParent=U.scene_graph_parent(actor.unit,pair.source.index+1) or 'nil',
                        nativeSourceAngle=angle(native,equivalent),modelMatrixError=error}
                    if pair.reference then
                        verify_node(actor.unit,pair.reference,false)
                        nodes[pair.name].animationReferenceWorld=matrix(actor.unit,pair.reference.index,true)
                        nodes[pair.name].animationReferenceLocal=matrix(actor.unit,pair.reference.index,false)
                    end
                end
                local owned=0
                for _,record in ipairs(self.pending) do if record.actor.unit==actor.unit then
                    for _,row in ipairs(record.left or {}) do
                        if row.touched and difference(matrix(actor.unit,row.index,false),row.written)<=cfg.localTolerance then
                            owned=owned+1
                        end
                    end
                end end
                emit({event='sync',sample=self.stats.syncSamples,phase=phase,frame=frame,time=now,
                    avatar=actor.id,world=actor.worldLabel,modelResource=model.spec.resource,nodes=nodes,
                    aimWorld=matrix(actor.unit,cfg.sync.aim.index,true),
                    rightMountWorld=matrix(actor.unit,cfg.target.index,true),leftLocalsOwned=owned,
                    modelMaxMatrixError=maximum,modelMaxPositionError=position,
                    ownership='last_unique_geometric_match_revalidated',cameraSample=false,
                    upperBodyWrites=cfg.bodySync and cfg.bodySync.enabled or false})
            end)
            if not ok then
                self.stats.syncErrors=self.stats.syncErrors+1
                if self.stats.syncErrors<=8 then emit({event='sync_unavailable',phase=phase,frame=frame,
                    avatar=actor.id,reason=tostring(why)}) end
            end
        end
    end
    local function consumer_node(item,name)
        for _,node in ipairs(item.spec.nodes) do if node.name==name then return node.index end end
        error('consumer_marker_missing:'..name)
    end
    local function weapon_static(resource,key)
        local targets=cfg.leftGrip and cfg.leftGrip.weaponTargets
        local row=targets and targets[resource]
        if resource then return row and row[key] end
        if key=='rootToIKRight' then return cfg.weaponRight end
        return cfg.weaponForegripLeft
    end
    local function plan_left(actor,target,nativeBefore,nativeLeft,membership,attachmentSnapshots)
        local c=cfg.leftGrip
        for _,node in ipairs(c.nodes) do verify_node(actor.unit,node,true) end
        for _,node in ipairs(c.outputs or {}) do verify_node(actor.unit,node,true) end
        local weapons={}
        local mounts={{name='attach_hand_r',pose=target}}
        for _, row in ipairs(cfg.attachments or {}) do
            if row.node.name=='attach_weapon' then
                mounts[#mounts+1]={name=row.node.name,pose=matrix(actor.unit,row.node.index,true)}
            end
        end
        for _,item in ipairs(self.consumers) do
            local supported=c.weaponTargets[item.spec.resource]
            if item.world==actor.world and supported and present(item,membership) then
                local ok,linked=pcall(function()
                    identity(item);if visible(item.unit)==false then return nil end
                    local names=supported.linkNodes or {supported.rootName}
                    for _,name in ipairs(names) do
                        local hash=A.string_to_id32(name)
                        if U.has_node(item.unit,hash) then
                            local pose=matrix(item.unit,U.node(item.unit,hash)-1,true)
                            for _,mount in ipairs(mounts) do
                                if distance(pose,mount.pose)<=c.linkMetres and angle(pose,mount.pose)<=c.linkDegrees then
                                    -- Sidearms use the hand-r link while aiming; the
                                    -- hip carry link must not force their free hand.
                                    -- GP-20 Ultimatum explicitly uses both links.
                                    if supported.leftPolicy~='aim_only' or mount.name=='attach_hand_r' then
                                        return {mount=mount.name,node=name}
                                    end
                                end
                            end
                        end
                    end
                end)
                if ok and linked then
                    weapons[#weapons+1]={item=item,link=linked}
                end
            end
        end
        if #weapons~=1 then self.leftIntent[actor.unit]=nil;return nil,'no_unique_supported_held_weapon' end
        local weapon=weapons[1].item
        -- 2026-11-05 user decision: the left hand always targets the held weapon's
        -- own IK_left marker, underbarrel accessories are no longer link-searched.
        local gripPose=matrix(weapon.unit,consumer_node(weapon,'IK_left'),true)
        local intent=c.intent
        if intent and intent.enabled then
            -- A TESTED pose-intent proxy, not a claim of reading engine ADS/reload flags.
            -- Reconstruct the unswapped native gun path, using this frame's animated
            -- marker relative to the actual matched link node (not static weapon bind).
            local link=weapons[1].link
            local linkPose=matrix(weapon.unit,U.node(weapon.unit,A.string_to_id32(link.node))-1,true)
            local nativeMount
            if link.mount=='attach_hand_r' then nativeMount=matrix(actor.unit,cfg.originalMount.index,true)
            else
                for _,row in ipairs(attachmentSnapshots or {}) do
                    if row.spec.node.name==link.mount then nativeMount=row.basis end
                end
            end
            if not nativeMount then return nil,'native_intent_mount_unavailable' end
            local nativeGrip=compose(nativeMount,relative(linkPose,gripPose))
            local separation=distance(nativeLeft,nativeGrip)
            local sidearm=c.weaponTargets[weapon.spec.resource].leftPolicy=='aim_only'
            local enter=sidearm and intent.sidearmEnterMetres or intent.primaryEnterMetres
            local leave=sidearm and intent.sidearmLeaveMetres or intent.primaryLeaveMetres
            local calibrated=intent.weaponThresholds and intent.weaponThresholds[weapon.spec.resource]
            if calibrated then enter,leave=calibrated.enterMetres,calibrated.leaveMetres end
            local previous=self.leftIntent[actor.unit]
            local held=previous and previous.resource==weapon.spec.resource and previous.held
            local permitted=separation<=(held and leave or enter)
            self.leftIntent[actor.unit]={resource=weapon.spec.resource,held=permitted,distance=separation,
                threshold=held and leave or enter,policy=sidearm and 'aim_pose_proxy' or 'native_hand_action_proxy'}
            if not permitted then return nil,sidearm and 'native_pose_not_two_hand_aim' or 'native_left_free_reload_or_other_action' end
        end
        local oldGrip=compose(nativeBefore,weapon_static(weapon.spec.resource,'rootToIKLeft'))
        local contact=distance(nativeLeft,oldGrip)
        local inContact=contact<=c.contactMetres and angle(nativeLeft,oldGrip)<=c.contactDegrees
        local function pose(m)
            return {p={m[10],m[11],m[12]},q=ArmMath.quaternion(rigid(m))}
        end
        local worlds,locals={},{ }
        for i,node in ipairs(c.nodes) do
            worlds[i]=matrix(actor.unit,node.index,true)
            locals[i]=matrix(actor.unit,node.index,false)
        end
        local _,parentScales=rigid(worlds[1]);local parentScale=parentScales[1]
        for i=2,3 do assert(math.abs(parentScales[i]-parentScale)<0.001,'left_parent_nonuniform_scale') end
        for i=2,4 do
            local _,scales=rigid(locals[i])
            for j=1,3 do assert(math.abs(scales[j]-1)<0.001,'left_joint_scaled') end
        end
        local root,mid,hand,parent=pose(worlds[2]),pose(worlds[3]),pose(worlds[4]),pose(worlds[1])
        local axes={p={0,0,0},q=ArmMath.quaternion(cfg.leftAxes)}
        local inverseAxes=ArmMath.relative(axes,{p={0,0,0},q={0,0,0,1}})
        local desiredHand=ArmMath.compose(pose(gripPose),inverseAxes)
        desiredHand.referencePosition=hand.p
        local chain={upperCalibration={0,0,0,1},forearmCalibration={0,0,0,1},handCalibration={0,0,0,1},
            upperOffset={locals[3][10],locals[3][11],locals[3][12]},
            forearmOffset={locals[4][10],locals[4][11],locals[4][12]},armFrame='reference',
            hingeAxis=c.hingeAxis,forearmHingeAxis=c.forearmHingeAxis}
        -- Match processor._apply_two_bone_ik's reachable interval and soft extension.
        -- Native contact is telemetry only: an unreachable target still extends the arm.
        local first,second=distance(worlds[2],worlds[3]),distance(worlds[3],worlds[4])
        local actualDistance=distance(worlds[2],gripPose)
        local minimum,maximum=math.abs(first-second)+1e-7,first+second-1e-7
        local reach=math.max(minimum,math.min(maximum,actualDistance))
        local soft=math.min(c.softDistance or 0,(maximum-minimum)*0.25)
        if soft>0 and actualDistance>maximum-soft then
            reach=maximum-soft*math.exp(-(actualDistance-(maximum-soft))/soft)
        end
        for j=1,3 do
            local direction=actualDistance>1e-8 and (gripPose[j+9]-root.p[j])/actualDistance
                or (mid.p[j]-root.p[j])/first
            desiredHand.p[j]=root.p[j]+direction*reach
        end
        local targets=ArmMath.solve_arm(root,root,mid,desiredHand,parent,chain,{},1/60,parentScale,desiredHand.q)
        local residual=math.abs(actualDistance-reach)
        local rows={};local expected=worlds[1]
        for i=1,3 do
            local before=locals[i+1];local written=copy(before)
            for col=0,2 do
                local axis={0,0,0};axis[col+1]=1
                local rotated=ArmMath.rotate(targets[i].q,axis)
                for j=1,3 do written[col*3+j]=rotated[j] end
            end
            -- The existing solver changes rotations; retain the animated bone offsets.
            for j=1,3 do assert(math.abs(targets[i].p[j]-before[j+9])<cfg.localTolerance,'left_bone_offset_changed') end
            expected=compose(expected,written)
            local output=c.outputs and c.outputs[i]
            if output then
                -- The animation still owns the private input chain. Only its
                -- unanimated named outputs receive IK deltas, held through skinning.
                rows[i]={index=output.index,before=matrix(actor.unit,output.index,false),
                    written=relative(worlds[i+1],expected),touched=false}
            else rows[i]={index=c.nodes[i+1].index,before=before,written=written,touched=false} end
        end
        return {rows=rows,target=gripPose,expected=expected,before=worlds[4],reachResidual=residual,
            nativeContactDistance=contact,nativeInContact=inContact,weapon=weapon.id,
            weaponResource=weapon.spec.resource,link=weapons[1].link}
    end
    local function plan_attachments(actor)
        local rows={}
        for _,spec in ipairs(cfg.attachments or {}) do
            verify_node(actor.unit,spec.node,true);verify_node(actor.unit,spec.native,true)
            verify_node(actor.unit,spec.source,true)
            if spec.reference then verify_node(actor.unit,spec.reference,true) end
            local before=matrix(actor.unit,spec.node.index,true)
            local reference=spec.reference and matrix(actor.unit,spec.reference.index,true) or before
            -- Snapshot every offset before any attachment write. Nested cape
            -- nodes must not receive the parent's translation a second time.
            local offset=relative(rigid(matrix(actor.unit,spec.native.index,true)),reference)
            rows[#rows+1]={spec=spec,index=spec.node.index,before=matrix(actor.unit,spec.node.index,false),
                basis=before,offset=offset,touched=false}
        end
        return rows
    end
    local function apply_attachments(actor,rows,leftPhase)
        local worlds,changed={},{}
        for _,row in ipairs(rows) do
            if (row.spec.native.name=='l_hand' or row.spec.native.name=='l_elbow')==leftPhase then
                local destination=compose(compose(rigid(matrix(actor.unit,row.spec.source.index,true)),row.spec.axes),row.offset)
                local desired=copy(row.basis)
                for i=10,12 do desired[i]=destination[i] end
                row.written=relative(worlds[row.spec.node.parent] or matrix(actor.unit,row.spec.node.parent,true),desired)
                worlds[row.index]=desired;changed[#changed+1]=row
                row.touched=true
                U.set_local_pose(actor.unit,row.index+1,X.from_elements(unpack(row.written)))
                assert(difference(matrix(actor.unit,row.index,false),row.written)<=cfg.localTolerance,'attachment_local_readback')
                self.stats.attachmentWrites=self.stats.attachmentWrites+1
            end
        end
        if #changed>0 then
            W.update_unit(actor.world,actor.unit)
            for _,row in ipairs(changed) do
                assert(difference(matrix(actor.unit,row.index,true),worlds[row.index])<=cfg.worldTolerance,'attachment_world_readback')
            end
        end
    end
    local function observe_consumers(actor, sourceLeft, nativeLeft, target, membership, frame)
        for _, item in ipairs(self.consumers) do
            if item.world==actor.world and present(item,membership) then
                pcall(function()
                    identity(item)
                    local root=matrix(item.unit,item.spec.root,true)
                    if distance(root,target)>cfg.consumerRadius then return end
                    local poses={}
                    for _,node in ipairs(item.spec.nodes) do poses[node.name]=matrix(item.unit,node.index,true) end
                    local row={event='consumer',frame=frame,phase='render',avatar=actor.id,
                        world=actor.worldLabel,instance=item.id,kind=item.spec.kind,
                        resource=item.spec.resource,owner='unverified',poses=poses}
                    if item.spec.kind=='weapon' and cfg.leftGrip and cfg.leftGrip.enabled
                        and cfg.leftGrip.weaponTargets[item.spec.resource] then
                        row.mountDistance=distance(root,target);row.mountAngleDegrees=angle(root,target)
                        local right=weapon_static(item.spec.resource,'rootToIKRight')
                        row.rightMarkerAvailable=poses.IK_right~=nil
                        if poses.IK_right and right then
                            row.predictedRightMarkerError=distance(poses.IK_right,compose(target,right))
                        end
                        row.predictedLeftMarkerError=distance(poses.IK_left,
                            compose(target,weapon_static(item.spec.resource,'rootToIKLeft')))
                    elseif item.spec.kind=='foregrip' then
                        row.sourceLeftDistance=distance(sourceLeft,poses.IK_left)
                        row.sourceLeftAngleDegrees=angle(sourceLeft,poses.IK_left)
                        row.nativeLeftDistance=distance(nativeLeft,poses.IK_left)
                        row.nativeLeftAngleDegrees=angle(nativeLeft,poses.IK_left)
                        row.predictedForegripError=distance(poses.IK_left,compose(target,cfg.weaponForegripLeft))
                    end
                    emit(row)
                end)
            end
        end
    end
    local function apply(actor, model, membership, frame, now, diagnostic)
        local record
        local ok, why=pcall(function()
            identity(actor);identity(model)
            assert(visible(model.unit),'model_hidden_before_write')
            local u=actor.unit
            local original=matrix(u,cfg.originalMount.index,false)
            -- A rigid Source wrist preserves this displacement's length. Check
            -- the animated reference before any body/mount/left setter: an
            -- out-of-range transition must not disable every later weapon.
            local offset=compose(cfg.rightAxes,original)
            local mountDistance=math.sqrt(offset[10]^2+offset[11]^2+offset[12]^2)
            if mountDistance>cfg.maxWristMountDistance then
                self.stats.mountSkipped=self.stats.mountSkipped+1
                if diagnostic or self.stats.mountSkipped==1 then
                    emit({event='mount_skipped',avatar=actor.id,frame=frame,time=now,
                        reason='mount_offset_out_of_range',distance=mountDistance,
                        limit=cfg.maxWristMountDistance,retry='next_render',originalLocal=original})
                end
                return
            end
            record={actor=actor,diagnostic=diagnostic,protected={},body={},attachments=plan_attachments(actor)}
            self.pending[#self.pending+1]=record
            if cfg.bodySync and cfg.bodySync.enabled then
                for _,item in ipairs(cfg.bodySync.outputs) do
                    verify_node(u,item.node,true);verify_node(u,item.native,true)
                    verify_node(u,item.reference,true);verify_node(u,item.positionParent,true)
                    assert(item.node.parent==item.native.index,'body_native_parent_required')
                    -- Keep the Source torso's animated offsets; direct native
                    -- pivots otherwise separate its coincident upper-spine joints.
                    local positioned=compose(matrix(u,item.positionParent.index,true),matrix(u,item.reference.index,false))
                    local parentLocal=relative(matrix(u,item.native.index,true),positioned)
                    local outputPose=copy(item.localPose)
                    for j=10,12 do outputPose[j]=parentLocal[j] end
                    local row={index=item.node.index,before=matrix(u,item.node.index,false),
                        written=outputPose,touched=true}
                    record.body[#record.body+1]=row
                    U.set_local_pose(u,row.index+1,X.from_elements(unpack(row.written)))
                    assert(difference(matrix(u,row.index,false),row.written)<=cfg.localTolerance,'body_local_readback')
                    self.stats.bodyNodeWrites=self.stats.bodyNodeWrites+1
                    W.update_unit(actor.world,u)
                    assert(distance(matrix(u,row.index,true),positioned)<=cfg.worldTolerance,'body_position_readback')
                end
                if not performance.batchRefresh then refresh_models(actor.world,membership,actor) end
                if diagnostic then emit({event='body_applied',avatar=actor.id,frame=frame,
                    mode=cfg.bodySync.mode,outputs=#record.body,nativeLocalsWritten=false,
                    positionPolicy='source_chain_animated_offsets'}) end
            end
            local native=matrix(u,cfg.target.index,true)
            local nativeLeftBefore=leftEnabled and matrix(u,cfg.nativeLeft.index,true) or nil
            local source=matrix(u,cfg.sourceRight.index,true)
            local sourceLeft=compose(rigid(matrix(u,cfg.sourceLeft.index,true)),cfg.leftAxes)
            local equivalent=compose(rigid(source),cfg.rightAxes)
            local reference=compose(equivalent,original)
            -- B20's effective position-only setter: keep the live native aim
            -- basis and scale. The destination still uses B23's wrist reference.
            local desired=copy(native);local _,nativeScale=rigid(native)
            for j=10,12 do desired[j]=reference[j] end
            assert(distance(desired,source)<=cfg.maxWristMountDistance,'mount_offset_out_of_range')
            local parent=matrix(u,cfg.target.parent,true)
            local written=relative(parent,desired)
            for _,v in ipairs(written) do assert(finite(v),'invalid_output') end
            record.before=matrix(u,cfg.target.index,false);record.written=written
            record.sourceWorld=source;record.desired=desired
            for _,node in ipairs(cfg.protected) do
                record.protected[#record.protected+1]={node=node,localPose=matrix(u,node.index,false),
                    worldPose=node.world and matrix(u,node.index,true) or nil}
            end
            apply_attachments(actor,record.attachments,false)
            U.set_local_pose(u,cfg.target.index+1,X.from_elements(unpack(written)))
            self.stats.writes=self.stats.writes+1
            W.update_unit(actor.world,u)
            local modelRefreshes,consumerRefreshes=self.stats.modelRefreshes,self.stats.consumerRefreshes
            refresh_models(actor.world,membership,actor)
            refresh_consumers(actor.world,membership,actor)
            local leftResult,leftReason
            if leftEnabled then
                local planned,result,reason=pcall(plan_left,actor,desired,native,nativeLeftBefore,membership,record.attachments)
                if planned then leftResult,leftReason=result,reason else leftReason=tostring(result) end
                if leftResult then
                    record.left=leftResult.rows
                    for _,row in ipairs(record.left) do
                        row.touched=true
                        U.set_local_pose(u,row.index+1,X.from_elements(unpack(row.written)))
                        self.stats.leftNodeWrites=self.stats.leftNodeWrites+1
                    end
                    W.update_unit(actor.world,u)
                    if not performance.batchRefresh or #record.attachments==0 then
                        refresh_models(actor.world,membership,actor);refresh_consumers(actor.world,membership,actor)
                    end
                    for _,row in ipairs(record.left) do
                        assert(difference(matrix(u,row.index,false),row.written)<=cfg.localTolerance,'left_local_readback')
                    end
                    local actualLeft=matrix(u,cfg.sourceLeft.index,true)
                    assert(difference(actualLeft,leftResult.expected)<=cfg.worldTolerance,'left_world_readback')
                    self.stats.leftWrites=self.stats.leftWrites+1
                    sourceLeft=compose(rigid(actualLeft),cfg.leftAxes)
                    if diagnostic then emit({event='left_applied',frame=frame,time=now,avatar=actor.id,
                        weapon=leftResult.weapon,weaponResource=leftResult.weaponResource,owner='unverified',
                        link=leftResult.link,
                        mode='existing_two_bone_solver',nativeContactDistance=leftResult.nativeContactDistance,
                        intent=self.leftIntent[actor.unit],
                        outputMode=cfg.leftGrip.outputs and 'unanimated_reference_children' or 'animated_source_nodes',
                        nativeInContact=leftResult.nativeInContact,requireNativeContact=false,
                        reachPolicy=cfg.leftGrip.reachPolicy,softDistance=cfg.leftGrip.softDistance,
                        beforeDistance=distance(leftResult.before,leftResult.target),
                        afterDistance=distance(actualLeft,leftResult.target),
                        afterAngleDegrees=angle(sourceLeft,leftResult.target),reachResidual=leftResult.reachResidual,
                        target=leftResult.target,sourceBefore=leftResult.before,sourceAfter=actualLeft}) end
                else
                    self.stats.leftSkipped=self.stats.leftSkipped+1
                    if diagnostic then emit({event='left_skipped',frame=frame,time=now,avatar=actor.id,reason=leftReason,intent=self.leftIntent[actor.unit]}) end
                end
            end
            -- A package or reload shell follows the final left wrist, whether
            -- that wrist is animated freely or solved to a two-handed weapon.
            apply_attachments(actor,record.attachments,true)
            if #record.attachments>0 then
                refresh_models(actor.world,membership,actor);refresh_consumers(actor.world,membership,actor)
                if diagnostic then emit({event='attachments_applied',frame=frame,avatar=actor.id,
                    count=#record.attachments,headDescendants=false,policy='position_preserve_native_basis',
                    singleHand='right_and_left_mounts_independent'}) end
            end
            local actual=matrix(u,cfg.target.index,true)
            assert(difference(matrix(u,cfg.target.index,false),written)<=cfg.localTolerance,'local_readback')
            assert(difference(actual,desired)<=cfg.worldTolerance,'world_readback')
            for _,row in ipairs(record.protected) do
                assert(difference(matrix(u,row.node.index,false),row.localPose)<=cfg.localTolerance,
                    'protected_local_changed:'..row.node.name)
                if row.worldPose then
                    assert(difference(matrix(u,row.node.index,true),row.worldPose)<=cfg.worldTolerance,
                        'protected_world_changed:'..row.node.name)
                end
            end
            self.stats.readbacks=self.stats.readbacks+1
            if diagnostic then
                local nativeLeft=matrix(u,cfg.nativeLeft.index,true)
                local rightMarker=leftResult and weapon_static(leftResult.weaponResource,'rootToIKRight')
                    or (not leftEnabled and cfg.weaponRight or nil)
                emit({event='applied',frame=frame,time=now,phase='render',avatar=actor.id,world=actor.worldLabel,
                    target=cfg.target.name,source=cfg.sourceRight.name,reference=cfg.originalMount.name,
                    axisRegistration=cfg.axisRegistration,originalLocal=original,rotationMode='native-world',
                    worldUnits=#membership[actor.world].units,modelResource=model.spec.resource,
                    modelRefreshes=self.stats.modelRefreshes-modelRefreshes,
                    consumerRefreshes=self.stats.consumerRefreshes-consumerRefreshes,
                    nativeRight=matrix(u,cfg.nativeRight.index,true),sourceRight=source,
                    equivalentRight=equivalent,beforeWorld=native,desiredWorld=desired,actualWorld=actual,
                    localReadbackError=difference(matrix(u,cfg.target.index,false),written),
                    worldReadbackError=difference(actual,desired),weaponWorldScale=nativeScale,
                    weaponResource=leftResult and leftResult.weaponResource,
                    rightWristToMarker=rightMarker and relative(equivalent,compose(desired,rightMarker)),
                    sourceLeft=sourceLeft,nativeLeft=nativeLeft,leftWrite=leftResult~=nil,
                    predictedLeftDistance=leftResult and distance(sourceLeft,leftResult.target),
                    palmSurfaceCalibrated=false})
                if not cfg.diagnostics or cfg.diagnostics.consumers~=false then
                    observe_consumers(actor,sourceLeft,nativeLeft,actual,membership,frame)
                end
            end
        end)
        if not ok then
            self.disabled=true
            if record then
                local restored,result=pcall(restore,record,membership,true)
                if restored then
                    for i=#self.pending,1,-1 do if self.pending[i]==record then table.remove(self.pending,i) end end
                end
                emit({event='rollback',avatar=actor.id,verified=restored and result=='restored',reason=tostring(result)},true)
            end
            emit({event='disabled',avatar=actor.id,reason=tostring(why)},true)
        end
    end
    function self:tick(phase, frame, now)
        if self.stopped then return end
        self.phase=phase
        if phase=='render' then self.validation={} end
        assert(phase=='update' or phase=='render','unknown_phase')
        -- Match the working B19/B20 lifetime: hold the write through update,
        -- restore immediately before the next render transaction or shutdown.
        if phase=='update' then
            begin_sync(frame,now)
            if self.syncFrame==frame then capture_sync('update',self.monitored,members(),frame,now) end
            return
        end
        local membership=members()
        begin_sync(frame,now)
        capture_sync('render_input',self.monitored,membership,frame,now)
        self:release(membership)
        if self.disabled then return end
        local rescanned=not self.lastScan or now<self.lastScan or now-self.lastScan>=cfg.scanSeconds
        if rescanned then scan(membership,now) end
        local diagnostic=not self.lastLog or now<self.lastLog or now-self.lastLog>=cfg.logSeconds
        local selected,reasons=matching_actors(membership);local active=0
        if cfg.previewGuard and cfg.previewGuard.enabled then
            for actor in pairs(selected) do
                -- The captured preview has 33 Units. Do not hardcode world 11.
                -- Small-world isolation is conservative and explicitly experimental.
                if #membership[actor.world].units<cfg.previewGuard.minimumWorldUnits then
                    selected[actor]=nil;self.leftIntent[actor.unit]=nil
                    if diagnostic then emit({event='small_world_bypass',avatar=actor.id,world=actor.worldLabel,
                        units=#membership[actor.world].units,reason='preview_isolation_heuristic',writes=false}) end
                end
            end
        end
        for actor,model in pairs(selected) do
            if not self.disabled then apply(actor,model,membership,frame,now,diagnostic);active=active+1 end
        end
        self.monitored=selected
        capture_sync('render_output',selected,membership,frame,now)
        if self.disabled then self:release(membership) end
        local status=active>0 and 'active' or 'waiting_for_unique_visible_test01'
        if status~=self.lastStatus then
            emit({event='status',status=status,frame=frame,actors=#self.actors,models=#self.models,
                consumers=#self.consumers},true)
            self.lastStatus=status
        end
        if active==0 then
            self.stats.skipped=self.stats.skipped+1
            if rescanned then emit({event='waiting',frame=frame,actors=#self.actors,models=#self.models,
                consumers=#self.consumers,reasons=reasons}) end
        end
        if diagnostic then self.lastLog=now end
    end
    function self:stop(reason)
        if self.stopped then return end
        self.phase='shutdown';self:release(members());self.stopped=true
        emit({event='complete',reason=reason or 'shutdown',stats=self.stats,pendingRestores=#self.pending,
            disabled=self.disabled},true)
    end
    emit({event='loaded',version=M.VERSION,writePhase='render',restorePhase='before_render_and_shutdown',
        target='attach_hand_r',originalReference=cfg.originalMount.name,axisRegistration=cfg.axisRegistration,
        writePolicy='position_only_preserve_native_aim',discovery='B19_B20_all_worlds_all_units',
        refreshOrder='avatar_model_weapon_components',
        experimentalPoseIntent=cfg.leftGrip and cfg.leftGrip.intent and cfg.leftGrip.intent.enabled or false,
        scopedRefresh=performance.scopedRefresh or false,
        previewIsolation=cfg.previewGuard and cfg.previewGuard.enabled or false,
        leftMode=leftEnabled and 'source_arm_to_weapon_self_ik_left' or 'foregrip_observation_only',
        mountOutOfRangePolicy='skip_frame_retry_without_setters',
        leftOutputMode=cfg.leftGrip and cfg.leftGrip.outputs and 'unanimated_reference_children' or 'animated_source_nodes',
        bodyMode=cfg.bodySync and cfg.bodySync.enabled and cfg.bodySync.mode or 'observation_only',
        rigExpectedNodes=cfg.avatar.count,
        attachmentCount=#(cfg.attachments or {}),headDescendants=false,
        syncMode=cfg.sync and cfg.sync.enabled and 'update_render_input_render_output' or 'off',
        physics='separate_addon',palmSurfaceCalibrated=false},true)
    return self
end

return M

end)()
local AttachmentRuntime=(function()
-- Model-specific attachment entry; uses the same B23 implementation as the test package.
-- Physics stays in physbone_runtime.lua. Calibration is generated from this model's
-- converter skeleton; old L4D2 weapon-bone positions are never a grip target.
local M = { VERSION = '1.0.8' }
function M.install(engine, options)
    assert(type(options)=='table' and type(options.profile)=='table', 'attachment_profile_required')
    assert(options.transfer and options.transfer.VERSION==M.VERSION, 'attachment_runtime_version_mismatch')
    assert(options.profile.attachments and #options.profile.attachments>0, 'attachment_plan_required')
    return options.transfer.new(engine, options.profile, options.logger, options.armMath)
end
return M

end)()
local profile=(function()
return {["version"]=1,["variant"]="test01-v35-B23LR-M-1.0.8-pending",["packageName"]="B23LR-M-多武器握持修正-1.0.8-待测试.zip",["axisRegistration"]="converter-reference-rotation",["avatar"]={["kind"]="avatar",["resource"]="4d1c334d294dfa97",["count"]=260,["nodes"]={{["name"]="attach_hand_r",["index"]=84,["parent"]=71,["hash"]=1339896631},{["name"]="r_hand",["index"]=71,["parent"]=69,["hash"]=612369653},{["name"]="l_hand",["index"]=47,["parent"]=46,["hash"]=1544317139},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=138,["parent"]=137,["hash"]=3022610578},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=259,["parent"]=115,["hash"]=2014374854},{["name"]="__hd2_attach_original__hd2n_4e4fb4fa303d_084",["index"]=220,["parent"]=71,["hash"]=2865060022},{["name"]="attach_hand_l",["index"]=48,["parent"]=47,["hash"]=1100233117},{["name"]="weapon_aim",["index"]=85,["parent"]=84,["hash"]=2305964830},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["index"]=136,["parent"]=135,["hash"]=991151059},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["index"]=137,["parent"]=136,["hash"]=4227385818},{["name"]="hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=257,["parent"]=113,["hash"]=1872341567},{["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=258,["parent"]=114,["hash"]=4226160508},{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=108,["parent"]=197,["hash"]=1877104845}}},["models"]={["e0b67b19ba91057b"]={["kind"]="model",["resource"]="e0b67b19ba91057b",["count"]=205,["nodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["hash"]=1877104845,["index"]=26,["parent"]=204,["avatarIndex"]=108},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["hash"]=991151059,["index"]=38,["parent"]=37,["avatarIndex"]=136},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["hash"]=4227385818,["index"]=39,["parent"]=38,["avatarIndex"]=137},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["hash"]=3022610578,["index"]=40,["parent"]=39,["avatarIndex"]=138},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["hash"]=2014374854,["index"]=33,["parent"]=32,["avatarIndex"]=259}},["observeNodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_000_hips",["index"]=22,["avatarIndex"]=107,["driver"]="hips"},{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=26,["avatarIndex"]=108,["driver"]="spine1"},{["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=28,["avatarIndex"]=255,["driver"]="spine2"},{["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=29,["avatarIndex"]=256,["driver"]="chest"},{["name"]="hd2n_4e4fb4fa303d_anim_054_neck",["index"]=98,["avatarIndex"]=161,["driver"]="neck"},{["name"]="hd2n_4e4fb4fa303d_anim_055_head",["index"]=99,["avatarIndex"]=162,["driver"]="head"},{["name"]="hd2n_4e4fb4fa303d_anim_005_l_clavicle",["index"]=30,["avatarIndex"]=112,["driver"]="l_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=31,["avatarIndex"]=257,["driver"]="l_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=32,["avatarIndex"]=258,["driver"]="l_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=33,["avatarIndex"]=259,["driver"]="l_hand"},{["name"]="hd2n_4e4fb4fa303d_anim_028_r_clavicle",["index"]=37,["avatarIndex"]=135,["driver"]="r_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["index"]=38,["avatarIndex"]=136,["driver"]="r_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["index"]=39,["avatarIndex"]=137,["driver"]="r_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=40,["avatarIndex"]=138,["driver"]="r_hand"}}},["a152e9ef3754a3d0"]={["kind"]="model",["resource"]="a152e9ef3754a3d0",["count"]=205,["nodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["hash"]=1877104845,["index"]=23,["parent"]=204,["avatarIndex"]=108},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["hash"]=991151059,["index"]=36,["parent"]=35,["avatarIndex"]=136},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["hash"]=4227385818,["index"]=37,["parent"]=36,["avatarIndex"]=137},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["hash"]=3022610578,["index"]=38,["parent"]=37,["avatarIndex"]=138},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["hash"]=2014374854,["index"]=30,["parent"]=29,["avatarIndex"]=259}},["observeNodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_000_hips",["index"]=19,["avatarIndex"]=107,["driver"]="hips"},{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=23,["avatarIndex"]=108,["driver"]="spine1"},{["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=25,["avatarIndex"]=255,["driver"]="spine2"},{["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=26,["avatarIndex"]=256,["driver"]="chest"},{["name"]="hd2n_4e4fb4fa303d_anim_054_neck",["index"]=98,["avatarIndex"]=161,["driver"]="neck"},{["name"]="hd2n_4e4fb4fa303d_anim_055_head",["index"]=99,["avatarIndex"]=162,["driver"]="head"},{["name"]="hd2n_4e4fb4fa303d_anim_005_l_clavicle",["index"]=27,["avatarIndex"]=112,["driver"]="l_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=28,["avatarIndex"]=257,["driver"]="l_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=29,["avatarIndex"]=258,["driver"]="l_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=30,["avatarIndex"]=259,["driver"]="l_hand"},{["name"]="hd2n_4e4fb4fa303d_anim_028_r_clavicle",["index"]=35,["avatarIndex"]=135,["driver"]="r_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["index"]=36,["avatarIndex"]=136,["driver"]="r_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["index"]=37,["avatarIndex"]=137,["driver"]="r_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=38,["avatarIndex"]=138,["driver"]="r_hand"}}},["c4e5e53d6dd12e65"]={["kind"]="model",["resource"]="c4e5e53d6dd12e65",["count"]=205,["nodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["hash"]=1877104845,["index"]=23,["parent"]=204,["avatarIndex"]=108},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["hash"]=991151059,["index"]=36,["parent"]=35,["avatarIndex"]=136},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["hash"]=4227385818,["index"]=37,["parent"]=36,["avatarIndex"]=137},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["hash"]=3022610578,["index"]=38,["parent"]=37,["avatarIndex"]=138},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["hash"]=2014374854,["index"]=30,["parent"]=29,["avatarIndex"]=259}},["observeNodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_000_hips",["index"]=19,["avatarIndex"]=107,["driver"]="hips"},{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=23,["avatarIndex"]=108,["driver"]="spine1"},{["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=25,["avatarIndex"]=255,["driver"]="spine2"},{["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=26,["avatarIndex"]=256,["driver"]="chest"},{["name"]="hd2n_4e4fb4fa303d_anim_054_neck",["index"]=98,["avatarIndex"]=161,["driver"]="neck"},{["name"]="hd2n_4e4fb4fa303d_anim_055_head",["index"]=99,["avatarIndex"]=162,["driver"]="head"},{["name"]="hd2n_4e4fb4fa303d_anim_005_l_clavicle",["index"]=27,["avatarIndex"]=112,["driver"]="l_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=28,["avatarIndex"]=257,["driver"]="l_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=29,["avatarIndex"]=258,["driver"]="l_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=30,["avatarIndex"]=259,["driver"]="l_hand"},{["name"]="hd2n_4e4fb4fa303d_anim_028_r_clavicle",["index"]=35,["avatarIndex"]=135,["driver"]="r_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["index"]=36,["avatarIndex"]=136,["driver"]="r_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["index"]=37,["avatarIndex"]=137,["driver"]="r_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=38,["avatarIndex"]=138,["driver"]="r_hand"}}},["c76d11f7ff9443d5"]={["kind"]="model",["resource"]="c76d11f7ff9443d5",["count"]=205,["nodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["hash"]=1877104845,["index"]=27,["parent"]=204,["avatarIndex"]=108},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["hash"]=991151059,["index"]=40,["parent"]=39,["avatarIndex"]=136},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["hash"]=4227385818,["index"]=41,["parent"]=40,["avatarIndex"]=137},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["hash"]=3022610578,["index"]=42,["parent"]=41,["avatarIndex"]=138},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["hash"]=2014374854,["index"]=34,["parent"]=33,["avatarIndex"]=259}},["observeNodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_000_hips",["index"]=21,["avatarIndex"]=107,["driver"]="hips"},{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=27,["avatarIndex"]=108,["driver"]="spine1"},{["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=29,["avatarIndex"]=255,["driver"]="spine2"},{["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=30,["avatarIndex"]=256,["driver"]="chest"},{["name"]="hd2n_4e4fb4fa303d_anim_054_neck",["index"]=98,["avatarIndex"]=161,["driver"]="neck"},{["name"]="hd2n_4e4fb4fa303d_anim_055_head",["index"]=99,["avatarIndex"]=162,["driver"]="head"},{["name"]="hd2n_4e4fb4fa303d_anim_005_l_clavicle",["index"]=31,["avatarIndex"]=112,["driver"]="l_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=32,["avatarIndex"]=257,["driver"]="l_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=33,["avatarIndex"]=258,["driver"]="l_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=34,["avatarIndex"]=259,["driver"]="l_hand"},{["name"]="hd2n_4e4fb4fa303d_anim_028_r_clavicle",["index"]=39,["avatarIndex"]=135,["driver"]="r_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["index"]=40,["avatarIndex"]=136,["driver"]="r_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["index"]=41,["avatarIndex"]=137,["driver"]="r_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=42,["avatarIndex"]=138,["driver"]="r_hand"}}},["ce2f4949f14c7df0"]={["kind"]="model",["resource"]="ce2f4949f14c7df0",["count"]=205,["nodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["hash"]=1877104845,["index"]=23,["parent"]=204,["avatarIndex"]=108},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["hash"]=991151059,["index"]=36,["parent"]=35,["avatarIndex"]=136},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["hash"]=4227385818,["index"]=37,["parent"]=36,["avatarIndex"]=137},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["hash"]=3022610578,["index"]=38,["parent"]=37,["avatarIndex"]=138},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["hash"]=2014374854,["index"]=30,["parent"]=29,["avatarIndex"]=259}},["observeNodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_000_hips",["index"]=19,["avatarIndex"]=107,["driver"]="hips"},{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=23,["avatarIndex"]=108,["driver"]="spine1"},{["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=25,["avatarIndex"]=255,["driver"]="spine2"},{["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=26,["avatarIndex"]=256,["driver"]="chest"},{["name"]="hd2n_4e4fb4fa303d_anim_054_neck",["index"]=98,["avatarIndex"]=161,["driver"]="neck"},{["name"]="hd2n_4e4fb4fa303d_anim_055_head",["index"]=99,["avatarIndex"]=162,["driver"]="head"},{["name"]="hd2n_4e4fb4fa303d_anim_005_l_clavicle",["index"]=27,["avatarIndex"]=112,["driver"]="l_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=28,["avatarIndex"]=257,["driver"]="l_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=29,["avatarIndex"]=258,["driver"]="l_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=30,["avatarIndex"]=259,["driver"]="l_hand"},{["name"]="hd2n_4e4fb4fa303d_anim_028_r_clavicle",["index"]=35,["avatarIndex"]=135,["driver"]="r_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["index"]=36,["avatarIndex"]=136,["driver"]="r_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["index"]=37,["avatarIndex"]=137,["driver"]="r_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=38,["avatarIndex"]=138,["driver"]="r_hand"}}},["d0c7ae3345bba229"]={["kind"]="model",["resource"]="d0c7ae3345bba229",["count"]=205,["nodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["hash"]=1877104845,["index"]=23,["parent"]=204,["avatarIndex"]=108},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["hash"]=991151059,["index"]=36,["parent"]=35,["avatarIndex"]=136},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["hash"]=4227385818,["index"]=37,["parent"]=36,["avatarIndex"]=137},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["hash"]=3022610578,["index"]=38,["parent"]=37,["avatarIndex"]=138},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["hash"]=2014374854,["index"]=30,["parent"]=29,["avatarIndex"]=259}},["observeNodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_000_hips",["index"]=19,["avatarIndex"]=107,["driver"]="hips"},{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=23,["avatarIndex"]=108,["driver"]="spine1"},{["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=25,["avatarIndex"]=255,["driver"]="spine2"},{["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=26,["avatarIndex"]=256,["driver"]="chest"},{["name"]="hd2n_4e4fb4fa303d_anim_054_neck",["index"]=98,["avatarIndex"]=161,["driver"]="neck"},{["name"]="hd2n_4e4fb4fa303d_anim_055_head",["index"]=99,["avatarIndex"]=162,["driver"]="head"},{["name"]="hd2n_4e4fb4fa303d_anim_005_l_clavicle",["index"]=27,["avatarIndex"]=112,["driver"]="l_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=28,["avatarIndex"]=257,["driver"]="l_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=29,["avatarIndex"]=258,["driver"]="l_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=30,["avatarIndex"]=259,["driver"]="l_hand"},{["name"]="hd2n_4e4fb4fa303d_anim_028_r_clavicle",["index"]=35,["avatarIndex"]=135,["driver"]="r_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["index"]=36,["avatarIndex"]=136,["driver"]="r_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["index"]=37,["avatarIndex"]=137,["driver"]="r_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=38,["avatarIndex"]=138,["driver"]="r_hand"}}},["d154442f2e33fdee"]={["kind"]="model",["resource"]="d154442f2e33fdee",["count"]=205,["nodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["hash"]=1877104845,["index"]=24,["parent"]=204,["avatarIndex"]=108},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["hash"]=991151059,["index"]=37,["parent"]=36,["avatarIndex"]=136},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["hash"]=4227385818,["index"]=38,["parent"]=37,["avatarIndex"]=137},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["hash"]=3022610578,["index"]=39,["parent"]=38,["avatarIndex"]=138},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["hash"]=2014374854,["index"]=31,["parent"]=30,["avatarIndex"]=259}},["observeNodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_000_hips",["index"]=22,["avatarIndex"]=107,["driver"]="hips"},{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=24,["avatarIndex"]=108,["driver"]="spine1"},{["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=26,["avatarIndex"]=255,["driver"]="spine2"},{["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=27,["avatarIndex"]=256,["driver"]="chest"},{["name"]="hd2n_4e4fb4fa303d_anim_054_neck",["index"]=98,["avatarIndex"]=161,["driver"]="neck"},{["name"]="hd2n_4e4fb4fa303d_anim_055_head",["index"]=99,["avatarIndex"]=162,["driver"]="head"},{["name"]="hd2n_4e4fb4fa303d_anim_005_l_clavicle",["index"]=28,["avatarIndex"]=112,["driver"]="l_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=29,["avatarIndex"]=257,["driver"]="l_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=30,["avatarIndex"]=258,["driver"]="l_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=31,["avatarIndex"]=259,["driver"]="l_hand"},{["name"]="hd2n_4e4fb4fa303d_anim_028_r_clavicle",["index"]=36,["avatarIndex"]=135,["driver"]="r_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["index"]=37,["avatarIndex"]=136,["driver"]="r_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["index"]=38,["avatarIndex"]=137,["driver"]="r_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=39,["avatarIndex"]=138,["driver"]="r_hand"}}},["f479e48687a13b31"]={["kind"]="model",["resource"]="f479e48687a13b31",["count"]=205,["nodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["hash"]=1877104845,["index"]=34,["parent"]=204,["avatarIndex"]=108},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["hash"]=991151059,["index"]=47,["parent"]=46,["avatarIndex"]=136},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["hash"]=4227385818,["index"]=48,["parent"]=47,["avatarIndex"]=137},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["hash"]=3022610578,["index"]=49,["parent"]=48,["avatarIndex"]=138},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["hash"]=2014374854,["index"]=41,["parent"]=40,["avatarIndex"]=259}},["observeNodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_000_hips",["index"]=30,["avatarIndex"]=107,["driver"]="hips"},{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=34,["avatarIndex"]=108,["driver"]="spine1"},{["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=36,["avatarIndex"]=255,["driver"]="spine2"},{["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=37,["avatarIndex"]=256,["driver"]="chest"},{["name"]="hd2n_4e4fb4fa303d_anim_054_neck",["index"]=101,["avatarIndex"]=161,["driver"]="neck"},{["name"]="hd2n_4e4fb4fa303d_anim_055_head",["index"]=102,["avatarIndex"]=162,["driver"]="head"},{["name"]="hd2n_4e4fb4fa303d_anim_005_l_clavicle",["index"]=38,["avatarIndex"]=112,["driver"]="l_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=39,["avatarIndex"]=257,["driver"]="l_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=40,["avatarIndex"]=258,["driver"]="l_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=41,["avatarIndex"]=259,["driver"]="l_hand"},{["name"]="hd2n_4e4fb4fa303d_anim_028_r_clavicle",["index"]=46,["avatarIndex"]=135,["driver"]="r_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["index"]=47,["avatarIndex"]=136,["driver"]="r_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["index"]=48,["avatarIndex"]=137,["driver"]="r_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=49,["avatarIndex"]=138,["driver"]="r_hand"}}},["34a40a5ae7a392ba"]={["kind"]="model",["resource"]="34a40a5ae7a392ba",["count"]=205,["nodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["hash"]=1877104845,["index"]=34,["parent"]=204,["avatarIndex"]=108},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["hash"]=991151059,["index"]=47,["parent"]=46,["avatarIndex"]=136},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["hash"]=4227385818,["index"]=48,["parent"]=47,["avatarIndex"]=137},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["hash"]=3022610578,["index"]=49,["parent"]=48,["avatarIndex"]=138},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["hash"]=2014374854,["index"]=41,["parent"]=40,["avatarIndex"]=259}},["observeNodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_000_hips",["index"]=30,["avatarIndex"]=107,["driver"]="hips"},{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=34,["avatarIndex"]=108,["driver"]="spine1"},{["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=36,["avatarIndex"]=255,["driver"]="spine2"},{["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=37,["avatarIndex"]=256,["driver"]="chest"},{["name"]="hd2n_4e4fb4fa303d_anim_054_neck",["index"]=101,["avatarIndex"]=161,["driver"]="neck"},{["name"]="hd2n_4e4fb4fa303d_anim_055_head",["index"]=102,["avatarIndex"]=162,["driver"]="head"},{["name"]="hd2n_4e4fb4fa303d_anim_005_l_clavicle",["index"]=38,["avatarIndex"]=112,["driver"]="l_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=39,["avatarIndex"]=257,["driver"]="l_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=40,["avatarIndex"]=258,["driver"]="l_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=41,["avatarIndex"]=259,["driver"]="l_hand"},{["name"]="hd2n_4e4fb4fa303d_anim_028_r_clavicle",["index"]=46,["avatarIndex"]=135,["driver"]="r_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["index"]=47,["avatarIndex"]=136,["driver"]="r_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["index"]=48,["avatarIndex"]=137,["driver"]="r_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=49,["avatarIndex"]=138,["driver"]="r_hand"}}},["63f4ef572404c7d2"]={["kind"]="model",["resource"]="63f4ef572404c7d2",["count"]=205,["nodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["hash"]=1877104845,["index"]=27,["parent"]=204,["avatarIndex"]=108},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["hash"]=991151059,["index"]=40,["parent"]=39,["avatarIndex"]=136},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["hash"]=4227385818,["index"]=41,["parent"]=40,["avatarIndex"]=137},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["hash"]=3022610578,["index"]=42,["parent"]=41,["avatarIndex"]=138},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["hash"]=2014374854,["index"]=34,["parent"]=33,["avatarIndex"]=259}},["observeNodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_000_hips",["index"]=21,["avatarIndex"]=107,["driver"]="hips"},{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=27,["avatarIndex"]=108,["driver"]="spine1"},{["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=29,["avatarIndex"]=255,["driver"]="spine2"},{["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=30,["avatarIndex"]=256,["driver"]="chest"},{["name"]="hd2n_4e4fb4fa303d_anim_054_neck",["index"]=99,["avatarIndex"]=161,["driver"]="neck"},{["name"]="hd2n_4e4fb4fa303d_anim_055_head",["index"]=100,["avatarIndex"]=162,["driver"]="head"},{["name"]="hd2n_4e4fb4fa303d_anim_005_l_clavicle",["index"]=31,["avatarIndex"]=112,["driver"]="l_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=32,["avatarIndex"]=257,["driver"]="l_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=33,["avatarIndex"]=258,["driver"]="l_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=34,["avatarIndex"]=259,["driver"]="l_hand"},{["name"]="hd2n_4e4fb4fa303d_anim_028_r_clavicle",["index"]=39,["avatarIndex"]=135,["driver"]="r_clavicle"},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["index"]=40,["avatarIndex"]=136,["driver"]="r_shoulder"},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["index"]=41,["avatarIndex"]=137,["driver"]="r_elbow"},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=42,["avatarIndex"]=138,["driver"]="r_hand"}}}},["consumers"]={["186ea95de7306b1a"]={["kind"]="weapon",["resource"]="186ea95de7306b1a",["count"]=36,["nodes"]={{["name"]="boss",["index"]=10,["parent"]=9,["hash"]=2601604451},{["name"]="IK_right",["index"]=12,["parent"]=10,["hash"]=365473252},{["name"]="IK_left",["index"]=16,["parent"]=10,["hash"]=1741246027},{["name"]="attach_underbarrel",["index"]=23,["parent"]=10,["hash"]=2035344238}},["root"]=10,["order"]=0},["f9df21c8e52cac95"]={["kind"]="foregrip",["resource"]="f9df21c8e52cac95",["count"]=13,["nodes"]={{["name"]="skeleton",["index"]=7,["parent"]=2,["hash"]=2539449277},{["name"]="IK_left",["index"]=8,["parent"]=7,["hash"]=1741246027}},["root"]=7,["order"]=1},["9c22a90da9c79de3"]={["kind"]="weapon_magazine",["resource"]="9c22a90da9c79de3",["count"]=11,["nodes"]={{["name"]="StingrayEntityRoot",["index"]=0,["hash"]=1243096897,["parent"]=nil},{["name"]="FbxAxisSystem_ConvertNode",["index"]=1,["hash"]=2133911068,["parent"]=0},{["name"]="game_mesh",["index"]=3,["hash"]=828166497,["parent"]=2},{["name"]="g_mag",["index"]=8,["hash"]=657972516,["parent"]=3},{["name"]="collision",["index"]=9,["hash"]=2748617169,["parent"]=2}},["root"]=3,["order"]=1},["52ff81fcba0c059d"]={["kind"]="weapon_magazine",["resource"]="52ff81fcba0c059d",["count"]=12,["nodes"]={{["name"]="StingrayEntityRoot",["index"]=0,["hash"]=1243096897,["parent"]=nil},{["name"]="FbxAxisSystem_ConvertNode",["index"]=1,["hash"]=2133911068,["parent"]=0},{["name"]="shadow_mesh",["index"]=3,["hash"]=493256494,["parent"]=2},{["name"]="collision",["index"]=6,["hash"]=2748617169,["parent"]=2},{["name"]="game_mesh",["index"]=8,["hash"]=828166497,["parent"]=2}},["root"]=8,["order"]=1}},["target"]={["name"]="attach_hand_r",["index"]=84,["parent"]=71,["hash"]=1339896631},["nativeRight"]={["name"]="r_hand",["index"]=71,["parent"]=69,["hash"]=612369653},["nativeLeft"]={["name"]="l_hand",["index"]=47,["parent"]=46,["hash"]=1544317139},["sourceRight"]={["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=138,["parent"]=137,["hash"]=3022610578},["sourceLeft"]={["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=259,["parent"]=115,["hash"]=2014374854},["originalMount"]={["name"]="__hd2_attach_original__hd2n_4e4fb4fa303d_084",["index"]=220,["parent"]=71,["hash"]=2865060022},["rightAxes"]={0.9702061922772703,0.24089138307280594,0.025909188102131622,-0.06421478090319893,0.35878590303728136,-0.9312084287071702,-0.2336159377705107,0.9018004309951253,0.3635650922140513,0.0,0.0,0.0},["leftAxes"]={0.9698523497804471,0.24250113091198405,-0.024075322048818126,0.028337436653635625,-0.21034915711648688,-0.9772155452019197,-0.24204009855651343,0.9470725598425881,-0.21087948473941454,0.0,0.0,0.0},["protected"]={{["name"]="r_hand",["index"]=71,["parent"]=69,["hash"]=612369653,["world"]=true},{["name"]="l_hand",["index"]=47,["parent"]=46,["hash"]=1544317139,["world"]=true},{["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=138,["parent"]=137,["hash"]=3022610578,["world"]=true},{["name"]="__hd2_attach_original__hd2n_4e4fb4fa303d_084",["index"]=220,["parent"]=71,["hash"]=2865060022,["world"]=true},{["name"]="weapon_aim",["index"]=85,["parent"]=84,["hash"]=2305964830,["world"]=false},{["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["index"]=136,["parent"]=135,["hash"]=991151059,["world"]=true},{["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["index"]=137,["parent"]=136,["hash"]=4227385818,["world"]=true},{["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=108,["parent"]=197,["hash"]=1877104845,["world"]=true}},["bodySync"]={["enabled"]=true,["outputs"]={{["node"]={["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=255,["parent"]=26,["hash"]=1520906558},["native"]={["name"]="spine2",["index"]=26,["parent"]=21,["hash"]=1514912418},["reference"]={["name"]="__hd2_b23_reference__hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=110,["parent"]=109,["hash"]=3738790731},["positionParent"]={["name"]="hd2n_4e4fb4fa303d_aux_002_valvebiped_bip01_spine1",["index"]=109,["parent"]=108,["hash"]=2341711249},["localPose"]={0.9980120818892231,-8.777619050215346e-07,0.06302288792469292,-0.06302288792392953,8.718084988923458e-07,0.9980120818892766,-9.309608755558862e-07,-0.9999999999992348,8.147563247962175e-07,0.08989746123552322,7.698704251879462e-08,0.05843370780348778}},{["node"]={["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=256,["parent"]=28,["hash"]=3698807838},["native"]={["name"]="chest",["index"]=28,["parent"]=26,["hash"]=938412064},["reference"]={["name"]="__hd2_b23_reference__hd2n_4e4fb4fa303d_anim_004_chest",["index"]=111,["parent"]=110,["hash"]=4210192551},["positionParent"]={["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=255,["parent"]=26,["hash"]=1520906558},["localPose"]={0.9848078678417287,-6.722732312919311e-07,-0.17364752643379716,0.17364752643454995,6.3262506770356275e-06,0.9848078678215061,4.36477814155789e-07,-0.9999999999797634,6.346880024377111e-06,-0.08413881808519363,7.698741910644458e-08,0.07333724200725555}}},["mode"]="native_parent_unanimated_output"},["leftGrip"]={["enabled"]=true,["nodes"]={{["name"]="hd2n_4e4fb4fa303d_anim_005_l_clavicle",["index"]=112,["parent"]=256,["hash"]=1195967450},{["name"]="__hd2_b23_reference__hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=113,["parent"]=112,["hash"]=3960215984},{["name"]="__hd2_b23_reference__hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=114,["parent"]=113,["hash"]=4040395058},{["name"]="__hd2_b23_reference__hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=115,["parent"]=114,["hash"]=343737262}},["outputs"]={{["name"]="hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=257,["parent"]=113,["hash"]=1872341567},{["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=258,["parent"]=114,["hash"]=4226160508},{["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=259,["parent"]=115,["hash"]=2014374854}},["weaponTargets"]={["006e44327bb953fe"]={["rootName"]="boss",["rootToIKLeft"]={0.7178585695357133,0.28152636033855133,-0.6367275575775465,0.12522909057930554,-0.9518888224544897,-0.27968794138983777,-0.6848333731768771,0.12103957254027882,-0.7185768385235131,-0.0967947468161583,0.4045783281326294,0.09621945768594742},["leftPolicy"]="always",["rootToIKRight"]={1.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,1.0,0.0753399059176445,-0.08978892117738724,0.09213294833898544},["linkNodes"]={"skeleton","root","boss"}},["027dec442cc26a90"]={["rootName"]="boss",["rootToIKLeft"]={0.7488807370400132,0.6386596154366831,0.1768941415103244,0.15812049354565239,0.08701940653219148,-0.9835779239123175,-0.6435646834916552,0.7645531039857704,-0.03581801416499263,-0.09511709213256836,0.2694437983445823,0.029525090008974075},["leftPolicy"]="aim_only",["rootToIKRight"]={1.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,1.0,0.018241344019770622,-0.06626173108816147,0.0009644225938245654},["linkNodes"]={"skeleton","boss"}},["02eecd0b1fa49630"]={["rootName"]="boss",["rootToIKLeft"]={0.12166377869220817,0.9880904585247658,-0.09420812452570859,-0.8476193417240516,0.05404082376017639,-0.5278456601153474,-0.5164681756794107,0.14407232607145473,0.8440993948408811,-0.1837170422077179,0.23685380816459656,0.1158408597111702},["leftPolicy"]="always",["rootToIKRight"]={-0.05057949998806256,0.9953133646534937,-0.08241905795271526,-0.04342011499896192,0.08025518100745976,0.9958281978006732,0.9977757300563405,0.05394714050868474,0.03915735616040994,0.05930173397064209,-0.07578816264867783,0.02056766487658024},["linkNodes"]={"skeleton","root","boss"}},["03e67a19b07c6523"]={["rootName"]="boss",["rootToIKLeft"]={0.6577524452069469,0.4657452688183961,-0.5919823184838906,0.47997971400780076,-0.8648550441457414,-0.14712316866033603,-0.5805008139230059,-0.18736887999064256,-0.7924088009643633,-0.08320314437150955,0.3026343882083893,0.05858613923192024},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["05d8d8c073b9d502"]={["rootName"]="boss",["rootToIKLeft"]={0.8218985230447021,0.47939926407566924,-0.30766709965701317,0.45583534783230045,-0.8774244196098486,-0.14946746648995698,-0.3416092401496377,-0.01739845047440894,-0.9396810208605243,-0.09500955909481945,0.32446613907814026,0.04060659185051918},["leftPolicy"]="always",["rootToIKRight"]={0.17411585615883002,0.9787749818959732,-0.10808886829186104,-0.021568490441216226,0.11352980988299144,0.9933004492539098,0.9844889379034001,-0.17061804442224016,0.040878038888451096,0.04215545952320099,-0.07071974873542786,0.016274627298116684},["linkNodes"]={"skeleton","root","boss"}},["05e4e5c2db6e44a2"]={["rootName"]="boss",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.045267943292856216,-0.006544031202793121},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07767770439386368,0.009775180369615555},["linkNodes"]={"skeleton","root","boss"}},["076dd5d4f4360204"]={["rootName"]="boss",["rootToIKLeft"]={0.7358469935652718,0.6578332229140724,-0.16057600347323098,0.6537752529169817,-0.7519489659050224,-0.08456093742632115,-0.17637195376064937,-0.042756705704890215,-0.9833944675635666,-0.055750382393512155,0.4032409302890301,0.015556201338768005},["leftPolicy"]="always",["rootToIKRight"]={0.0906430944277936,0.9958705007984274,-0.005065161671412896,0.00239689175868818,0.004867927523911464,0.9999852789874054,0.9958805567752629,-0.09065390611731938,-0.0019457498978426302,0.0508757010102272,-0.07970024645328522,0.001588986604474485},["linkNodes"]={"skeleton","root","boss"}},["0b882808c6f498e8"]={["rootName"]="boss",["rootToIKLeft"]={0.9999834502896169,-6.1560832543363126e-06,0.005742812872611204,0.00044243213422872713,-0.9969447716361658,-0.07810842823357608,0.005725748451102884,0.07810968102236582,-0.9969283291868372,-0.06668855249881744,0.13129089772701263,-0.007902255281805992},["leftPolicy"]="aim_only",["rootToIKRight"]={1.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,1.0,0.018241344019770622,-0.06626173108816147,-0.00905071571469307},["linkNodes"]={"skeleton","root","boss"}},["0c197bbd8d2c725b"]={["rootName"]="boss",["rootToIKLeft"]={0.5558874303966608,0.529397276784451,-0.6408804007458845,0.43179920961490875,-0.8426978953900198,-0.32157360039637234,-0.7103087955785833,-0.09797293393165875,-0.6970385349035773,-0.07402196526527405,0.13150565326213837,0.05077578127384186},["leftPolicy"]="always",["rootToIKRight"]={0.19944364870218695,0.9774005083039721,-0.07007394772816794,-0.04342011252616115,0.08025520546713755,0.9958281959372526,0.9789468423150944,-0.19556900183955345,0.0584452345430026,0.03808998689055443,-0.09442506730556488,0.0009573957067914307},["linkNodes"]={"skeleton","root","boss"}},["0f83639ab8c86165"]={["rootName"]="boss",["rootToIKLeft"]={0.6233108054669942,0.6385715051757846,-0.29711208051301946,0.5058546168661429,-0.6819613189066822,-0.4044817598475401,-0.4900615212788592,0.10826249147849393,-0.7954146428887732,-0.06628934293985367,0.28860190510749817,-0.019291890785098076},["leftPolicy"]="always",["rootToIKRight"]={0.04128531451086634,0.9441625670362744,-0.32688293103789523,0.062117728554689944,0.3241035176337157,0.9439800303272615,0.9972145759071893,-0.05927774115664025,-0.045268521089286584,0.04238821938633919,-0.067970871925354,-0.0056585525162518024},["linkNodes"]={"skeleton","root","boss"}},["11c27d3babb38956"]={["rootName"]="boss",["rootToIKLeft"]={0.6974975567675367,0.5080271167531303,-0.5053765801237058,0.47034613519912927,-0.8566427004491369,-0.21198536947264274,-0.5406215066115077,-0.08984264935874547,-0.8364548313838024,-0.07008086889982224,0.33792489767074585,0.06070384383201599},["leftPolicy"]="aim_only",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["11ec8e2296a3d662"]={["rootName"]="boss",["rootToIKLeft"]={0.7358469935652718,0.6578332229140724,-0.16057600347323098,0.6537752529169817,-0.7519489659050224,-0.08456093742632115,-0.17637195376064937,-0.042756705704890215,-0.9833944675635666,-0.060610835701140786,0.3337301164865494,0.017540141940116882},["leftPolicy"]="always",["rootToIKRight"]={0.17411585615883002,0.9787749818959732,-0.10808886829186104,-0.021568490441216226,0.11352980988299144,0.9933004492539098,0.9844889379034001,-0.17061804442224016,0.040878038888451096,0.04215545952320099,-0.07071974873542786,0.016274627298116684},["linkNodes"]={"skeleton","root","boss"}},["14d5d4506056c7a4"]={["rootName"]="boss",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.036788661032915115,-0.02259310707449913},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07767770439386368,-0.006273894105106592},["linkNodes"]={"skeleton","root","boss"}},["186ea95de7306b1a"]={["rootName"]="boss",["rootToIKLeft"]={0.4864572477710284,0.4175523637206947,-0.7674694584426782,0.2825565734073904,-0.9063899476364525,-0.31403669474738705,-0.8267533664372411,-0.06408811414646431,-0.5589021244456308,-0.09486283361911774,0.11785032600164413,0.07305047661066055},["leftPolicy"]="always",["rootToIKRight"]={0.10136649994289279,0.9919782175045959,-0.07552515266937387,-0.0434200971177984,0.08025520966388286,0.9958281962708664,0.9939011660399684,-0.09766430933668102,0.05120698024860093,0.04822712764143944,-0.05957790091633797,0.01641298085451126},["linkNodes"]={"skeleton","root","boss"}},["1a437158e1b8d2a1"]={["rootName"]="boss",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.05315188318490982,-0.018521130084991455},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07767770439386368,0.009775180369615555},["linkNodes"]={"skeleton","root","boss"}},["1abbff60d26ba391"]={["rootName"]="boss",["rootToIKLeft"]={0.5224126560389781,0.5586831624781363,-0.644172446456482,0.37993787559524683,-0.8288317434961077,-0.41071297966021675,-0.7633689982560672,-0.030183852249691986,-0.6452570864119958,-0.0776255875825882,0.2780989706516266,0.03484581783413887},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05012330412864685,-0.06427469104528427,0.015789929777383804},["linkNodes"]={"skeleton","boss"}},["2152d5147b0ac418"]={["rootName"]="skeleton",["rootToIKLeft"]={0.41909649574044694,0.8594430394583408,-0.2927725895378296,-0.8177273455941196,0.21716237556398726,-0.5330689363553286,-0.39456319585799327,0.46281547572009163,0.7938020659511491,-0.19711509346961975,0.2679261863231659,0.12727218866348267},["leftPolicy"]="always",["rootToIKRight"]={-0.05057949998806256,0.9953133646534937,-0.08241905795271526,-0.04342011499896192,0.08025518100745976,0.9958281978006732,0.9977757300563405,0.05394714050868474,0.03915735616040994,0.05930173397064209,-0.07578816264867783,0.02056766487658024},["linkNodes"]={"skeleton","root"}},["25aa2fd4643cf4ee"]={["rootName"]="boss",["rootToIKLeft"]={0.13691645031684152,0.6556769644361014,0.7425237612229968,-0.6818372692341454,0.6061331417305689,-0.40951248743725505,-0.7185761648612302,-0.45021143122280877,0.5300545891159897,-0.22013837256474708,0.21551860123872757,0.010903538104073268},["leftPolicy"]="always",["rootToIKRight"]={0.019660769870497807,0.9748926199418142,-0.2218058468820987,-0.045215621769532865,0.22248873423891483,0.9738861898008206,0.9987837612196615,-0.009118262978837888,0.048454675771847644,0.05475248396396637,-0.05437533184885979,0.03385704755783081},["linkNodes"]={"skeleton","boss"}},["26e40437ea275296"]={["rootName"]="boss",["rootToIKLeft"]={0.6163323506963793,0.7870857061483827,0.02511025013768542,-0.3666249808368458,0.3150161628432974,-0.8754147249012136,-0.6969365515679731,0.5303403702570518,0.4827199340861689,-0.20645223837345839,0.19236442260444164,0.040850646793842316},["leftPolicy"]="always",["rootToIKRight"]={0.015580847583488378,0.9907609907081092,-0.1347215516525334,-0.04677857211618666,0.13531266295899605,0.9896980592249921,0.9987837615717181,-0.009118252794876214,0.04845467043142393,0.05475248396396637,-0.060859329998493195,0.02678264118731022},["linkNodes"]={"skeleton","root","boss"}},["27ee1ed8f6fb6356"]={["rootName"]="boss",["rootToIKLeft"]={0.6974975567675367,0.5080271167531303,-0.5053765801237058,0.47034613519912927,-0.8566427004491369,-0.21198536947264274,-0.5406215066115077,-0.08984264935874547,-0.8364548313838024,-0.07008086889982224,0.20648352801799774,0.06070384383201599},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["295beb26dc4f8ff1"]={["rootName"]="boss",["rootToIKLeft"]={0.42422381174334345,0.48559365675035304,-0.7643513315706126,0.3642926364482991,-0.8642693316056442,-0.3468851081643523,-0.8290506720094578,-0.13129064675367533,-0.5435418560843939,-0.08479355275630951,0.2641202509403229,-0.0685497298836708},["leftPolicy"]="always",["rootToIKRight"]={-0.21917024901228266,0.9012868175818245,-0.3736930216114842,0.4278789579196094,0.4329970287604565,0.7933682439159295,0.8768603077557584,0.013987334908539706,-0.48054173090859986,0.07712278515100479,-0.10009992122650146,-0.02661946229636669},["linkNodes"]={"skeleton","root","boss"}},["2b28e17ffed05f7c"]={["rootName"]="skeleton",["rootToIKLeft"]={-0.042169286030288106,0.77901017794037,-0.6255916351590779,0.11091449877846915,-0.6186282707488264,-0.7778155543514399,-0.9929348456699615,-0.10218710315309873,-0.06031640733881422,-0.0779607817530632,-0.06855284422636032,0.0032710705418139696},["leftPolicy"]="aim_only",["rootToIKRight"]={0.3678875412347828,0.8558682595561649,-0.3635218839069274,0.047432222641412114,0.3731570375799188,0.9265549144869261,0.9286597466917509,-0.3581106815871585,0.09668409697356706,0.030315997079014778,-0.056022629141807556,0.02890508808195591},["linkNodes"]={"skeleton","root"}},["2e9d0bdc48b09e60"]={["rootName"]="boss",["rootToIKLeft"]={0.8201792863079692,0.4530503266731912,-0.34935846892935835,0.41963372924861986,-0.8914616154637058,-0.17089061478750098,-0.38886173712051814,-0.006441655072224661,-0.921273604573334,-0.07453829795122147,0.293459951877594,0.04327723756432533},["leftPolicy"]="always",["rootToIKRight"]={-0.048476159523897,0.992912673172017,-0.10850975164899782,0.1746628599163882,0.11539035144215593,0.9778435213058805,0.9834342616786886,0.028449476672123025,-0.17901865889782262,0.05449722707271576,-0.07558490335941315,0.006327372044324875},["linkNodes"]={"skeleton","root","boss"}},["30061f91af477f5e"]={["rootName"]="boss",["rootToIKLeft"]={0.5558874303966608,0.529397276784451,-0.6408804007458845,0.43179920961490875,-0.8426978953900198,-0.32157360039637234,-0.7103087955785833,-0.09797293393165875,-0.6970385349035773,-0.08144859224557877,0.3602168560028076,0.039132069796323776},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["3575aabc5f1f9326"]={["rootName"]="boss",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.045267943292856216,-0.006544031202793121},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07767770439386368,0.009775180369615555},["linkNodes"]={"skeleton","root","boss"}},["35a61296619cc47e"]={["rootName"]="boss",["rootToIKLeft"]={0.6163323506963793,0.7870857061483827,0.02511025013768542,-0.3666249808368458,0.3150161628432974,-0.8754147249012136,-0.6969365515679731,0.5303403702570518,0.4827199340861689,-0.19825172424316406,0.21392413973808289,0.029102683067321777},["leftPolicy"]="aim_only",["rootToIKRight"]={0.019660769870497807,0.9748926199418142,-0.2218058468820987,-0.045215621769532865,0.22248873423891483,0.9738861898008206,0.9987837612196615,-0.009118262978837888,0.048454675771847644,0.05475248396396637,-0.05437533184885979,0.03385704755783081},["linkNodes"]={"skeleton","root","boss"}},["372481e910c05a76"]={["rootName"]="boss",["rootToIKLeft"]={0.6163323506963793,0.7870857061483827,0.02511025013768542,-0.3666249808368458,0.3150161628432974,-0.8754147249012136,-0.6969365515679731,0.5303403702570518,0.4827199340861689,-0.21358811855316162,0.1842418611049652,0.02122724987566471},["leftPolicy"]="always",["linkNodes"]={"skeleton","root","boss"}},["3828e2051aa9e897"]={["rootName"]="boss",["rootToIKLeft"]={0.6080983125447484,0.6597090758100599,-0.44158847083462915,0.477506121267834,-0.7483361234484142,-0.46041389042246383,-0.6341957887636003,0.06911570781360779,-0.7700770099403389,-0.06859099119901657,0.34157973527908325,-0.06638523191213608},["leftPolicy"]="always",["rootToIKRight"]={-0.21917024901228266,0.9012868175818245,-0.3736930216114842,0.4278789579196094,0.4329970287604565,0.7933682439159295,0.8768603077557584,0.013987334908539706,-0.48054173090859986,0.07712278515100479,-0.11144270747900009,-0.014983616769313812},["linkNodes"]={"skeleton","root","boss"}},["39ab99895147a3bf"]={["rootName"]="boss",["rootToIKLeft"]={0.7161943065497777,0.6002925988812488,-0.35596981753244095,-0.6795417718983622,0.48359995366537295,-0.5516829388879843,-0.15902419787855349,0.637008540400555,0.754275429764113,-0.19585557281970978,0.6269219517707825,0.008664516732096672},["leftPolicy"]="always",["rootToIKRight"]={0.26449370153494517,0.7289440425870131,-0.6314139255796947,-0.05232887729393049,0.6646140065885504,0.7453522059050145,0.9629665890188746,-0.16409978205371512,0.21393104205325353,0.03791550174355507,-0.020705794915556908,0.035988789051771164},["linkNodes"]={"skeleton","root","boss"}},["3c86e871923f3970"]={["rootName"]="boss",["rootToIKLeft"]={0.3681925890153416,0.4052588592445343,-0.8367792267964106,0.21534917039484264,-0.912702669867867,-0.34727304995683245,-0.9044660605485478,-0.05233634581589525,-0.4233224929213469,-0.09556647390127182,0.11130518466234207,0.017180386930704117},["leftPolicy"]="always",["rootToIKRight"]={-0.21917024901228266,0.9012868175818245,-0.3736930216114842,0.4278789579196094,0.4329970287604565,0.7933682439159295,0.8768603077557584,0.013987334908539706,-0.48054173090859986,0.07712278515100479,-0.10009992122650146,-0.02661946229636669},["linkNodes"]={"skeleton","root","boss"}},["3f92ba65ef65cca9"]={["rootName"]="boss",["rootToIKLeft"]={-0.18604804582448792,0.827587942464044,-0.5296077058852333,0.01665985917933771,-0.5362840216184921,-0.8438731523450795,-0.9823993962421875,-0.16582414071789253,0.085987095649049,-0.05792391300201416,-0.042516544461250305,0.0016201374819502234},["leftPolicy"]="aim_only",["rootToIKRight"]={0.3678875412347828,0.8558682595561649,-0.3635218839069274,0.047432222641412114,0.3731570375799188,0.9265549144869261,0.9286597466917509,-0.3581106815871585,0.09668409697356706,0.030315997079014778,-0.056022629141807556,0.02890508808195591},["linkNodes"]={"skeleton","root","boss"}},["416d053372c4e433"]={["rootName"]="boss",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.045267943292856216,-0.006544031202793121},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07767770439386368,0.009775180369615555},["linkNodes"]={"skeleton","boss"}},["41eac4a03987faa0"]={["rootName"]="boss",["rootToIKLeft"]={0.8218985230447021,0.47939926407566924,-0.30766709965701317,0.45583534783230045,-0.8774244196098486,-0.14946746648995698,-0.3416092401496377,-0.01739845047440894,-0.9396810208605243,-0.09500955909481945,0.32446613907814026,0.04060659185051918},["leftPolicy"]="always",["rootToIKRight"]={0.17411585615883002,0.9787749818959732,-0.10808886829186104,-0.021568490441216226,0.11352980988299144,0.9933004492539098,0.9844889379034001,-0.17061804442224016,0.040878038888451096,0.04215545952320099,-0.07071974873542786,0.016274627298116684},["linkNodes"]={"skeleton","root","boss"}},["41f2def484634b59"]={["rootName"]="boss",["rootToIKLeft"]={0.4421734873383062,0.6574926430000184,-0.6100705135440753,0.4775061223949121,-0.7483361171212265,-0.4604138995374726,-0.7592565509565635,-0.0877295857323912,-0.6448511530708206,-0.06643486022949219,0.35991647839546204,0.05690763518214226},["leftPolicy"]="always",["rootToIKRight"]={-0.21917024901228266,0.9012868175818245,-0.3736930216114842,0.4278789579196094,0.4329970287604565,0.7933682439159295,0.8768603077557584,0.013987334908539706,-0.48054173090859986,0.04533329978585243,-0.051729582250118256,0.004064417909830809},["linkNodes"]={"skeleton","root","boss"}},["43a58cb89cfa197c"]={["rootName"]="boss",["rootToIKLeft"]={0.17613143703698536,0.9833898546945644,0.04384188147297344,-0.8805612605751751,0.17730880476802235,-0.4395148858875069,-0.43998805759709947,0.03880692834775751,0.8971647181449702,-0.2253486067056656,0.5988988876342773,0.11634251475334167},["leftPolicy"]="always",["rootToIKRight"]={0.2255255586097326,0.46301150332483676,-0.8571805936922757,0.0033570165408811758,0.8794732902888228,0.47593628029307655,0.9742314678003213,-0.11021337147651053,0.1967893795290076,0.03035701997578144,-0.041173312813043594,0.06942956894636154},["linkNodes"]={"skeleton","root","boss"}},["43b2d7766120203b"]={["rootName"]="boss",["rootToIKLeft"]={0.7161943065497777,0.6002925988812488,-0.35596981753244095,-0.6795417718983622,0.48359995366537295,-0.5516829388879843,-0.15902419787855349,0.637008540400555,0.754275429764113,-0.19585557281970978,0.6269219517707825,0.008664516732096672},["leftPolicy"]="always",["rootToIKRight"]={0.26449370153494517,0.7289440425870131,-0.6314139255796947,-0.05232887729393049,0.6646140065885504,0.7453522059050145,0.9629665890188746,-0.16409978205371512,0.21393104205325353,0.03791550174355507,-0.020705794915556908,0.035988789051771164},["linkNodes"]={"skeleton","root","boss"}},["46183b50961d1328"]={["rootName"]="boss",["rootToIKLeft"]={0.6974975567675367,0.5080271167531303,-0.5053765801237058,0.47034613519912927,-0.8566427004491369,-0.21198536947264274,-0.5406215066115077,-0.08984264935874547,-0.8364548313838024,-0.06688406318426132,0.3105694055557251,0.038820359855890274},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["4ba41b6f9f405cc2"]={["rootName"]="boss",["rootToIKLeft"]={0.651756751142696,0.4551208703755062,-0.6066944294194234,0.4945102027711589,-0.8615243030998851,-0.11504527506246805,-0.5750415354943175,-0.2250350640164347,-0.7865662415966357,-0.07102613896131516,0.23243559896945953,0.012795057147741318},["leftPolicy"]="always",["rootToIKRight"]={0.15060892195350928,0.9254197043389318,0.07403269055222214,0.0087239954198467,-0.07640802148858256,0.9373639751864109,0.9283352629050949,-0.14941787341077925,-0.020819571885226745,0.03465299308300018,-0.052836257964372635,-0.003220271784812212},["linkNodes"]={"skeleton","root","boss"}},["4d58c77087b774c5"]={["rootName"]="boss",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.045267943292856216,0.0027355276979506016},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07767770439386368,0.01905474066734314},["linkNodes"]={"skeleton","root","boss"}},["4dbd74f49c8ffc13"]={["rootName"]="boss",["rootToIKLeft"]={0.6974975567675367,0.5080271167531303,-0.5053765801237058,0.47034613519912927,-0.8566427004491369,-0.21198536947264274,-0.5406215066115077,-0.08984264935874547,-0.8364548313838024,-0.06688406318426132,0.3105694055557251,0.038820359855890274},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["4e4a613eb9bf5c24"]={["rootName"]="boss",["rootToIKLeft"]={0.6608859869955608,0.5198690790023996,-0.5412632011231688,0.1984058987190696,-0.816585762065877,-0.5420542339515195,-0.7237850589411068,0.2508462355477698,-0.6428151791651555,-0.10321909934282303,0.17179474234580994,0.062638059258461},["leftPolicy"]="aim_only",["rootToIKRight"]={0.10136649994289279,0.9919782175045959,-0.07552515266937387,-0.0434200971177984,0.08025520966388286,0.9958281962708664,0.9939011660399684,-0.09766430933668102,0.05120698024860093,0.04822712764143944,-0.05957790091633797,0.01641298085451126},["linkNodes"]={"skeleton","root","boss"}},["4fb0f8c02f55c82b"]={["rootName"]="boss",["rootToIKLeft"]={0.6974975567675367,0.5080271167531303,-0.5053765801237058,0.47034613519912927,-0.8566427004491369,-0.21198536947264274,-0.5406215066115077,-0.08984264935874547,-0.8364548313838024,-0.06688406318426132,0.3105694055557251,0.038820359855890274},["leftPolicy"]="aim_only",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05215433984994888,-0.05452342331409454,0.012555224820971489},["linkNodes"]={"skeleton","boss"}},["52071f49263415e4"]={["rootName"]="boss",["rootToIKLeft"]={0.5500637718408532,0.45874417185467997,-0.6978421251956471,0.2919791307505433,-0.8885221658946225,-0.35394427233688336,-0.7824180686272338,-0.009063415652644652,-0.6226875784712078,-0.08532755821943283,0.25030531361699104,0.004637948470190167},["leftPolicy"]="always",["rootToIKRight"]={-0.21917024901228266,0.9012868175818245,-0.3736930216114842,0.4278789579196094,0.4329970287604565,0.7933682439159295,0.8768603077557584,0.013987334908539706,-0.48054173090859986,0.07712278515100479,-0.10009992122650146,-0.02661946229636669},["linkNodes"]={"skeleton","root","boss"}},["52e4334e6a128caf"]={["rootName"]="boss",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.045267943292856216,-0.006544031202793121},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07767770439386368,0.009775180369615555},["linkNodes"]={"skeleton","root","boss"}},["53eebe75cd6e26df"]={["rootName"]="boss",["rootToIKLeft"]={0.8218985230447021,0.47939926407566924,-0.30766709965701317,0.45583534783230045,-0.8774244196098486,-0.14946746648995698,-0.3416092401496377,-0.01739845047440894,-0.9396810208605243,-0.09500955909481945,0.32446613907814026,0.04060659185051918},["leftPolicy"]="always",["rootToIKRight"]={0.17411585615883002,0.9787749818959732,-0.10808886829186104,-0.021568490441216226,0.11352980988299144,0.9933004492539098,0.9844889379034001,-0.17061804442224016,0.040878038888451096,0.04215545952320099,-0.07071974873542786,0.016274627298116684},["linkNodes"]={"skeleton","root","boss"}},["5990123d142b16cb"]={["rootName"]="boss",["rootToIKLeft"]={0.6163323506963793,0.7870857061483827,0.02511025013768542,-0.3666249808368458,0.3150161628432974,-0.8754147249012136,-0.6969365515679731,0.5303403702570518,0.4827199340861689,-0.21019229292869568,0.17699357867240906,0.017851389944553375},["leftPolicy"]="always",["rootToIKRight"]={0.019660769870497807,0.9748926199418142,-0.2218058468820987,-0.045215621769532865,0.22248873423891483,0.9738861898008206,0.9987837612196615,-0.009118262978837888,0.048454675771847644,0.05475248396396637,-0.05437533184885979,0.03385704755783081},["linkNodes"]={"skeleton","root","boss"}},["5beec97f4c7f4ae9"]={["rootName"]="boss",["rootToIKLeft"]={0.6974975567675367,0.5080271167531303,-0.5053765801237058,0.47034613519912927,-0.8566427004491369,-0.21198536947264274,-0.5406215066115077,-0.08984264935874547,-0.8364548313838024,-0.07008086889982224,0.20648352801799774,0.06070384383201599},["leftPolicy"]="always",["linkNodes"]={"skeleton","root","boss"}},["5f3ec9bda2bd8553"]={["rootName"]="boss",["rootToIKLeft"]={1.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,1.0,0.0,-0.054281916469335556,0.34879210591316223},["leftPolicy"]="always",["linkNodes"]={"skeleton","boss"}},["5fecab819f96a3e8"]={["rootName"]="boss",["rootToIKLeft"]={0.5984294687691696,0.44389689327902354,-0.6669615573973365,0.4113096963416842,-0.8846189909924338,-0.21971248137245125,-0.6875365478314305,-0.14284533213500317,-0.7119611692243331,-0.08163926750421524,0.33654841780662537,0.07686500251293182},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["6228d0242bde56b6"]={["rootName"]="boss",["rootToIKLeft"]={0.6974975567675367,0.5080271167531303,-0.5053765801237058,0.47034613519912927,-0.8566427004491369,-0.21198536947264274,-0.5406215066115077,-0.08984264935874547,-0.8364548313838024,-0.06688406318426132,0.3105694055557251,0.038820359855890274},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["64cdb52aca152be1"]={["rootName"]="boss",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.045267943292856216,-0.006544031202793121},["leftPolicy"]="aim_only",["linkNodes"]={"skeleton","root","boss"}},["6cfcc7f8801a0266"]={["rootName"]="boss",["rootToIKLeft"]={0.11460144268958845,0.9906613887985183,-0.073868275174503,-0.8503719638097902,0.05938867566116652,-0.52281965261475,-0.5135503347244841,0.12273140399486561,0.8492367491917784,-0.18465159495053318,0.23454251846233592,0.12157096172199845},["leftPolicy"]="always",["rootToIKRight"]={-0.05057949998806256,0.9953133646534937,-0.08241905795271526,-0.04342011499896192,0.08025518100745976,0.9958281978006732,0.9977757300563405,0.05394714050868474,0.03915735616040994,0.05930173397064209,-0.07578816264867783,0.02056766487658024},["linkNodes"]={"skeleton","boss"}},["6e68194b95d60145"]={["rootName"]="boss",["rootToIKLeft"]={0.6577524452069469,0.4657452688183961,-0.5919823184838906,0.47997971400780076,-0.8648550441457414,-0.14712316866033603,-0.5805008139230059,-0.18736887999064256,-0.7924088009643633,-0.08299999684095383,0.3026343882083893,0.05858613923192024},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["708ea298c82093d0"]={["rootName"]="boss",["rootToIKLeft"]={0.5558874303966608,0.529397276784451,-0.6408804007458845,0.43179920961490875,-0.8426978953900198,-0.32157360039637234,-0.7103087955785833,-0.09797293393165875,-0.6970385349035773,-0.07573103904724121,0.24677936732769012,0.08783368766307831},["leftPolicy"]="always",["rootToIKRight"]={0.19944364870218695,0.9774005083039721,-0.07007394772816794,-0.04342011252616115,0.08025520546713755,0.9958281959372526,0.9789468423150944,-0.19556900183955345,0.0584452345430026,0.04999999701976776,-0.0819999948143959,0.0010000000474974513},["linkNodes"]={"skeleton","root","boss"}},["72170a55a1f37ff1"]={["rootName"]="boss",["rootToIKLeft"]={0.7020525880985005,0.5146995915659657,-0.49214478965648467,0.433537558669457,-0.8571777542058319,-0.27801345815908646,-0.5649489789061705,-0.018183182792764985,-0.8249254651763398,-0.07560734450817108,0.19184625893831253,0.06628843396902084},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["73d84eaae8c75342"]={["rootName"]="boss",["rootToIKLeft"]={-0.14149258943347048,0.2705954970459534,-0.9522383756779944,-0.8190869992474943,-0.5722097631799921,-0.040895899369410516,-0.555946308517628,0.7741795608587074,0.3026046767400588,0.26527950167655945,0.18469226360321045,0.07241783291101456},["leftPolicy"]="aim_only",["rootToIKRight"]={0.6036226993156851,0.33535512301230846,-0.7233093799550506,0.5397956133574816,0.49575679808926265,0.6803277834605187,0.5867369847177887,-0.8011005712212663,0.11822683939460787,-0.03154948353767395,-0.053853366523981094,-0.04666445031762123},["linkNodes"]={"skeleton","boss"}},["7617642765ac38c7"]={["rootName"]="boss",["rootToIKLeft"]={0.6163323476587454,0.7870857079346596,0.025110268705361427,-0.3666249235603863,0.31501613542203927,-0.8754146906688387,-0.6969365728891127,0.5303403727409454,0.48271990057441605,-0.20645223762946827,0.2098706252872944,0.03385064690275205},["leftPolicy"]="always",["rootToIKRight"]={0.019660769870497807,0.9748926199418142,-0.2218058468820987,-0.045215621769532865,0.22248873423891483,0.9738861898008206,0.9987837612196615,-0.009118262978837888,0.048454675771847644,0.05475248163565993,-0.054375335574150085,0.03385704755783081},["linkNodes"]={"skeleton","root","boss"}},["78a8185f63a70795"]={["rootName"]="boss",["rootToIKLeft"]={0.1370061140723333,0.9794743214130127,0.1478487713511042,-0.8927860306620151,0.18676017883805276,-0.4099435803316623,-0.42914147314149437,-0.07583254078266767,0.90004827791575,-0.21278329193592072,0.5979273915290833,0.10724794119596481},["leftPolicy"]="always",["rootToIKRight"]={0.2255255586097326,0.46301150332483676,-0.8571805936922757,0.0033570165408811758,0.8794732902888228,0.47593628029307655,0.9742314678003213,-0.11021337147651053,0.1967893795290076,0.03035701997578144,-0.041173312813043594,0.06942956894636154},["linkNodes"]={"skeleton","root","boss"}},["7b06196e90154c88"]={["rootName"]="boss",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.045267943292856216,-0.006544031202793121},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07767770439386368,0.009775180369615555},["linkNodes"]={"skeleton","root","boss"}},["7b75e5132ffd4ca6"]={["rootName"]="boss",["rootToIKLeft"]={0.4421734873383062,0.6574926430000184,-0.6100705135440753,0.4775061223949121,-0.7483361171212265,-0.4604138995374726,-0.7592565509565635,-0.0877295857323912,-0.6448511530708206,-0.06270794570446014,0.31306183338165283,0.025163210928440094},["leftPolicy"]="always",["rootToIKRight"]={-0.21917024901228266,0.9012868175818245,-0.3736930216114842,0.4278789579196094,0.4329970287604565,0.7933682439159295,0.8768603077557584,0.013987334908539706,-0.48054173090859986,0.07712278515100479,-0.11144270747900009,-0.014983616769313812},["linkNodes"]={"skeleton","root","boss"}},["7e3145a5baa4b948"]={["rootName"]="boss",["rootToIKLeft"]={0.3598327401693262,0.8019722546812138,-0.4768237639041962,0.07838228474522974,-0.5352328836721134,-0.8410600321464285,-0.9297185684605593,0.26526639997852003,-0.2554547327846635,-0.09241388738155365,0.15103298425674438,0.07535956799983978},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05087999626994133,-0.07573805004358292,0.015532604418694973},["linkNodes"]={"skeleton","root","boss"}},["80932fa0ed6901d3"]={["rootName"]="boss",["rootToIKLeft"]={0.6365703129104799,-0.1146326258708679,0.7626516883918922,0.09425791572079256,0.993042199970112,0.0705869335869357,-0.7654369216244435,0.026952413774425255,0.6429462546790581,-0.13449589908123016,0.19317419826984406,0.163800448179245},["leftPolicy"]="always",["rootToIKRight"]={-0.040671023730770216,0.4573782683140993,0.8883417064973853,0.13943277038270435,-0.8777798738145864,0.45832398634608573,0.9893959612078917,0.14250445940242024,-0.028073314658873146,0.14491507411003113,-0.03479024022817612,0.06093423813581467},["linkNodes"]={"skeleton","root","boss"}},["80f1a156d9fa1e36"]={["rootName"]="boss",["rootToIKLeft"]={0.6865639962345945,0.5106910460841038,-0.5175175507310081,0.4702928473282269,-0.8547592090717725,-0.21957079099667845,-0.5544857623371322,-0.09263540827404607,-0.8270212938608716,-0.06959342211484909,0.37681636214256287,0.04296526685357094},["leftPolicy"]="aim_only",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","boss"}},["84354339522c932d"]={["rootName"]="boss",["rootToIKLeft"]={0.283108830693015,0.7108429030432143,-0.6438569384395338,0.3080778785599928,-0.7031469936221466,-0.6408372071767616,-0.9082606513141525,-0.016931407302193058,-0.41806209672865485,-0.07448728382587433,0.24654047191143036,0.08569135516881943},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.04987477511167526,-0.08160483837127686,0.0011494695208966732},["linkNodes"]={"skeleton","root","boss"}},["8645f167b3c813a2"]={["rootName"]="boss",["rootToIKLeft"]={0.6909491299803597,0.5029465422544457,-0.5192630117904423,0.36427784565771587,-0.8626749055476283,-0.350847058561653,-0.6244124846144231,0.053261458604583006,-0.7792767583374697,-0.08810296654701233,0.28757986426353455,-0.023183312267065048},["leftPolicy"]="always",["rootToIKRight"]={-0.21917024901228266,0.9012868175818245,-0.3736930216114842,0.4278789579196094,0.4329970287604565,0.7933682439159295,0.8768603077557584,0.013987334908539706,-0.48054173090859986,0.07712278515100479,-0.10009992122650146,-0.02661946229636669},["linkNodes"]={"skeleton","root","boss"}},["88c2d09ad85a7c9f"]={["rootName"]="boss",["rootToIKLeft"]={0.17613143703698536,0.9833898546945644,0.04384188147297344,-0.8805612605751751,0.17730880476802235,-0.4395148858875069,-0.43998805759709947,0.03880692834775751,0.8971647181449702,-0.2253486067056656,0.5988988876342773,0.11634251475334167},["leftPolicy"]="always",["rootToIKRight"]={0.2255255586097326,0.46301150332483676,-0.8571805936922757,0.0033570165408811758,0.8794732902888228,0.47593628029307655,0.9742314678003213,-0.11021337147651053,0.1967893795290076,0.03035701997578144,-0.041173312813043594,0.06942956894636154},["linkNodes"]={"skeleton","root","boss"}},["89c5493e08ca4207"]={["rootName"]="boss",["rootToIKLeft"]={0.7028206193035398,0.11718775987021732,-0.7016482067378131,0.03952091627706972,-0.9912465959838497,-0.12596890059758908,-0.710268452116674,0.06080376432072917,-0.701299955919158,-0.10328681021928787,0.36740848422050476,0.08991722017526627},["leftPolicy"]="always",["rootToIKRight"]={0.012164517212952308,0.996736824848685,-0.0797980357624003,-0.04342009868748173,0.08025520537117714,0.9958281965483804,0.9989828424707528,-0.00864893065018546,0.04425467712754383,0.05535465478897095,-0.07127473503351212,0.02195945754647255},["linkNodes"]={"skeleton","root","boss"}},["8a307bd1811a5fe9"]={["rootName"]="boss",["rootToIKLeft"]={0.6608859869955608,0.5198690790023996,-0.5412632011231688,0.1984058987190696,-0.816585762065877,-0.5420542339515195,-0.7237850589411068,0.2508462355477698,-0.6428151791651555,-0.10321909934282303,0.17179474234580994,0.062638059258461},["leftPolicy"]="always",["rootToIKRight"]={0.10136649994289279,0.9919782175045959,-0.07552515266937387,-0.0434200971177984,0.08025520966388286,0.9958281962708664,0.9939011660399684,-0.09766430933668102,0.05120698024860093,0.04822712764143944,-0.05957790091633797,0.01641298085451126},["linkNodes"]={"skeleton","root","boss"}},["8d3d52a3b2f19402"]={["rootName"]="skeleton",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.045267943292856216,-0.006544031202793121},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07767770439386368,0.009775180369615555},["linkNodes"]={"skeleton","root"}},["8dc91f277c6096ee"]={["rootName"]="boss",["rootToIKLeft"]={0.6865639962345945,0.5106910460841038,-0.5175175507310081,0.4702928473282269,-0.8547592090717725,-0.21957079099667845,-0.5544857623371322,-0.09263540827404607,-0.8270212938608716,-0.06959342211484909,0.37681636214256287,0.04296526685357094},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","boss"}},["90ddc374f4e3d756"]={["rootName"]="boss",["rootToIKLeft"]={0.7358469935652718,0.6578332229140724,-0.16057600347323098,0.6537752529169817,-0.7519489659050224,-0.08456093742632115,-0.17637195376064937,-0.042756705704890215,-0.9833944675635666,-0.05301711454978886,0.3147392123937607,-0.006891496479511261},["leftPolicy"]="always",["rootToIKRight"]={0.17411585615883002,0.9787749818959732,-0.10808886829186104,-0.021568490441216226,0.11352980988299144,0.9933004492539098,0.9844889379034001,-0.17061804442224016,0.040878038888451096,0.04215545952320099,-0.07071974873542786,0.016274627298116684},["linkNodes"]={"skeleton","root","boss"}},["94bd931b5fb4ee95"]={["rootName"]="boss",["rootToIKLeft"]={0.8174668117684984,0.5112346327374673,-0.2653055648446665,0.20929606132864642,-0.6927919965585417,-0.6900973903854044,-0.5366032898776434,0.5086043340727375,-0.6733338998260204,-0.09889594465494156,0.22333195805549622,0.002550580073148012},["leftPolicy"]="always",["rootToIKRight"]={0.10136649994289279,0.9919782175045959,-0.07552515266937387,-0.0434200971177984,0.08025520966388286,0.9958281962708664,0.9939011660399684,-0.09766430933668102,0.05120698024860093,0.04822712764143944,-0.05957790091633797,0.01641298085451126},["linkNodes"]={"skeleton","root","boss"}},["9571ca51f0daf35b"]={["rootName"]="boss",["rootToIKLeft"]={0.6491389510083546,0.3498456677126567,-0.6754454173781715,0.14929196419067386,-0.9292862719665727,-0.3378445414129992,-0.7458756474636268,0.11846948521408773,-0.6554651017360305,-0.09263642877340317,0.20114873349666595,0.050930168479681015},["leftPolicy"]="always",["rootToIKRight"]={0.10136649994289279,0.9919782175045959,-0.07552515266937387,-0.0434200971177984,0.08025520966388286,0.9958281962708664,0.9939011660399684,-0.09766430933668102,0.05120698024860093,0.04822712764143944,-0.05957790091633797,0.01641298085451126},["linkNodes"]={"skeleton","root","boss"}},["968211c0033dce64"]={["rootName"]="boss",["rootToIKLeft"]={0.5558874303966608,0.529397276784451,-0.6408804007458845,0.43179920961490875,-0.8426978953900198,-0.32157360039637234,-0.7103087955785833,-0.09797293393165875,-0.6970385349035773,-0.07402196526527405,0.13150565326213837,0.05077578127384186},["leftPolicy"]="aim_only",["rootToIKRight"]={0.19944364870218695,0.9774005083039721,-0.07007394772816794,-0.04342011252616115,0.08025520546713755,0.9958281959372526,0.9789468423150944,-0.19556900183955345,0.0584452345430026,0.03808998689055443,-0.09442506730556488,0.0009573957067914307},["linkNodes"]={"skeleton","root","boss"}},["96de9cd50f7306e6"]={["rootName"]="boss",["rootToIKLeft"]={0.3280805868110723,0.9435421159285952,-0.045731871016743975,-0.6391523985562443,0.1860721754865864,-0.7462314365727896,-0.6955913184466915,0.2740536663236146,0.6641138354731758,-0.15568552911281586,0.24308811128139496,0.07289522141218185},["leftPolicy"]="always",["rootToIKRight"]={-0.05057949998806256,0.9953133646534937,-0.08241905795271526,-0.04342011499896192,0.08025518100745976,0.9958281978006732,0.9977757300563405,0.05394714050868474,0.03915735616040994,0.05930173397064209,-0.07578816264867783,0.02056766487658024},["linkNodes"]={"skeleton","root","boss"}},["9eb160830321bfd6"]={["rootName"]="boss",["rootToIKLeft"]={0.8007802129128059,0.526187476277106,-0.28614295451129096,0.16882173731399885,-0.656649637710618,-0.7350581434858039,-0.5746740568510154,0.5403128659430974,-0.6146639205929953,-0.08957616239786148,0.12061204761266708,0.01978873834013939},["leftPolicy"]="always",["rootToIKRight"]={1.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,1.0,0.018241344019770622,-0.06626173108816147,0.0009644225938245654},["linkNodes"]={"skeleton","root","boss"}},["9f80d67a12a7e40f"]={["rootName"]="boss",["rootToIKLeft"]={0.6163323506963793,0.7870857061483827,0.02511025013768542,-0.3666249808368458,0.3150161628432974,-0.8754147249012136,-0.6969365515679731,0.5303403702570518,0.4827199340861689,-0.20645223557949066,0.2098706215620041,0.03385065123438835},["leftPolicy"]="always",["rootToIKRight"]={0.019660769870497807,0.9748926199418142,-0.2218058468820987,-0.045215621769532865,0.22248873423891483,0.9738861898008206,0.9987837612196615,-0.009118262978837888,0.048454675771847644,0.05475248396396637,-0.05437533184885979,0.03385704755783081},["linkNodes"]={"skeleton","root","boss"}},["a6a735accb4a327f"]={["rootName"]="boss",["rootToIKLeft"]={0.6974975567675367,0.5080271167531303,-0.5053765801237058,0.47034613519912927,-0.8566427004491369,-0.21198536947264274,-0.5406215066115077,-0.08984264935874547,-0.8364548313838024,-0.06982731819152832,0.36454111337661743,0.06070384383201599},["leftPolicy"]="aim_only",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05058847740292549,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["a7ee1ebf58fcdf1f"]={["rootName"]="boss",["rootToIKLeft"]={0.5558874303966608,0.529397276784451,-0.6408804007458845,0.43179920961490875,-0.8426978953900198,-0.32157360039637234,-0.7103087955785833,-0.09797293393165875,-0.6970385349035773,-0.07464643567800522,0.08766952902078629,0.048672955483198166},["leftPolicy"]="always",["rootToIKRight"]={0.19944364870218695,0.9774005083039721,-0.07007394772816794,-0.04342011252616115,0.08025520546713755,0.9958281959372526,0.9789468423150944,-0.19556900183955345,0.0584452345430026,0.03808998689055443,-0.09442506730556488,0.0009573957067914307},["linkNodes"]={"skeleton","root","boss"}},["a8a91eb54892b6b2"]={["rootName"]="boss",["rootToIKLeft"]={0.7774253990826865,0.3265781673463349,-0.537546695156649,0.321462504300907,-0.9408905354536281,-0.10670922463580448,-0.540621500857777,-0.08984264525543825,-0.8364548355433128,-0.08865612000226974,0.3785759210586548,0.025535067543387413},["leftPolicy"]="always",["linkNodes"]={"skeleton","root","boss"}},["a8cffb316f0b5c5f"]={["rootName"]="boss",["rootToIKLeft"]={0.1369164555909087,0.6556769614614001,0.7425238086399442,-0.681837303601644,0.6061331463039997,-0.4095125155216306,-0.7185762141941956,-0.45021142939774383,0.5300546134446694,-0.2195747406643161,0.21551861613988876,0.01446536622808467},["leftPolicy"]="always",["rootToIKRight"]={-0.09393032801145412,0.9942913775456226,-0.05061373349289139,-0.02314064477655453,0.04864432944082098,0.9985480658298721,0.9953098030457586,0.09496518178617727,0.018439365751900777,0.06906423717737198,-0.07016013562679291,0.008686363697052002},["linkNodes"]={"skeleton","root","boss"}},["a955c4ea6f6d4203"]={["rootName"]="boss",["rootToIKLeft"]={0.6974975567675367,0.5080271167531303,-0.5053765801237058,0.47034613519912927,-0.8566427004491369,-0.21198536947264274,-0.5406215066115077,-0.08984264935874547,-0.8364548313838024,-0.06928377598524094,0.32338184118270874,0.09924367815256119},["leftPolicy"]="always",["linkNodes"]={"skeleton","root","boss"}},["aa69a60d74a3ec54"]={["rootName"]="boss",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.04873490333557129,-0.010579127818346024},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07893167436122894,-0.0004581369867082685},["linkNodes"]={"skeleton","root","boss"}},["ab2a2b390c539f18"]={["rootName"]="boss",["rootToIKLeft"]={0.5558874303966608,0.529397276784451,-0.6408804007458845,0.43179920961490875,-0.8426978953900198,-0.32157360039637234,-0.7103087955785833,-0.09797293393165875,-0.6970385349035773,-0.07402196526527405,0.13150565326213837,0.05077578127384186},["leftPolicy"]="always",["rootToIKRight"]={0.19944364870218695,0.9774005083039721,-0.07007394772816794,-0.04342011252616115,0.08025520546713755,0.9958281959372526,0.9789468423150944,-0.19556900183955345,0.0584452345430026,0.03808998689055443,-0.09442506730556488,0.0009573957067914307},["linkNodes"]={"skeleton","root","boss"}},["b0f1b354ba1d38d8"]={["rootName"]="boss",["rootToIKLeft"]={0.5797673479843268,-0.11017828726839529,0.8072983136522851,0.16920535696003858,0.9854953128773268,0.012982121276802733,-0.7970190520854858,0.12907258931090929,0.5900007604243667,-0.07963167130947113,0.019617632031440735,-0.02940835803747177},["leftPolicy"]="always",["linkNodes"]={"skeleton","root","boss"}},["b16c9d490aa59b77"]={["rootName"]="boss",["rootToIKLeft"]={0.8201792863079692,0.4530503266731912,-0.34935846892935835,0.41963372924861986,-0.8914616154637058,-0.17089061478750098,-0.38886173712051814,-0.006441655072224661,-0.921273604573334,-0.07453829795122147,0.3062472641468048,0.038657207041978836},["leftPolicy"]="always",["rootToIKRight"]={-0.048476159523897,0.992912673172017,-0.10850975164899782,0.1746628599163882,0.11539035144215593,0.9778435213058805,0.9834342616786886,0.028449476672123025,-0.17901865889782262,0.05449722707271576,-0.07558490335941315,0.006327372044324875},["linkNodes"]={"skeleton","root","boss"}},["b2b5e0d185605f9e"]={["rootName"]="boss",["rootToIKLeft"]={0.6163323506963793,0.7870857061483827,0.02511025013768542,-0.3666249808368458,0.3150161628432974,-0.8754147249012136,-0.6969365515679731,0.5303403702570518,0.4827199340861689,-0.20645223557949066,0.2098706215620041,0.03385065123438835},["leftPolicy"]="always",["rootToIKRight"]={0.019660769870497807,0.9748926199418142,-0.2218058468820987,-0.045215621769532865,0.22248873423891483,0.9738861898008206,0.9987837612196615,-0.009118262978837888,0.048454675771847644,0.05475248396396637,-0.05437533184885979,0.03385704755783081},["linkNodes"]={"skeleton","root","boss"}},["b80951732a5f58f4"]={["rootName"]="boss",["rootToIKLeft"]={0.4988369615088075,0.5288754573613335,-0.6866239410576223,0.5203583758402373,-0.8163115756029603,-0.2507240958295059,-0.6931008507127661,-0.23222005879973828,-0.6824111193576792,-0.06184623762965202,0.08964842557907104,0.057689789682626724},["leftPolicy"]="always",["rootToIKRight"]={0.19944364870218695,0.9774005083039721,-0.07007394772816794,-0.04342011252616115,0.08025520546713755,0.9958281959372526,0.9789468423150944,-0.19556900183955345,0.0584452345430026,0.03808998689055443,-0.09442506730556488,0.0009573957067914307},["linkNodes"]={"skeleton","root","boss"}},["b814eece17533bc4"]={["rootName"]="boss",["rootToIKLeft"]={0.6865639962345945,0.5106910460841038,-0.5175175507310081,0.4702928473282269,-0.8547592090717725,-0.21957079099667845,-0.5544857623371322,-0.09263540827404607,-0.8270212938608716,-0.06959342211484909,0.37681636214256287,0.04296526685357094},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","boss"}},["bc29613666df696b"]={["rootName"]="boss",["rootToIKLeft"]={0.6515240130897773,0.5607019395664403,-0.5110086059293172,0.49712081392484414,-0.824368329228241,-0.2707171108890968,-0.5730509198405435,-0.07765431560364755,-0.8158323666894057,-0.06810040026903152,0.2921055853366852,0.07175091654062271},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["bde1f2534280300d"]={["rootName"]="skeleton",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.045267943292856216,-0.006544031202793121},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07767770439386368,0.009775180369615555},["linkNodes"]={"skeleton","root"}},["be70ee0d8d44028e"]={["rootName"]="boss",["rootToIKLeft"]={0.6491389995321462,0.7468962128916258,-0.1440992937337033,0.14929196693190402,-0.3108486235688084,-0.9386612395458199,-0.7458756365769432,0.5878087859795087,-0.31328958789949646,-0.09263643622398376,0.1595166847109795,-0.006711557507514974},["leftPolicy"]="always",["rootToIKRight"]={0.10136649994289279,0.9919782175045959,-0.07552515266937387,-0.0434200971177984,0.08025520966388286,0.9958281962708664,0.9939011660399684,-0.09766430933668102,0.05120698024860093,0.04822712764143944,-0.05957790091633797,0.01641298085451126},["linkNodes"]={"skeleton","root","boss"}},["bf4cfd2aeabfb5a4"]={["rootName"]="skeleton",["rootToIKLeft"]={1.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,1.0,0.0,-0.18662023544311523,0.4943159818649292},["leftPolicy"]="always",["linkNodes"]={"skeleton","root"}},["c12a34f375bd5a87"]={["rootName"]="boss",["rootToIKLeft"]={0.4919045672733724,0.8706067656571499,0.008588148088677194,-0.07769192785780749,0.05371743966447429,-0.9955292065136166,-0.8671757959268317,0.48903813375634647,0.09406297194314112,-0.07793310284614563,0.3233329653739929,-0.034501612186431885},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["c4232a0e62166d91"]={["rootName"]="boss",["rootToIKLeft"]={0.4919045672733724,0.8706067656571499,0.008588148088677194,-0.07769192785780749,0.05371743966447429,-0.9955292065136166,-0.8671757959268317,0.48903813375634647,0.09406297194314112,-0.07793310284614563,0.16745765507221222,-0.029103785753250122},["leftPolicy"]="always",["rootToIKRight"]={0.10136649994289279,0.9919782175045959,-0.07552515266937387,-0.0434200971177984,0.08025520966388286,0.9958281962708664,0.9939011660399684,-0.09766430933668102,0.05120698024860093,0.04822712764143944,-0.05957790091633797,0.01641298085451126},["linkNodes"]={"skeleton","root","boss"}},["c780bcd79547da0f"]={["rootName"]="boss",["rootToIKLeft"]={0.16355478512071697,0.96859863020244,-0.18726026440434887,0.244491649026371,-0.22369142173183892,-0.9434966148273496,-0.9557581574361466,0.10852982819664087,-0.2734001113494093,-0.07920055091381073,-0.053131528198719025,-0.009998247027397156},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.03223549202084541,-0.087367944419384,0.012082539498806},["linkNodes"]={"skeleton","root","boss"}},["c85f576d5e086147"]={["rootName"]="boss",["rootToIKLeft"]={0.7205451313180551,0.5536481035610269,-0.41747873138295977,0.36068719809422417,-0.8134647699096272,-0.4562671301305075,-0.5922157067793969,0.17818183593001274,-0.7858319094999833,-0.07751219719648361,0.20970258116722107,0.04742826521396637},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05087999626994133,-0.07573805004358292,0.015532604418694973},["linkNodes"]={"skeleton","root","boss"}},["cc786f6491fe7e65"]={["rootName"]="boss",["rootToIKLeft"]={0.011071699129087476,0.9281419449129679,-0.1516425513921567,-0.805291543930255,-0.06897293879087825,-0.48095091101912957,-0.4857452651071094,0.13550195433600826,0.7938868141103625,-0.17825074680149555,0.2219318710267543,0.12617019936442372},["leftPolicy"]="always",["rootToIKRight"]={0.1423632654027138,0.9273953586348318,0.06508506178535262,0.06052543428486297,-0.07494969988719836,0.9355665289612505,0.927704095220917,-0.13742600587423606,-0.07102619545596682,0.027713267132639885,-0.04847130551934242,-0.002783839823678136},["linkNodes"]={"skeleton","root","boss"}},["cdf28be026bb7d84"]={["rootName"]="boss",["rootToIKLeft"]={0.5558874303966608,0.529397276784451,-0.6408804007458845,0.43179920961490875,-0.8426978953900198,-0.32157360039637234,-0.7103087955785833,-0.09797293393165875,-0.6970385349035773,-0.07511196285486221,0.099471315741539,0.003551261266693473},["leftPolicy"]="always",["rootToIKRight"]={0.07155809387815121,0.9895323638032637,-0.12532015075976916,-0.043004171804603995,0.12858616174992413,0.9907654217848626,0.9965089463659949,-0.06550799967403637,0.05175540349800617,0.0519632026553154,-0.066082663834095,0.0009573957067914307},["linkNodes"]={"skeleton","root","boss"}},["ce063aa33d95a812"]={["rootName"]="boss",["rootToIKLeft"]={0.5558874303966608,0.529397276784451,-0.6408804007458845,0.43179920961490875,-0.8426978953900198,-0.32157360039637234,-0.7103087955785833,-0.09797293393165875,-0.6970385349035773,-0.07176468521356583,0.17025361955165863,0.04667655751109123},["leftPolicy"]="always",["rootToIKRight"]={0.19944364870218695,0.9774005083039721,-0.07007394772816794,-0.04342011252616115,0.08025520546713755,0.9958281959372526,0.9789468423150944,-0.19556900183955345,0.0584452345430026,0.03808998689055443,-0.09442506730556488,0.0009573957067914307},["linkNodes"]={"skeleton","root","boss"}},["cf8934ff6567a42d"]={["rootName"]="boss",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.045267943292856216,-0.006544031202793121},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07767770439386368,0.009775180369615555},["linkNodes"]={"skeleton","root","boss"}},["d323de60855898ac"]={["rootName"]="boss",["rootToIKLeft"]={0.8218985230447021,0.47939926407566924,-0.30766709965701317,0.45583534783230045,-0.8774244196098486,-0.14946746648995698,-0.3416092401496377,-0.01739845047440894,-0.9396810208605243,-0.09500955909481945,0.32446613907814026,0.04060659185051918},["leftPolicy"]="always",["rootToIKRight"]={0.17411585615883002,0.9787749818959732,-0.10808886829186104,-0.021568490441216226,0.11352980988299144,0.9933004492539098,0.9844889379034001,-0.17061804442224016,0.040878038888451096,0.04215545952320099,-0.07071974873542786,0.016274627298116684},["linkNodes"]={"skeleton","root","boss"}},["d54b9505c0f72873"]={["rootName"]="boss",["rootToIKLeft"]={0.6163323506963793,0.7870857061483827,0.02511025013768542,-0.3666249808368458,0.3150161628432974,-0.8754147249012136,-0.6969365515679731,0.5303403702570518,0.4827199340861689,-0.19825172424316406,0.21392413973808289,0.029102683067321777},["leftPolicy"]="aim_only",["rootToIKRight"]={0.019660769870497807,0.9748926199418142,-0.2218058468820987,-0.045215621769532865,0.22248873423891483,0.9738861898008206,0.9987837612196615,-0.009118262978837888,0.048454675771847644,0.05475248396396637,-0.05437533184885979,0.03385704755783081},["linkNodes"]={"skeleton","root","boss"}},["d6b1fb05b9109353"]={["rootName"]="skeleton",["rootToIKLeft"]={0.1196502346375195,0.9800226313564542,-0.1588693280037354,0.268404911589628,-0.1859905155607549,-0.945180581453094,-0.9558465487648897,0.07044977040854361,-0.28529669655226114,-0.07324307411909103,-0.03726395219564438,-0.021313399076461792},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.05592723563313484,0.017025835812091827},["linkNodes"]={"skeleton","root"}},["dbb6c961c59fadc1"]={["rootName"]="boss",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.045267943292856216,-0.006544031202793121},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07767770439386368,0.009775180369615555},["linkNodes"]={"skeleton","root","boss"}},["dcd1c835407ef7ba"]={["rootName"]="boss",["rootToIKLeft"]={0.5693085147769338,0.6237967185912092,-0.5355048728791564,0.32090072229992345,-0.768308834554246,-0.5538269234817713,-0.756908542315298,0.14345448274883588,-0.6375815790543159,-0.0811227485537529,0.2938240170478821,-0.017352735390886664},["leftPolicy"]="always",["rootToIKRight"]={0.17411585615883002,0.9787749818959732,-0.10808886829186104,-0.021568490441216226,0.11352980988299144,0.9933004492539098,0.9844889379034001,-0.17061804442224016,0.040878038888451096,0.0408499650657177,-0.015664827078580856,0.011837909929454327},["linkNodes"]={"skeleton","root","boss"}},["e3b6aedd07fcb464"]={["rootName"]="boss",["rootToIKLeft"]={1.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,1.0,0.0,0.0,-1.0999882221221924},["leftPolicy"]="always",["linkNodes"]={"skeleton","boss"}},["e5796355a8fd67e0"]={["rootName"]="boss",["rootToIKLeft"]={0.7379350321779761,0.4018065114185175,-0.5422208181785073,0.40572585055336585,-0.906170807671952,-0.11933516793730051,-0.5392943564082431,-0.13193140951516563,-0.8317185222955903,-0.07745245099067688,0.2880803346633911,0.07106467336416245},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}},["e6d932be83729076"]={["rootName"]="boss",["rootToIKLeft"]={0.5569404566720384,0.5589737903027739,-0.6143008304301779,0.3579617347156709,-0.828957047467925,-0.42975994454184346,-0.7494535924422738,0.0194545100339997,-0.6617709836602897,-0.0818280503153801,0.2741517126560211,-0.015596066601574421},["leftPolicy"]="always",["rootToIKRight"]={-0.1125438541239343,0.9323702853438682,-0.3435397093593756,0.10496960216760115,0.35495767042638104,0.9289706318427147,0.9880866680204254,0.06848870865529844,-0.13781884220607682,0.07691752910614014,-0.08730717748403549,-0.01534843910485506},["linkNodes"]={"skeleton","root","boss"}},["e8d5f49ad7780e54"]={["rootName"]="boss",["rootToIKLeft"]={0.6163323533266019,0.787085703737847,0.025110261137458678,-0.36662496855665927,0.31501616775899305,-0.8754147282752712,-0.6969365557019678,0.5303403709146952,0.48271992739511194,-0.20645224347197394,0.20987061597406856,0.03385064812630054},["leftPolicy"]="always",["rootToIKRight"]={0.019660769870497807,0.9748926199418142,-0.2218058468820987,-0.045215621769532865,0.22248873423891483,0.9738861898008206,0.9987837612196615,-0.009118262978837888,0.048454675771847644,0.05475248396396637,-0.05437533184885979,0.03385704755783081},["linkNodes"]={"skeleton","boss"}},["e91f569c2ad8af01"]={["rootName"]="boss",["rootToIKLeft"]={0.1353433194847643,0.9672805966468067,-0.21459336898459133,0.26084394721425125,-0.24373134955303988,-0.9341067735793072,-0.9558465456802574,0.07044973427661283,-0.2852967158091283,-0.07098226249217987,-0.036788661032915115,-0.02259310707449913},["leftPolicy"]="aim_only",["rootToIKRight"]={0.35373070937460266,0.9334361937330037,0.05976167228736959,-0.11164971866934689,-0.021298129096690377,0.9935193656985437,0.9286597469290871,-0.3581106839040457,0.09668408611235163,0.02710658498108387,-0.07767770439386368,-0.006273894105106592},["linkNodes"]={"skeleton","root","boss"}},["eea5e3cef1e12c14"]={["rootName"]="boss",["rootToIKLeft"]={0.3598327401693262,0.8019722546812138,-0.4768237639041962,0.07838228474522974,-0.5352328836721134,-0.8410600321464285,-0.9297185684605593,0.26526639997852003,-0.2554547327846635,-0.09436462074518204,0.153520867228508,0.08294426649808884},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.0508757010102272,-0.07573805004358292,0.015532604418694973},["linkNodes"]={"skeleton","root","boss"}},["efdcef306cea63fe"]={["rootName"]="boss",["rootToIKLeft"]={0.3598327401693262,0.8019722546812138,-0.4768237639041962,0.07838228474522974,-0.5352328836721134,-0.8410600321464285,-0.9297185684605593,0.26526639997852003,-0.2554547327846635,-0.09170085936784744,0.13533134758472443,0.05436144396662712},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.0508757010102272,-0.07573805004358292,0.015532604418694973},["linkNodes"]={"skeleton","root","boss"}},["f0338468dcdb6a6c"]={["rootName"]="boss",["rootToIKLeft"]={0.6974975567675367,0.5080271167531303,-0.5053765801237058,0.47034613519912927,-0.8566427004491369,-0.21198536947264274,-0.5406215066115077,-0.08984264935874547,-0.8364548313838024,-0.07526931911706924,0.25512179732322693,0.06051063910126686},["leftPolicy"]="always",["rootToIKRight"]={0.08808743357285986,0.9723304857941244,-0.21636550196810367,0.021506293403768417,0.215302800128205,0.9763104954884925,0.9958805567891054,-0.09065390588560812,-0.0019457536085730753,0.05033492296934128,-0.06169149652123451,0.035065799951553345},["linkNodes"]={"skeleton","root","boss"}},["f49227a0630a3f7f"]={["rootName"]="boss",["rootToIKLeft"]={0.46510531876537353,0.7596041070505111,-0.4546192285948274,0.27983612026211485,-0.6133681481826784,-0.7385602619905833,-0.8398623626837958,0.21628942495403597,-0.4978454543332146,-0.08939778059720993,0.14389167726039886,0.0038046829868108034},["leftPolicy"]="always",["rootToIKRight"]={0.19944364870218695,0.9774005083039721,-0.07007394772816794,-0.04342011252616115,0.08025520546713755,0.9958281959372526,0.9789468423150944,-0.19556900183955345,0.0584452345430026,0.03918460011482239,-0.07214702665805817,0.012949122115969658},["linkNodes"]={"skeleton","root","boss"}},["f992ce97577c8a7f"]={["rootName"]="boss",["rootToIKLeft"]={0.8201792863079692,0.4530503266731912,-0.34935846892935835,0.41963372924861986,-0.8914616154637058,-0.17089061478750098,-0.38886173712051814,-0.006441655072224661,-0.921273604573334,-0.07453829795122158,0.3062472678720951,0.038657207041978836},["leftPolicy"]="aim_only",["rootToIKRight"]={-0.048476159523897,0.992912673172017,-0.10850975164899782,0.1746628599163882,0.11539035144215593,0.9778435213058805,0.9834342616786886,0.028449476672123025,-0.17901865889782262,0.05449722707271576,-0.07558490335941315,0.006327372044324875},["linkNodes"]={"skeleton","root","boss"}},["fd91a6b676a254e0"]={["rootName"]="boss",["rootToIKLeft"]={0.6974975567675367,0.5080271167531303,-0.5053765801237058,0.47034613519912927,-0.8566427004491369,-0.21198536947264274,-0.5406215066115077,-0.08984264935874547,-0.8364548313838024,-0.07008086889982224,0.1634138822555542,0.059025805443525314},["leftPolicy"]="always",["linkNodes"]={"skeleton","root","boss"}},["fe3b29b2cfa63f9b"]={["rootName"]="boss",["rootToIKLeft"]={0.1760040301493502,0.9788489040718313,0.1042947955008372,-0.9132598050967713,0.20190964699797026,-0.3538204398200816,-0.3673948969978421,-0.03297442321958102,0.9294803263508491,-0.1758347451686859,0.2259015291929245,0.09899047017097473},["leftPolicy"]="always",["rootToIKRight"]={0.09042095395774495,0.9944685887776881,-0.053443033321462746,0.0067798103881705485,0.053046944097329796,0.9985690040718445,0.9958805572365707,-0.09065390097669324,-0.0019457532950564738,0.05033492296934128,-0.07453373074531555,0.013630583882331848},["linkNodes"]={"skeleton","root","boss"}}},["contactMetres"]=0.002,["contactDegrees"]=0.1,["linkMetres"]=0.002,["linkDegrees"]=0.1,["hingeAxis"]={0.0006895141550540217,-0.10952291062871858,-0.9939840323755929},["forearmHingeAxis"]={0.0003006059391823608,-0.018029509997108152,-0.052511260890131056},["softDistance"]=0.008,["reachPolicy"]="anim_batch_mod.processor._apply_two_bone_ik",["requireNativeContact"]=false,["intent"]={["enabled"]=true,["primaryEnterMetres"]=0.1,["primaryLeaveMetres"]=0.14,["sidearmEnterMetres"]=0.035,["sidearmLeaveMetres"]=0.055,["weaponThresholds"]={["a955c4ea6f6d4203"]={["enterMetres"]=0.14,["leaveMetres"]=0.18}},["semantics"]="experimental unswapped-native-hand pose proxy; NOT true ADS/reload flags"}},["sync"]={["enabled"]=false,["seconds"]=0.2,["maxSamples"]=1800,["pairs"]={{["name"]="hips",["native"]={["name"]="hips",["index"]=9,["parent"]=7,["hash"]=1720674920},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_000_hips",["index"]=107,["parent"]=197,["hash"]=1955713740},["axes"]={9.014375904337069e-07,0.9793123706540467,0.20235434436437993,-1.4131878780521134e-06,-0.2023543443630125,0.9793123706537246,0.999999999998595,-1.1687536901616724e-06,1.2015425584765982e-06,0.0,0.0,0.0}},{["name"]="spine1",["native"]={["name"]="spine1",["index"]=21,["parent"]=7,["hash"]=1490585339},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=108,["parent"]=197,["hash"]=1877104845},["axes"]={0.9999999999975238,-6.822393453117529e-07,-2.118407614238126e-06,2.118405244648036e-06,-3.4732353417776807e-06,0.9999999999917247,-6.822467030343011e-07,-0.9999999999937358,-3.4732338964893472e-06,0.0,0.0,0.0}},{["name"]="spine2",["native"]={["name"]="spine2",["index"]=26,["parent"]=21,["hash"]=1514912418},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=255,["parent"]=26,["hash"]=1520906558},["axes"]={0.9980120818892231,-0.06302288792392963,-9.309608754448639e-07,-8.777619049174512e-07,8.718084988923458e-07,-0.9999999999992348,0.06302288792469302,0.9980120818892766,8.147563247962175e-07,0.0,0.0,0.0},["reference"]={["name"]="__hd2_b23_reference__hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=110,["parent"]=109,["hash"]=3738790731}},{["name"]="chest",["native"]={["name"]="chest",["index"]=28,["parent"]=26,["hash"]=938412064},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=256,["parent"]=28,["hash"]=3698807838},["axes"]={0.9848078678417286,0.17364752643455017,4.3647781435007804e-07,-6.72273231097642e-07,6.3262506770356275e-06,-0.9999999999797634,-0.17364752643379738,0.9848078678215061,6.346880024377111e-06,0.0,0.0,0.0},["reference"]={["name"]="__hd2_b23_reference__hd2n_4e4fb4fa303d_anim_004_chest",["index"]=111,["parent"]=110,["hash"]=4210192551}},{["name"]="neck",["native"]={["name"]="neck",["index"]=89,["parent"]=28,["hash"]=3924609569},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_054_neck",["index"]=161,["parent"]=256,["hash"]=3853654291},["axes"]={0.9999767638986662,-5.630123205780171e-07,-0.0068170127207150015,-0.006817012725227797,-8.445541865409467e-06,-0.9999767638631296,5.054258720169416e-07,0.999999999964178,-8.449183686143336e-06,0.0,0.0,0.0}},{["name"]="head",["native"]={["name"]="head",["index"]=90,["parent"]=89,["hash"]=2354409673},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_055_head",["index"]=162,["parent"]=161,["hash"]=3949009523},["axes"]={-0.8960246392981001,-0.2124482543321259,-0.389878936340427,-0.39898702830732913,7.340464053678941e-07,0.9169565699867953,-0.19480553640283665,0.9771723180845301,-0.08476475538872014,0.0,0.0,0.0}},{["name"]="l_clavicle",["native"]={["name"]="l_clavicle",["index"]=42,["parent"]=28,["hash"]=3296230222},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_005_l_clavicle",["index"]=112,["parent"]=256,["hash"]=1195967450},["axes"]={0.9715285277202995,0.2364947843305228,-0.014231542786614343,0.01029903080132584,-0.10216764583868132,-0.9947138795192996,-0.23669864763065512,0.9662463397748224,-0.10169444961047597,0.0,0.0,0.0}},{["name"]="l_shoulder",["native"]={["name"]="l_shoulder",["index"]=44,["parent"]=42,["hash"]=58010776},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=257,["parent"]=113,["hash"]=1872341567},["axes"]={0.9984569845758685,0.05526775140350125,-0.005396814473800141,-0.05551679669281177,0.9956515995387231,-0.07480493045883718,0.0012390466628976302,0.0749891191492689,0.9971835822819106,0.0,0.0,0.0},["reference"]={["name"]="__hd2_b23_reference__hd2n_4e4fb4fa303d_anim_006_l_shoulder",["index"]=113,["parent"]=112,["hash"]=3960215984}},{["name"]="l_elbow",["native"]={["name"]="l_elbow",["index"]=46,["parent"]=44,["hash"]=480431462},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=258,["parent"]=114,["hash"]=4226160508},["axes"]={0.9999226208260509,-0.00883497116583256,0.008757604972872434,0.01133985377298017,0.9367998175119949,-0.34968201215661726,-0.005114692245815011,0.34975426401116555,0.9368275159970691,0.0,0.0,0.0},["reference"]={["name"]="__hd2_b23_reference__hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=114,["parent"]=113,["hash"]=4040395058}},{["name"]="l_hand",["native"]={["name"]="l_hand",["index"]=47,["parent"]=46,["hash"]=1544317139},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=259,["parent"]=115,["hash"]=2014374854},["axes"]={0.9698523497804471,0.24250113091198405,-0.024075322048818126,0.028337436653635625,-0.21034915711648688,-0.9772155452019197,-0.24204009855651343,0.9470725598425881,-0.21087948473941454,0.0,0.0,0.0},["reference"]={["name"]="__hd2_b23_reference__hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=115,["parent"]=114,["hash"]=343737262}},{["name"]="r_clavicle",["native"]={["name"]="r_clavicle",["index"]=65,["parent"]=28,["hash"]=2998720569},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_028_r_clavicle",["index"]=135,["parent"]=256,["hash"]=1647229629},["axes"]={0.9676280231743393,0.25186097470842816,0.0161882113478128,-0.01198689105490014,0.1099327777240855,-0.9938667409792448,-0.25209586115317106,0.9614992635466695,0.1093930664560317,0.0,0.0,0.0}},{["name"]="r_shoulder",["native"]={["name"]="r_shoulder",["index"]=67,["parent"]=65,["hash"]=371241678},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_029_r_shoulder",["index"]=136,["parent"]=135,["hash"]=991151059},["axes"]={0.9982672790001367,0.05165130508561788,0.028188337315549934,0.053158425821358685,-0.9970352972223436,-0.05563090738921704,0.025231358303862812,0.05703296218595841,-0.998053415295212,0.0,0.0,0.0}},{["name"]="r_elbow",["native"]={["name"]="r_elbow",["index"]=69,["parent"]=67,["hash"]=836980140},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_030_r_elbow",["index"]=137,["parent"]=136,["hash"]=4227385818},["axes"]={0.9999297945313673,-0.002208045094005787,0.011641758686734215,0.003482162914048581,-0.8843460187054336,-0.4668190160450713,0.011326100383509731,0.4668267812976365,-0.8842762440060182,0.0,0.0,0.0}},{["name"]="r_hand",["native"]={["name"]="r_hand",["index"]=71,["parent"]=69,["hash"]=612369653},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=138,["parent"]=137,["hash"]=3022610578},["axes"]={0.9702061922772703,0.24089138307280594,0.025909188102131622,-0.06421478090319893,0.35878590303728136,-0.9312084287071702,-0.2336159377705107,0.9018004309951253,0.3635650922140513,0.0,0.0,0.0}}},["aim"]={["name"]="weapon_aim",["index"]=85,["parent"]=84,["hash"]=2305964830},["reference"]="same-callback numeric poses; weapon aim is not a camera sample"},["weaponRight"]={0.10136651247739792,0.9919782280921936,-0.07552514970302582,-0.043420109897851944,0.08025521039962769,0.9958282113075256,0.9939011931419373,-0.09766431897878647,0.05120699480175972,0.04822712764143944,-0.05957790091633797,0.01641298085451126},["weaponForegripLeft"]={0.4919045865535737,0.870606780052185,0.008588146418333657,-0.0776919350028028,0.053717445582151545,-0.9955292344093324,-0.867175817489624,0.4890381395816804,0.09406298398971476,-0.07793310284614559,0.1965024257078767,-0.02858553640544423},["minNodes"]=3,["maxNodes"]=512,["maxRecords"]=5000,["scanSeconds"]=0.5,["logSeconds"]=1.0,["consumerRadius"]=3.0,["maxWristMountDistance"]=0.5,["matchTolerance"]=0.001,["localTolerance"]=2e-05,["worldTolerance"]=0.002,["attachments"]={{["node"]={["name"]="pistol",["index"]=11,["parent"]=10,["hash"]=3438608839},["native"]={["name"]="r_thigh",["index"]=10,["parent"]=9,["hash"]=1955545729},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_060_r_thigh",["index"]=167,["parent"]=107,["hash"]=3802879602},["axes"]={0.9999411471183574,0.010849049810158167,2.044115543291497e-05,0.01075094136529491,-0.9906422781810705,-0.1360598910038479,-0.0014558706618787208,0.1360521032488498,-0.9907006135267004,0,0,0}},{["node"]={["name"]="attach_samplepouch",["index"]=22,["parent"]=21,["hash"]=598743},["native"]={["name"]="spine1",["index"]=21,["parent"]=7,["hash"]=1490585339},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=108,["parent"]=197,["hash"]=1877104845},["axes"]={0.9999999999975238,-6.822393453117529e-07,-2.118407614238126e-06,2.118405244648036e-06,-3.4732353417776807e-06,0.9999999999917247,-6.822467030343011e-07,-0.9999999999937358,-3.4732338964893472e-06,0,0,0}},{["node"]={["name"]="attach_intelpad",["index"]=23,["parent"]=21,["hash"]=2221210382},["native"]={["name"]="spine1",["index"]=21,["parent"]=7,["hash"]=1490585339},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=108,["parent"]=197,["hash"]=1877104845},["axes"]={0.9999999999975238,-6.822393453117529e-07,-2.118407614238126e-06,2.118405244648036e-06,-3.4732353417776807e-06,0.9999999999917247,-6.822467030343011e-07,-0.9999999999937358,-3.4732338964893472e-06,0,0,0}},{["node"]={["name"]="target_designator",["index"]=24,["parent"]=21,["hash"]=27055602},["native"]={["name"]="spine1",["index"]=21,["parent"]=7,["hash"]=1490585339},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=108,["parent"]=197,["hash"]=1877104845},["axes"]={0.9999999999975238,-6.822393453117529e-07,-2.118407614238126e-06,2.118405244648036e-06,-3.4732353417776807e-06,0.9999999999917247,-6.822467030343011e-07,-0.9999999999937358,-3.4732338964893472e-06,0,0,0}},{["node"]={["name"]="attach_knife",["index"]=25,["parent"]=21,["hash"]=2532799282},["native"]={["name"]="spine1",["index"]=21,["parent"]=7,["hash"]=1490585339},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_001_spine1",["index"]=108,["parent"]=197,["hash"]=1877104845},["axes"]={0.9999999999975238,-6.822393453117529e-07,-2.118407614238126e-06,2.118405244648036e-06,-3.4732353417776807e-06,0.9999999999917247,-6.822467030343011e-07,-0.9999999999937358,-3.4732338964893472e-06,0,0,0}},{["node"]={["name"]="sling",["index"]=27,["parent"]=26,["hash"]=3968224353},["native"]={["name"]="spine2",["index"]=26,["parent"]=21,["hash"]=1514912418},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_003_spine2",["index"]=255,["parent"]=26,["hash"]=1520906558},["axes"]={0.9980120818892231,-0.06302288792392963,-9.309608754448639e-07,-8.777619049174512e-07,8.718084988923458e-07,-0.9999999999992348,0.06302288792469302,0.9980120818892766,8.147563247962175e-07,0,0,0}},{["node"]={["name"]="backpack",["index"]=29,["parent"]=28,["hash"]=2004397926},["native"]={["name"]="chest",["index"]=28,["parent"]=26,["hash"]=938412064},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=256,["parent"]=28,["hash"]=3698807838},["axes"]={0.9848078678417286,0.17364752643455017,4.3647781435007804e-07,-6.72273231097642e-07,6.3262506770356275e-06,-0.9999999999797634,-0.17364752643379738,0.9848078678215061,6.346880024377111e-06,0,0,0}},{["node"]={["name"]="support_mg",["index"]=30,["parent"]=28,["hash"]=133847770},["native"]={["name"]="chest",["index"]=28,["parent"]=26,["hash"]=938412064},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=256,["parent"]=28,["hash"]=3698807838},["axes"]={0.9848078678417286,0.17364752643455017,4.3647781435007804e-07,-6.72273231097642e-07,6.3262506770356275e-06,-0.9999999999797634,-0.17364752643379738,0.9848078678215061,6.346880024377111e-06,0,0,0}},{["node"]={["name"]="support",["index"]=31,["parent"]=28,["hash"]=3893183355},["native"]={["name"]="chest",["index"]=28,["parent"]=26,["hash"]=938412064},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=256,["parent"]=28,["hash"]=3698807838},["axes"]={0.9848078678417286,0.17364752643455017,4.3647781435007804e-07,-6.72273231097642e-07,6.3262506770356275e-06,-0.9999999999797634,-0.17364752643379738,0.9848078678215061,6.346880024377111e-06,0,0,0}},{["node"]={["name"]="attach_weapon",["index"]=32,["parent"]=28,["hash"]=2996348202},["native"]={["name"]="r_hand",["index"]=71,["parent"]=69,["hash"]=612369653},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_031_r_hand",["index"]=138,["parent"]=137,["hash"]=3022610578},["axes"]={0.9702061922772703,0.24089138307280594,0.025909188102131622,-0.06421478090319893,0.35878590303728136,-0.9312084287071702,-0.2336159377705107,0.9018004309951253,0.3635650922140513,0,0,0}},{["node"]={["name"]="cape1",["index"]=34,["parent"]=28,["hash"]=2405377262},["native"]={["name"]="chest",["index"]=28,["parent"]=26,["hash"]=938412064},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=256,["parent"]=28,["hash"]=3698807838},["axes"]={0.9848078678417286,0.17364752643455017,4.3647781435007804e-07,-6.72273231097642e-07,6.3262506770356275e-06,-0.9999999999797634,-0.17364752643379738,0.9848078678215061,6.346880024377111e-06,0,0,0}},{["node"]={["name"]="cape2",["index"]=35,["parent"]=34,["hash"]=4128216218},["native"]={["name"]="chest",["index"]=28,["parent"]=26,["hash"]=938412064},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=256,["parent"]=28,["hash"]=3698807838},["axes"]={0.9848078678417286,0.17364752643455017,4.3647781435007804e-07,-6.72273231097642e-07,6.3262506770356275e-06,-0.9999999999797634,-0.17364752643379738,0.9848078678215061,6.346880024377111e-06,0,0,0}},{["node"]={["name"]="cape3",["index"]=36,["parent"]=35,["hash"]=1839357638},["native"]={["name"]="chest",["index"]=28,["parent"]=26,["hash"]=938412064},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=256,["parent"]=28,["hash"]=3698807838},["axes"]={0.9848078678417286,0.17364752643455017,4.3647781435007804e-07,-6.72273231097642e-07,6.3262506770356275e-06,-0.9999999999797634,-0.17364752643379738,0.9848078678215061,6.346880024377111e-06,0,0,0}},{["node"]={["name"]="cape4",["index"]=37,["parent"]=36,["hash"]=619184713},["native"]={["name"]="chest",["index"]=28,["parent"]=26,["hash"]=938412064},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=256,["parent"]=28,["hash"]=3698807838},["axes"]={0.9848078678417286,0.17364752643455017,4.3647781435007804e-07,-6.72273231097642e-07,6.3262506770356275e-06,-0.9999999999797634,-0.17364752643379738,0.9848078678215061,6.346880024377111e-06,0,0,0}},{["node"]={["name"]="cape5",["index"]=38,["parent"]=37,["hash"]=1092771792},["native"]={["name"]="chest",["index"]=28,["parent"]=26,["hash"]=938412064},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=256,["parent"]=28,["hash"]=3698807838},["axes"]={0.9848078678417286,0.17364752643455017,4.3647781435007804e-07,-6.72273231097642e-07,6.3262506770356275e-06,-0.9999999999797634,-0.17364752643379738,0.9848078678215061,6.346880024377111e-06,0,0,0}},{["node"]={["name"]="cape6",["index"]=39,["parent"]=38,["hash"]=601034983},["native"]={["name"]="chest",["index"]=28,["parent"]=26,["hash"]=938412064},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=256,["parent"]=28,["hash"]=3698807838},["axes"]={0.9848078678417286,0.17364752643455017,4.3647781435007804e-07,-6.72273231097642e-07,6.3262506770356275e-06,-0.9999999999797634,-0.17364752643379738,0.9848078678215061,6.346880024377111e-06,0,0,0}},{["node"]={["name"]="cape7",["index"]=40,["parent"]=39,["hash"]=3123615026},["native"]={["name"]="chest",["index"]=28,["parent"]=26,["hash"]=938412064},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=256,["parent"]=28,["hash"]=3698807838},["axes"]={0.9848078678417286,0.17364752643455017,4.3647781435007804e-07,-6.72273231097642e-07,6.3262506770356275e-06,-0.9999999999797634,-0.17364752643379738,0.9848078678215061,6.346880024377111e-06,0,0,0}},{["node"]={["name"]="cape8",["index"]=41,["parent"]=40,["hash"]=419927175},["native"]={["name"]="chest",["index"]=28,["parent"]=26,["hash"]=938412064},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_004_chest",["index"]=256,["parent"]=28,["hash"]=3698807838},["axes"]={0.9848078678417286,0.17364752643455017,4.3647781435007804e-07,-6.72273231097642e-07,6.3262506770356275e-06,-0.9999999999797634,-0.17364752643379738,0.9848078678215061,6.346880024377111e-06,0,0,0}},{["node"]={["name"]="attach_hand_l",["index"]=48,["parent"]=47,["hash"]=1100233117},["native"]={["name"]="l_hand",["index"]=47,["parent"]=46,["hash"]=1544317139},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_008_l_hand",["index"]=259,["parent"]=115,["hash"]=2014374854},["axes"]={0.9698523497804471,0.24250113091198405,-0.024075322048818126,0.028337436653635625,-0.21034915711648688,-0.9772155452019197,-0.24204009855651343,0.9470725598425881,-0.21087948473941454,0,0,0},["reference"]={["name"]="__hd2_attach_original__hd2n_4e4fb4fa303d_048",["index"]=219,["parent"]=47,["hash"]=1561813730}},{["node"]={["name"]="hellpad_socket",["index"]=103,["parent"]=46,["hash"]=2781352283},["native"]={["name"]="l_elbow",["index"]=46,["parent"]=44,["hash"]=480431462},["source"]={["name"]="hd2n_4e4fb4fa303d_anim_007_l_elbow",["index"]=258,["parent"]=114,["hash"]=4226160508},["axes"]={0.9999226208260509,-0.00883497116583256,0.008757604972872434,0.01133985377298017,0.9367998175119949,-0.34968201215661726,-0.005114692245815011,0.34975426401116555,0.9368275159970691,0,0,0}}},["performance"]={["strictConsumers"]=true,["cacheIdentity"]=true,["scopedRefresh"]=true,["batchRefresh"]=true,["refreshRadius"]=1.5},["previewGuard"]={["enabled"]=true,["minimumWorldUnits"]=128},["allowedConsumers"]={["005c2262f672caf4"]=true,["006e44327bb953fe"]=true,["027dec442cc26a90"]=true,["02cd7321cd8445f5"]=true,["02eecd0b1fa49630"]=true,["03e67a19b07c6523"]=true,["05d8d8c073b9d502"]=true,["05e4e5c2db6e44a2"]=true,["076dd5d4f4360204"]=true,["0b882808c6f498e8"]=true,["0c197bbd8d2c725b"]=true,["0f83639ab8c86165"]=true,["11c27d3babb38956"]=true,["11ec8e2296a3d662"]=true,["129e5fb1b13c2018"]=true,["14d5d4506056c7a4"]=true,["16f397ca5f51f271"]=true,["186ea95de7306b1a"]=true,["1a437158e1b8d2a1"]=true,["1abbff60d26ba391"]=true,["1c8764d62e12925a"]=true,["2152d5147b0ac418"]=true,["2383b0439f0bc465"]=true,["2457b559aa341cc1"]=true,["25aa2fd4643cf4ee"]=true,["26e40437ea275296"]=true,["26ec4f9513fc6525"]=true,["27ee1ed8f6fb6356"]=true,["28aee9c6a2282aa3"]=true,["295beb26dc4f8ff1"]=true,["2b28e17ffed05f7c"]=true,["2d761a80bcbfe792"]=true,["2e9d0bdc48b09e60"]=true,["30061f91af477f5e"]=true,["309f7e645a8d2b56"]=true,["3575aabc5f1f9326"]=true,["35a61296619cc47e"]=true,["372481e910c05a76"]=true,["37c2891774b38c87"]=true,["3828e2051aa9e897"]=true,["39ab99895147a3bf"]=true,["3ae1f60c5efd2b43"]=true,["3ae8ba6377efe3ae"]=true,["3c86e871923f3970"]=true,["3d58ea61b2b485cc"]=true,["3f92ba65ef65cca9"]=true,["411c4fd07740a7dd"]=true,["416d053372c4e433"]=true,["41eac4a03987faa0"]=true,["41f2def484634b59"]=true,["43a58cb89cfa197c"]=true,["43b2d7766120203b"]=true,["46183b50961d1328"]=true,["4851d75853622a47"]=true,["4ba41b6f9f405cc2"]=true,["4d58c77087b774c5"]=true,["4dbd74f49c8ffc13"]=true,["4e4a613eb9bf5c24"]=true,["4fb0f8c02f55c82b"]=true,["4ffb842ce1093f3f"]=true,["52071f49263415e4"]=true,["52e4334e6a128caf"]=true,["53eebe75cd6e26df"]=true,["541eb319127c7484"]=true,["5990123d142b16cb"]=true,["5beec97f4c7f4ae9"]=true,["5c1e075cba68340b"]=true,["5f3ec9bda2bd8553"]=true,["5fecab819f96a3e8"]=true,["6228d0242bde56b6"]=true,["64cdb52aca152be1"]=true,["6cfcc7f8801a0266"]=true,["6d54652ee217d712"]=true,["6e68194b95d60145"]=true,["708ea298c82093d0"]=true,["72170a55a1f37ff1"]=true,["73d84eaae8c75342"]=true,["756e3fdaca41cfca"]=true,["7617642765ac38c7"]=true,["7686544f539bb9b7"]=true,["78a8185f63a70795"]=true,["7b06196e90154c88"]=true,["7b153e02ad22d12c"]=true,["7b75e5132ffd4ca6"]=true,["7be1e04a7738e673"]=true,["7e3145a5baa4b948"]=true,["8039834a4b7489b9"]=true,["80932fa0ed6901d3"]=true,["80f1a156d9fa1e36"]=true,["84354339522c932d"]=true,["8645f167b3c813a2"]=true,["88c2d09ad85a7c9f"]=true,["89c5493e08ca4207"]=true,["8a307bd1811a5fe9"]=true,["8cd335a5f711bb59"]=true,["8d3d52a3b2f19402"]=true,["8dc91f277c6096ee"]=true,["8f6f7c8c1e4b9b6d"]=true,["90ddc374f4e3d756"]=true,["94bd931b5fb4ee95"]=true,["9549ff64ba3fd5a1"]=true,["9571ca51f0daf35b"]=true,["968211c0033dce64"]=true,["96de9cd50f7306e6"]=true,["9dbc8aa8702ac9e1"]=true,["9eb160830321bfd6"]=true,["9f80d67a12a7e40f"]=true,["a0b52d203e689d18"]=true,["a4fa3ef43a8cecaf"]=true,["a6a735accb4a327f"]=true,["a7ee1ebf58fcdf1f"]=true,["a8a91eb54892b6b2"]=true,["a8cffb316f0b5c5f"]=true,["a955c4ea6f6d4203"]=true,["a9936cbe561e8180"]=true,["aa69a60d74a3ec54"]=true,["ab2a2b390c539f18"]=true,["b0f1b354ba1d38d8"]=true,["b16c9d490aa59b77"]=true,["b191a4f26558a9cc"]=true,["b2b5e0d185605f9e"]=true,["b571e0428ca83b9e"]=true,["b80951732a5f58f4"]=true,["b814eece17533bc4"]=true,["bc29613666df696b"]=true,["bd4245dcfd4b832f"]=true,["bde1f2534280300d"]=true,["be70ee0d8d44028e"]=true,["bf4cfd2aeabfb5a4"]=true,["c12a34f375bd5a87"]=true,["c4232a0e62166d91"]=true,["c780bcd79547da0f"]=true,["c85f576d5e086147"]=true,["cc786f6491fe7e65"]=true,["cdf28be026bb7d84"]=true,["ce063aa33d95a812"]=true,["cf8934ff6567a42d"]=true,["d323de60855898ac"]=true,["d54b9505c0f72873"]=true,["d6b1fb05b9109353"]=true,["d8cf7fe059b4bf1e"]=true,["db50297b40133d12"]=true,["dbb6c961c59fadc1"]=true,["dcd1c835407ef7ba"]=true,["e3b6aedd07fcb464"]=true,["e5796355a8fd67e0"]=true,["e69567209a83df39"]=true,["e6d932be83729076"]=true,["e8d5f49ad7780e54"]=true,["e8de5e95b9635c21"]=true,["e91f569c2ad8af01"]=true,["ec824b9d8b7f7b58"]=true,["eea5e3cef1e12c14"]=true,["efdcef306cea63fe"]=true,["f0338468dcdb6a6c"]=true,["f49227a0630a3f7f"]=true,["f992ce97577c8a7f"]=true,["f9c6092b665018b8"]=true,["f9df21c8e52cac95"]=true,["f9f37dcce764fad6"]=true,["fd91a6b676a254e0"]=true,["fe3b29b2cfa63f9b"]=true,["ffc18b2ce10ca381"]=true},["diagnostics"]={["consumers"]=false}}
end)()
local path=assert(loader.log_directory,'Chef log directory unavailable')..'/hd2_grip_b23.log'
local handle,why=io.open(path,'a');assert(handle,'Cannot open B23 log: '..tostring(why))
local closed,frame,lastFlush=false,0,0
local function log(line)
    if handle then
        handle:write(os.date('%Y-%m-%d %H:%M:%S'),' [grip_b23] ',line,'\n')
        local now=stingray.Application.time_since_launch()
        local urgent=line:find('"event":"loaded"',1,true) or line:find('"event":"complete"',1,true)
            or line:find('"event":"disabled"',1,true) or line:find('"event":"rollback"',1,true)
            or line:find('"event":"restore_failed"',1,true)
        if urgent or now-lastFlush>=0.5 then handle:flush();lastFlush=now end
    end
end
local made,runtime=pcall(AttachmentRuntime.install,stingray,{profile=profile,logger=log,armMath=ArmMath,transfer=Transfer})
if not made then handle:close();error(runtime) end
__hd2_grip_b23=runtime
local function stop(reason)
    if closed then return end
    local ok,err=pcall(runtime.stop,runtime,reason or 'shutdown')
    if not ok then log('{"event":"shutdown_error","variant":"'..profile.variant..'"}') end
    handle:flush();handle:close();handle=nil;closed=true;__hd2_grip_b23=nil
    if not ok then error(err) end
end
local function step(phase)
    if closed then return end
    if phase=='update' then frame=frame+1 end
    local ok,err=pcall(runtime.tick,runtime,phase,frame,stingray.Application.time_since_launch())
    if not ok then
        log('{"event":"callback_error","phase":"'..phase..'","variant":"'..profile.variant..'"}')
        stop('callback_error');error(err)
    end
end
return {version=Transfer.VERSION,update=function()step('update')end,render=function()step('render')end,
    shutdown=function()stop('shutdown')end,on_stop=function()stop('on_stop')end}
